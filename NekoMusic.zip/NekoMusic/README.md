# NEKO MUSIC (v0.7.0)

## Como compilar
1. Android Studio (Ladybug ou mais novo) → File > Open → pasta `NekoMusic`.
2. Aguarde o Gradle sincronizar (ele baixa o wrapper e as dependências; requer internet).
3. Rode em um aparelho real (Android 8.0+). Emulador sem músicas mostra a biblioteca vazia.
4. APK: Build > Build APK(s)  → app/build/outputs/apk/debug/app-debug.apk

## Status
Feito: tema BLUE, biblioteca real (MediaStore, MP4 com áudio), busca, ordenação, categorias,
mini player, player completo, Media3 + MediaSession + serviço em 2º plano, notificação/tela de bloqueio,
equalizador real (Visualizer API/FFT), shuffle/repeat, configurações básicas.
Etapa 5: Room (favoritos e playlists: criar, renomear, excluir, adicionar, remover), fila de reprodução
(sheet no player), botão de favorito e menu de opções no player e nas listas.
Pendente: letras, ajustes do equalizador de áudio, reordenar fila, tema claro, testes em vários aparelhos.

## Observação sobre o equalizador
A Visualizer API do Android exige a permissão RECORD_AUDIO mesmo analisando o áudio do próprio app.
Sem ela o app mostra aviso — não simula barras.

## v0.2.0 — Etapa 6 + filtro do WhatsApp
- Biblioteca oculta áudios do WhatsApp / WhatsApp Business por padrão (pastas "WhatsApp*" / "com.whatsapp*" e nomes AUD-/PTT-/VOICE-/VID-AAAAMMDD-WAxxxx).
  Configurações > Biblioteca > "Mostrar áudios do WhatsApp" liga/desliga na hora (sem reler os arquivos). Nada é apagado.
- Correção de código (agrupamento por artista/álbum/pasta), menos recomposições no visualizador, ticker de posição mais leve em pausa.
- CI: .github/workflows/apk.yml roda os testes unitários e gera o APK debug.

## Checklist de teste no aparelho
1. Primeira abertura: permissões pedidas e biblioteca aparece.  2. Tocar MP3/FLAC/M4A e um MP4 com áudio.
3. Bloquear a tela: notificação com anterior/play/próxima.  4. Player > "Ativar equalizador": barras reagem à música.
5. Favoritar, criar playlist, fechar o app e reabrir.  6. Receber um áudio no WhatsApp > Atualizar biblioteca: não aparece; ligar a opção: aparece.

## v0.3.0
- MP4: fora da biblioteca por padrão; filtro na varredura (MediaScanner). Configurações > "Mostrar áudios de vídeos (MP4)" reindexa.
- Camadas: Player e Configurações bloqueiam toques que passariam para a lista (Modifier.blockTouchesBehind).
- Excluir música (⋮ > Excluir música): confirmação + MediaStore.createDeleteRequest (Android 11+), RecoverableSecurityException (Android 10),
  delete direto + WRITE_EXTERNAL_STORAGE (Android 9-). Só remove da biblioteca/favoritos/playlists/fila se o arquivo realmente sumiu.

## v0.4.0 — Splash animada
Neko (olho aberto -> piscada) -> estrelas mágicas cartoon -> chuva de estrelas cadentes -> transição para a biblioteca.
Código: presentation/splash/NekoSplash.kt (uma linha do tempo em Canvas, ~4,4 s, toque/voltar para pular).
Só na abertura; respeita "remover animações" do Android. Imagens: res/drawable-nodpi/neko_splash_open|blink.webp.

## v0.5.0 — Integração com os controles de mídia
- Toque no cartão/notificação abre o player (MediaSession.setSessionActivity + launchMode singleTask + onNewIntent).
- Capa no cartão/tela de bloqueio: capa real dentro de um display Y2K (NekoBitmapLoader/Y2kArtwork); sem capa, display NEKO.
- Canal de notificação e ícone próprios; MediaButtonReceiver; estado reconstruído dos metadados ao recriar a Activity.

## v0.6.0 — Mascote animada no cabeçalho
presentation/components/NekoMascot.kt substitui a imagem estática da logo (mesmo 38 dp / cantos 8 dp).
Dormindo (parado/pausado): 2 frames em respiração + Zzz. Dançando (tocando): 6 frames em loop com fusão + notas ♪♫ e brilhos.
Estado vem de PlayerViewModel.playbackActive (playWhenReady + READY/BUFFERING). Respeita "remover animações".

## v0.7.0 — Equalizador real (estilo mini system Y2K)
- audio/NekoEqualizer.kt: android.media.audiofx.Equalizer na MESMA sessão do ExoPlayer (criado no PlaybackService, vale com o app fechado).
- audio/EqModel.kt: 7 bandas (60, 150, 400, 1k, 2,4k, 6k, 15k), presets e mapeamento p/ as bandas físicas do aparelho (interpolação em escala log).
- Tela: espectro colorido real, 9 presets, 7 faders metálicos (-12..+12 dB), botão giratório de PREAMP, ON/OFF e RESET. Configurações persistentes.
- Acesso: ícone de sliders na barra superior do player.
