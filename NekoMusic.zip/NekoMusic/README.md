# NEKO MUSIC (v0.4.0)

## Como compilar
1. Android Studio (Ladybug ou mais novo) → File > Open → pasta `NekoMusic`.
2. Aguarde o Gradle sincronizar (ele baixa o wrapper e as dependências; requer internet).
3. Rode em um aparelho real (Android 8.0+). Emulador sem músicas mostra a biblioteca vazia.
4. APK: Build > Build APK(s)  → app/build/outputs/apk/debug/app-debug.apk

## Status
Feito: tema BLUE, biblioteca real (MediaStore, MP4 com áudio), busca, ordenação, categorias,
mini player, player completo, Media3 + MediaSession + serviço em 2º plano, notificação/tela de bloqueio,
equalizador real (Visualizer API/FFT), shuffle/repeat, configurações básicas.
Etapa 5: Room (favoritos e playlists: criar, renomear, excluir, adicionar, remover), fila de reprodução
(sheet no player), botão de favorito e menu de opções no player e nas listas.
Pendente: letras, ajustes do equalizador de áudio, reordenar fila, tema claro, testes em vários aparelhos.

## Observação sobre o equalizador
A Visualizer API do Android exige a permissão RECORD_AUDIO mesmo analisando o áudio do próprio app.
Sem ela o app mostra aviso — não simula barras.

## v0.2.0 — Etapa 6 + filtro do WhatsApp
- Biblioteca oculta áudios do WhatsApp / WhatsApp Business por padrão (pastas "WhatsApp*" / "com.whatsapp*" e nomes AUD-/PTT-/VOICE-/VID-AAAAMMDD-WAxxxx).
  Configurações > Biblioteca > "Mostrar áudios do WhatsApp" liga/desliga na hora (sem reler os arquivos). Nada é apagado.
- Correção de código (agrupamento por artista/álbum/pasta), menos recomposições no visualizador, ticker de posição mais leve em pausa.
- CI: .github/workflows/apk.yml roda os testes unitários e gera o APK debug.

## Checklist de teste no aparelho
1. Primeira abertura: permissões pedidas e biblioteca aparece.  2. Tocar MP3/FLAC/M4A e um MP4 com áudio.
3. Bloquear a tela: notificação com anterior/play/próxima.  4. Player > "Ativar equalizador": barras reagem à música.
5. Favoritar, criar playlist, fechar o app e reabrir.  6. Receber um áudio no WhatsApp > Atualizar biblioteca: não aparece; ligar a opção: aparece.

## v0.3.0
- MP4: fora da biblioteca por padrão; filtro na varredura (MediaScanner). Configurações > "Mostrar áudios de vídeos (MP4)" reindexa.
- Camadas: Player e Configurações bloqueiam toques que passariam para a lista (Modifier.blockTouchesBehind).
- Excluir música (⋮ > Excluir música): confirmação + MediaStore.createDeleteRequest (Android 11+), RecoverableSecurityException (Android 10),
  delete direto + WRITE_EXTERNAL_STORAGE (Android 9-). Só remove da biblioteca/favoritos/playlists/fila se o arquivo realmente sumiu.

## v0.4.0 — Splash animada
Neko (olho aberto -> piscada) -> estrelas mágicas cartoon -> chuva de estrelas cadentes -> transição para a biblioteca.
Código: presentation/splash/NekoSplash.kt (uma linha do tempo em Canvas, ~4,4 s, toque/voltar para pular).
Só na abertura; respeita "remover animações" do Android. Imagens: res/drawable-nodpi/neko_splash_open|blink.webp.
