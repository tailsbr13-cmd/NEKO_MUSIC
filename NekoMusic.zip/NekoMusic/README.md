# NEKO MUSIC (v0.1.0)

## Como compilar
1. Android Studio (Ladybug ou mais novo) → File > Open → pasta `NekoMusic`.
2. Aguarde o Gradle sincronizar (ele baixa o wrapper e as dependências; requer internet).
3. Rode em um aparelho real (Android 8.0+). Emulador sem músicas mostra a biblioteca vazia.
4. APK: Build > Build APK(s)  → app/build/outputs/apk/debug/app-debug.apk

## Status
Feito: tema BLUE, biblioteca real (MediaStore, MP4 com áudio), busca, ordenação, categorias,
mini player, player completo, Media3 + MediaSession + serviço em 2º plano, notificação/tela de bloqueio,
equalizador real (Visualizer API/FFT), shuffle/repeat, configurações básicas.
Etapa 5: Room (favoritos e playlists: criar, renomear, excluir, adicionar, remover), fila de reprodução
(sheet no player), botão de favorito e menu de opções no player e nas listas.
Pendente: letras, ajustes do equalizador de áudio, reordenar fila, tema claro, testes em vários aparelhos.

## Observação sobre o equalizador
A Visualizer API do Android exige a permissão RECORD_AUDIO mesmo analisando o áudio do próprio app.
Sem ela o app mostra aviso — não simula barras.
