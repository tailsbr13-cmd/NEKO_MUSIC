package br.neko.music.media

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class MediaScannerRulesTest {
    @Test fun videoRowsAreRecognized() {
        assertTrue(MediaScanner.looksLikeVideo("video/mp4", "/s/0/DCIM/Camera/VID_1.mp4"))
        assertTrue(MediaScanner.looksLikeVideo("", "/s/0/Movies/clip.MP4"))
        assertTrue(MediaScanner.looksLikeVideo("audio/mp4", "/s/0/Movies/clip.mp4"))
    }

    @Test fun musicIsNeverTreatedAsVideo() {
        assertFalse(MediaScanner.looksLikeVideo("audio/mpeg", "/s/0/Music/a.mp3"))
        assertFalse(MediaScanner.looksLikeVideo("audio/mp4", "/s/0/Music/a.m4a"))
        assertFalse(MediaScanner.looksLikeVideo("audio/flac", "/s/0/Music/a.flac"))
        assertFalse(MediaScanner.looksLikeVideo("audio/aac", "/s/0/Music/a.aac"))
    }
}
