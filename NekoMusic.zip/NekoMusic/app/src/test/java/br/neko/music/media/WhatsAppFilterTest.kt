package br.neko.music.media

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class WhatsAppFilterTest {
    @Test fun detectsWhatsAppFolders() {
        listOf(
            "/storage/emulated/0/WhatsApp/Media/WhatsApp Audio/AUD-20230510-WA0002.opus",
            "/storage/emulated/0/WhatsApp/Media/WhatsApp Voice Notes/202319/PTT-20230510-WA0001.opus",
            "/storage/emulated/0/WhatsApp Business/Media/WhatsApp Business Audio/AUD-20230510-WA0002.m4a",
            "/storage/emulated/0/Android/media/com.whatsapp/WhatsApp/Media/WhatsApp Audio/Sent/audio.mp3",
            "/storage/emulated/0/Android/media/com.whatsapp.w4b/WhatsApp Business/Media/WhatsApp Business Audio/x.opus",
        ).forEach { assertTrue(it, WhatsAppFilter.isWhatsAppPath(it)) }
    }

    @Test fun detectsWhatsAppFileNamesOutsideWhatsAppFolders() {
        assertTrue(WhatsAppFilter.isWhatsAppPath("/storage/emulated/0/Download/AUD-20230510-WA0002.mp3"))
        assertTrue(WhatsAppFilter.isWhatsAppPath("/storage/emulated/0/Download/aud-20230510-wa0002.opus"))
    }

    @Test fun keepsLegitimateMusic() {
        listOf(
            "/storage/emulated/0/Music/Artista/Faixa.mp3",
            "/storage/emulated/0/Download/Minha musica.flac",
            "/storage/emulated/0/Music/Unknown/track01.mp3",
            "/storage/emulated/0/Download/AUDIO-final-mix.wav",
            "/storage/emulated/0/Music/Podcast/AUD-notes.mp3",
        ).forEach { assertFalse(it, WhatsAppFilter.isWhatsAppPath(it)) }
    }
}
