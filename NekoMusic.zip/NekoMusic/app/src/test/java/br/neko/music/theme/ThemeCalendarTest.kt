package br.neko.music.theme

import br.neko.music.presentation.theme.FestiveCalendar
import br.neko.music.presentation.theme.ThemeMode
import br.neko.music.presentation.theme.ThemeResolver
import br.neko.music.presentation.theme.ThemeSettings
import br.neko.music.presentation.theme.ThemeSource
import java.time.LocalDate
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class ThemeCalendarTest {
    private fun d(y: Int, m: Int, day: Int) = LocalDate.of(y, m, day)
    private fun id(date: LocalDate, s: ThemeSettings = ThemeSettings()) = ThemeResolver.resolve(s, date).spec.id

    @Test fun easterDates() {
        assertEquals(d(2024, 3, 31), FestiveCalendar.easter(2024))
        assertEquals(d(2025, 4, 20), FestiveCalendar.easter(2025))
        assertEquals(d(2026, 4, 5), FestiveCalendar.easter(2026))
        assertEquals(d(2027, 3, 28), FestiveCalendar.easter(2027))
    }

    @Test fun carnivalFollowsEaster() {
        assertEquals(d(2025, 3, 4), FestiveCalendar.carnivalTuesday(2025))
        assertEquals(d(2026, 2, 17), FestiveCalendar.carnivalTuesday(2026))
        assertEquals(d(2027, 2, 9), FestiveCalendar.carnivalTuesday(2027))
        assertEquals("carnival", id(d(2026, 2, 13)))      // sexta
        assertEquals("carnival", id(d(2026, 2, 18)))      // quarta de cinzas
        assertEquals("blue", id(d(2026, 2, 12)))
        assertEquals("blue", id(d(2026, 2, 19)))
        assertEquals("carnival", id(d(2025, 3, 4)))       // outro ano, outra data
    }

    @Test fun easterWindow() {
        assertEquals("easter", id(d(2026, 3, 29)))        // Domingo de Ramos
        assertEquals("easter", id(d(2026, 4, 6)))         // segunda de Páscoa
        assertEquals("blue", id(d(2026, 4, 7)))
    }

    @Test fun newYearCrossesYearBoundary() {
        assertEquals("newyear", id(d(2026, 12, 31)))
        assertEquals("newyear", id(d(2027, 1, 3)))
        assertEquals("blue", id(d(2027, 1, 7)))
        assertEquals("christmas", id(d(2026, 12, 28)))
        assertEquals("newyear", id(d(2026, 12, 29)))
    }

    @Test fun fixedFestivities() {
        assertEquals("mothers", id(d(2026, 5, 10)))       // 2º domingo de maio de 2026
        assertEquals(d(2026, 5, 10), FestiveCalendar.mothersDay(2026))
        assertEquals("blue", id(d(2026, 5, 11)))
        assertEquals("junina", id(d(2026, 6, 3)))
        assertEquals("valentines", id(d(2026, 6, 12)))
        assertEquals("junina", id(d(2026, 6, 13)))
        assertEquals("winter", id(d(2026, 7, 15)))
        assertEquals("halloween", id(d(2026, 10, 31)))
        assertEquals("christmas", id(d(2026, 12, 25)))
    }

    @Test fun outsideFestivitiesUsesPermanent() {
        assertEquals("blue", id(d(2026, 11, 16)))
        assertEquals("neon", id(d(2026, 11, 16), ThemeSettings(permanentId = "neon")))
    }

    @Test fun manualModeAndSwitchIgnoreFestive() {
        val xmas = d(2026, 12, 25)
        assertEquals("dark", id(xmas, ThemeSettings(mode = ThemeMode.MANUAL, permanentId = "dark")))
        assertEquals("aero", id(xmas, ThemeSettings(festivalsEnabled = false, permanentId = "aero")))
        assertEquals("christmas", id(xmas, ThemeSettings(permanentId = "aero")))
    }

    @Test fun previewAndSimulatedDate() {
        val r = ThemeResolver.resolve(ThemeSettings(previewId = "halloween", mode = ThemeMode.MANUAL), d(2026, 1, 1))
        assertEquals("halloween", r.spec.id); assertEquals(ThemeSource.PREVIEW, r.source)
        val sim = ThemeResolver.resolve(ThemeSettings(simDate = d(2026, 12, 25)), d(2026, 11, 16))
        assertEquals("christmas", sim.spec.id); assertEquals(ThemeSource.FESTIVE, sim.source)
        assertNull(ThemeResolver.festiveOn(d(2026, 11, 16)))
    }

    @Test fun registryHasAllThemes() {
        val perm = listOf("blue", "aero", "neon", "pastel", "dark")
        val fest = listOf("newyear", "carnival", "easter", "mothers", "junina", "valentines", "winter", "halloween", "christmas")
        assertEquals(perm, br.neko.music.presentation.theme.Themes.permanent.map { it.id })
        assertEquals(fest, br.neko.music.presentation.theme.Themes.festive.map { it.spec.id })
        val all = perm + fest
        assertEquals(all.size, all.toSet().size)
        all.forEach { assertEquals(it, br.neko.music.presentation.theme.Themes.byId(it)?.id) }
    }

    @Test fun everyFestiveIsReachableEveryYear() {
        for (y in 2025..2032) br.neko.music.presentation.theme.Themes.festive.forEach { f ->
            val sample = f.spans(y).first().from
            assertEquals("${f.spec.id} $y", f.spec.id, id(sample))
        }
    }

    @Test fun previewDoesNotTouchSavedSettings() {
        val saved = ThemeSettings(permanentId = "neon")
        val previewing = saved.copy(previewId = "christmas")
        assertEquals("christmas", id(d(2026, 3, 1), previewing))
        assertEquals("neon", id(d(2026, 3, 1), previewing.copy(previewId = null)))   // sair restaura o anterior
    }
}
