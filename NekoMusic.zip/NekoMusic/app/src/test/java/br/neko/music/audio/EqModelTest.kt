package br.neko.music.audio

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class EqModelTest {
    @Test fun flatIsZeroEverywhere() {
        val flat = EqPreset.FLAT.gains!!
        for (hz in listOf(40f, 60f, 230f, 910f, 3600f, 14000f, 20000f)) assertEquals(0f, EqModel.gainAtHz(flat, hz), 1e-4f)
    }

    @Test fun exactBandFrequencyReturnsBandValue() {
        val g = listOf(1f, 2f, 3f, 4f, 5f, 6f, 7f)
        EqModel.FREQS.forEachIndexed { i, hz -> assertEquals(g[i], EqModel.gainAtHz(g, hz), 1e-3f) }
    }

    @Test fun bassBoostFavorsLowsOverHighs() {
        val g = EqPreset.BASS.gains!!
        assertTrue(EqModel.gainAtHz(g, 60f) > EqModel.gainAtHz(g, 3600f))
        assertTrue(EqModel.gainAtHz(g, 230f) > 0f)
    }

    @Test fun deviceLevelAddsPreampAndClamps() {
        val flat = EqPreset.FLAT.gains!!
        assertEquals(300, EqModel.deviceLevelMb(flat, 3f, 1000f, -1500, 1500))      // 3 dB = 300 mB
        assertEquals(1200, EqModel.deviceLevelMb(flat, 12f, 1000f, -1500, 1500))    // 12 dB = 1200 mB
        assertEquals(1000, EqModel.deviceLevelMb(flat, 12f, 1000f, -1500, 1000))    // limitado ao máximo do aparelho
        assertEquals(-1000, EqModel.deviceLevelMb(flat, -12f, 1000f, -1000, 1500))  // limitado ao mínimo do aparelho
    }

    @Test fun allPresetsHaveSevenBandsInRange() {
        for (p in EqPreset.values()) p.gains?.let {
            assertEquals(7, it.size)
            assertTrue(it.all { v -> v in EqModel.MIN_DB..EqModel.MAX_DB })
        }
    }
}
