package br.neko.music.presentation.theme

import android.content.Context
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import java.time.LocalDate

/** Cores já convertidas para Compose (uma única alocação por troca de tema). */
class NekoColors(p: Palette) {
    val electric = Color(p.electric); val deep = Color(p.deep); val navy = Color(p.navy)
    val cyan = Color(p.cyan); val ice = Color(p.ice); val steel = Color(p.steel)
    val background: Brush = Brush.verticalGradient(p.bg.map { Color(it) })
    val light = p.light
}

/**
 * Ponto central dos temas. Estado em Compose: quem lê [Neko].* recompõe sozinho quando o tema muda,
 * sem reiniciar a Activity nem o player. A data é relida ao voltar ao app e à meia-noite.
 */
object ThemeManager {
    private var prefs: android.content.SharedPreferences? = null

    var settings by mutableStateOf(ThemeSettings())
        private set
    private var realToday by mutableStateOf(LocalDate.now())

    val resolved: ResolvedTheme by derivedStateOf { ThemeResolver.resolve(settings, realToday) }
    val colors: NekoColors by derivedStateOf { NekoColors(resolved.spec.palette) }

    fun init(ctx: Context) {
        if (prefs != null) return
        val p = ctx.applicationContext.getSharedPreferences("neko_theme", Context.MODE_PRIVATE)
        prefs = p
        settings = ThemeSettings(
            mode = runCatching { ThemeMode.valueOf(p.getString("mode", "AUTO") ?: "AUTO") }.getOrDefault(ThemeMode.AUTO),
            permanentId = p.getString("permanent", Themes.blue.id) ?: Themes.blue.id,
            festivalsEnabled = p.getBoolean("festivals", true),
        )
        refreshDate()
    }

    /** Chamado ao abrir/retomar o app e à meia-noite: o tema festivo entra e sai sem depender do app aberto. */
    fun refreshDate() { realToday = LocalDate.now() }

    fun msUntilMidnight(): Long {
        val now = java.time.LocalDateTime.now()
        return java.time.Duration.between(now, now.toLocalDate().plusDays(1).atStartOfDay()).toMillis() + 1_000L
    }

    private fun save() = prefs?.edit()
        ?.putString("mode", settings.mode.name)?.putString("permanent", settings.permanentId)?.putBoolean("festivals", settings.festivalsEnabled)?.apply()

    fun setMode(m: ThemeMode) { settings = settings.copy(mode = m, previewId = null); save() }
    fun setPermanent(id: String) { settings = settings.copy(permanentId = id, previewId = null); save() }
    fun setFestivals(on: Boolean) { settings = settings.copy(festivalsEnabled = on, previewId = null); save() }
    fun preview(id: String?) { settings = settings.copy(previewId = id) }
    fun simulate(date: LocalDate?) { settings = settings.copy(simDate = date, previewId = null) }
    fun today(): LocalDate = settings.simDate ?: realToday
}
