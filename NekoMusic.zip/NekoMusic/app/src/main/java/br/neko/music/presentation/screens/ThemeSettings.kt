package br.neko.music.presentation.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import br.neko.music.presentation.theme.*
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

private val fmt = DateTimeFormatter.ofPattern("dd/MM/yyyy", Locale("pt", "BR"))

@Composable
private fun StatusLine() {
    val st = ThemeManager.settings
    val res = ThemeManager.resolved
    val label = when (res.source) {
        ThemeSource.PREVIEW -> "Visualização: ${res.spec.label}"
        ThemeSource.FESTIVE -> "Festivo automático: ${res.spec.label}"
        ThemeSource.PERMANENT -> if (st.mode == ThemeMode.AUTO) "Permanente: ${res.spec.label}" else "Manual: ${res.spec.label}"
    }
    Text("Tema ativo agora", color = Neko.SteelGray, fontSize = 12.sp)
    Text(label, color = Neko.Cyan, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
}

/** Grade de 2 colunas: todos os cartões ficam visíveis, sem rolagem horizontal escondida. */
@Composable
private fun ThemeGrid(items: List<ThemeSpec>, isSelected: (ThemeSpec) -> Boolean, onClick: (ThemeSpec) -> Unit) {
    items.chunked(2).forEach { row ->
        Row(Modifier.fillMaxWidth().padding(bottom = 10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            row.forEach { t -> Box(Modifier.weight(1f)) { ThemeCard(t, isSelected(t)) { onClick(t) } } }
            if (row.size == 1) Spacer(Modifier.weight(1f))
        }
    }
}

/** TEMAS PERMANENTES */
@Composable
fun ThemePermanentContent() {
    val st = ThemeManager.settings
    val previewing = ThemeManager.resolved.source == ThemeSource.PREVIEW
    ThemeGrid(Themes.permanent, { st.permanentId == it.id && !previewing }) { ThemeManager.setPermanent(it.id) }
}

/** TEMAS FESTIVOS (visualização temporária) */
@Composable
fun ThemeFestiveContent() {
    val st = ThemeManager.settings
    Text("Toque para ver o tema em todo o app. A visualização não é salva e não muda suas preferências.", color = Neko.SteelGray, fontSize = 12.sp)
    Spacer(Modifier.height(8.dp))
    ThemeGrid(Themes.festive.map { it.spec }, { st.previewId == it.id }) { ThemeManager.preview(if (st.previewId == it.id) null else it.id) }
    if (st.previewId != null) SmallButton("Sair da visualização") { ThemeManager.preview(null) }
}

/** AUTOMAÇÃO */
@Composable
fun ThemeAutomationContent() {
    val st = ThemeManager.settings
    StatusLine()
    Spacer(Modifier.height(12.dp))
    Text("Modo de tema", color = Neko.IceWhite, fontWeight = FontWeight.SemiBold)
    Spacer(Modifier.height(6.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Chip("AUTOMÁTICO", st.mode == ThemeMode.AUTO) { ThemeManager.setMode(ThemeMode.AUTO) }
        Chip("MANUAL", st.mode == ThemeMode.MANUAL) { ThemeManager.setMode(ThemeMode.MANUAL) }
    }
    Text(
        if (st.mode == ThemeMode.AUTO) "Acompanha as festividades; fora delas usa o tema permanente." else "Mantém sempre o tema que você escolheu.",
        color = Neko.SteelGray, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp),
    )
    Spacer(Modifier.height(10.dp))
    Row(verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text("Temas festivos automáticos", color = Neko.IceWhite)
            Text("Ano Novo, Carnaval, Páscoa, Natal e mais", color = Neko.SteelGray, fontSize = 12.sp)
        }
        Switch(st.festivalsEnabled, { ThemeManager.setFestivals(it) },
            colors = SwitchDefaults.colors(checkedTrackColor = Neko.Cyan, checkedThumbColor = Neko.Navy))
    }
}

/** Painel de desenvolvedor: só aparece depois de destravar (7 toques na versão, apenas em builds de debug). */
@Composable
fun ThemeDevContent() {
    val st = ThemeManager.settings
    val shown = ThemeManager.today()
    Text("Simulação de data (não altera a data do aparelho; some ao fechar o app)", color = Neko.SteelGray, fontSize = 12.sp)
    Text(
        (if (st.simDate != null) "Simulando: " else "Hoje: ") + shown.format(fmt) + (ThemeResolver.festiveOn(shown)?.let { " — ${it.spec.label}" } ?: ""),
        color = if (st.simDate != null) Neko.Cyan else Neko.SteelGray, fontFamily = FontFamily.Monospace, fontSize = 12.sp,
    )
    Spacer(Modifier.height(6.dp))
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        SmallButton("−30 d") { ThemeManager.simulate(shown.minusDays(30)) }
        SmallButton("−1 d") { ThemeManager.simulate(shown.minusDays(1)) }
        SmallButton("+1 d") { ThemeManager.simulate(shown.plusDays(1)) }
        SmallButton("+30 d") { ThemeManager.simulate(shown.plusDays(30)) }
        SmallButton("Carnaval") { ThemeManager.simulate(FestiveCalendar.carnivalTuesday(shown.year)) }
        SmallButton("Páscoa") { ThemeManager.simulate(FestiveCalendar.easter(shown.year)) }
        SmallButton("31/12") { ThemeManager.simulate(LocalDate.of(shown.year, 12, 31)) }
        SmallButton("Hoje") { ThemeManager.simulate(null) }
    }
    Spacer(Modifier.height(8.dp))
    SmallButton("Desativar modo desenvolvedor") { ThemeManager.setDevMode(false) }
}

/** Faixa flutuante exibida em QUALQUER tela enquanto uma visualização está ativa. */
@Composable
fun PreviewBanner(modifier: Modifier = Modifier) {
    val r = ThemeManager.resolved
    if (r.source != ThemeSource.PREVIEW) return
    val shape = RoundedCornerShape(20.dp)
    Row(
        modifier.clip(shape).background(Color.Black.copy(alpha = 0.75f)).border(1.dp, Neko.Cyan, shape)
            .clickable { ThemeManager.preview(null) }.padding(horizontal = 14.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text("Visualizando: ${r.spec.label}  ·  SAIR ✕", color = Color.White, fontFamily = FontFamily.Monospace, fontSize = 12.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun ThemeCard(spec: ThemeSpec, selected: Boolean, onClick: () -> Unit) {
    val p = spec.palette
    val shape = RoundedCornerShape(10.dp)
    Column(
        Modifier.fillMaxWidth().clip(shape)
            .background(Brush.verticalGradient(p.bg.map { Color(it) }))
            .border(BorderStroke(if (selected) 2.5.dp else 1.dp, if (selected) Neko.Cyan else Color(p.steel).copy(alpha = 0.5f)), shape)
            .clickable(onClick = onClick).padding(10.dp).heightIn(min = 72.dp),
    ) {
        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            listOf(p.electric, p.cyan, p.deep, p.ice).forEach { Box(Modifier.size(14.dp).clip(CircleShape).background(Color(it)).border(1.dp, Color.White.copy(alpha = 0.4f), CircleShape)) }
        }
        Spacer(Modifier.weight(1f))
        Text(spec.label, color = Color(p.ice), fontWeight = FontWeight.Bold, fontSize = 12.sp, maxLines = 2)
    }
}

@Composable
private fun Chip(text: String, selected: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(6.dp)
    Text(
        text, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 12.sp, letterSpacing = 1.sp,
        color = if (selected) Neko.Navy else Neko.IceWhite,
        modifier = Modifier.heightIn(min = 40.dp).clip(shape)
            .background(if (selected) Neko.Cyan else Neko.Electric.copy(alpha = 0.4f))
            .clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 10.dp),
    )
}

@Composable
private fun SmallButton(text: String, onClick: () -> Unit) {
    val shape = RoundedCornerShape(6.dp)
    Text(
        text, fontFamily = FontFamily.Monospace, fontSize = 12.sp, color = Neko.IceWhite,
        modifier = Modifier.clip(shape).background(Neko.Electric.copy(alpha = 0.35f)).border(1.dp, Neko.SteelGray.copy(alpha = 0.5f), shape)
            .clickable(onClick = onClick).padding(horizontal = 12.dp, vertical = 10.dp),
    )
}
