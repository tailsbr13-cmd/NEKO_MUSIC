package br.neko.music.media

import android.content.ContentUris
import android.content.Context
import android.database.Cursor
import android.media.MediaMetadataRetriever
import android.os.Build
import android.provider.MediaStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Lê a biblioteca via MediaStore (API oficial), fora da thread principal.
 * Duplicatas são removidas pelo caminho do arquivo.
 */
class MediaScanner(private val ctx: Context) {

    /**
     * @param includeMp4 false (padrão do app): vídeos/MP4 NÃO entram no índice — nem os da coleção de vídeo
     * nem linhas de vídeo que alguns aparelhos registram na coleção de áudio. true: o áudio de MP4 é indexado.
     */
    suspend fun scan(includeMp4: Boolean = false): List<Song> = withContext(Dispatchers.IO) {
        val out = LinkedHashMap<String, Song>()
        runCatching { queryAudio(out, includeMp4) }   // SecurityException (permissão negada) => lista vazia
        if (includeMp4) runCatching { queryMp4(out) }
        out.values.toList()
    }

    private fun queryAudio(out: MutableMap<String, Song>, includeMp4: Boolean) {
        val coll = if (Build.VERSION.SDK_INT >= 29) MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
        else MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val proj = arrayOf(
            MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM, MediaStore.Audio.Media.ALBUM_ID, MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.DATA, MediaStore.Audio.Media.DATE_ADDED, MediaStore.Audio.Media.DISPLAY_NAME, MediaStore.Audio.Media.MIME_TYPE,
        ) + (if (Build.VERSION.SDK_INT >= 29) arrayOf(MediaStore.Audio.Media.RELATIVE_PATH) else emptyArray())
        // Ignora toques, notificações e alarmes
        val sel = "${MediaStore.Audio.Media.DURATION} > 0 AND ${MediaStore.Audio.Media.IS_RINGTONE} = 0 AND " +
            "${MediaStore.Audio.Media.IS_NOTIFICATION} = 0 AND ${MediaStore.Audio.Media.IS_ALARM} = 0"
        ctx.contentResolver.query(coll, proj, sel, null, null)?.use { c ->
            while (c.moveToNext()) {
                val id = c.long(MediaStore.Audio.Media._ID)
                val path = c.str(MediaStore.Audio.Media.DATA).ifEmpty { fallbackPath(c) }
                // Arquivo de vídeo registrado como áudio: só entra se a opção de MP4 estiver ligada
                val mime = c.str(MediaStore.Audio.Media.MIME_TYPE).lowercase()
                if (looksLikeVideo(mime, path) && !includeMp4) continue
                out.putIfAbsent(path.ifEmpty { "a$id" }, Song(
                    id = id, uri = ContentUris.withAppendedId(coll, id),
                    title = c.str(MediaStore.Audio.Media.TITLE).ifBlank { path.substringAfterLast('/').substringBeforeLast('.') },
                    artist = clean(c.str(MediaStore.Audio.Media.ARTIST), "Artista desconhecido"),
                    album = clean(c.str(MediaStore.Audio.Media.ALBUM), "Álbum desconhecido"),
                    albumId = c.long(MediaStore.Audio.Media.ALBUM_ID),
                    durationMs = c.long(MediaStore.Audio.Media.DURATION),
                    path = path, dateAdded = c.long(MediaStore.Audio.Media.DATE_ADDED), fromVideo = false,
                ))
            }
        }
    }

    /** MP4 só entra se realmente tiver faixa de áudio. O vídeo nunca é exibido (trilha de vídeo desativada no player). */
    private fun queryMp4(out: MutableMap<String, Song>) {
        val coll = if (Build.VERSION.SDK_INT >= 29) MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
        else MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        val proj = arrayOf(
            MediaStore.Video.Media._ID, MediaStore.Video.Media.TITLE, MediaStore.Video.Media.ARTIST,
            MediaStore.Video.Media.DURATION, MediaStore.Video.Media.DATA, MediaStore.Video.Media.DATE_ADDED,
        )
        ctx.contentResolver.query(coll, proj, "${MediaStore.Video.Media.MIME_TYPE} = ? AND ${MediaStore.Video.Media.DURATION} > 0",
            arrayOf("video/mp4"), null)?.use { c ->
            while (c.moveToNext()) {
                val id = c.long(MediaStore.Video.Media._ID)
                val path = c.str(MediaStore.Video.Media.DATA)
                if (out.containsKey(path.ifEmpty { "v$id" })) continue
                val uri = ContentUris.withAppendedId(coll, id)
                if (!hasAudioTrack(uri)) continue
                out[path.ifEmpty { "v$id" }] = Song(
                    id = id, uri = uri,
                    title = c.str(MediaStore.Video.Media.TITLE).ifBlank { path.substringAfterLast('/').substringBeforeLast('.') },
                    artist = clean(c.str(MediaStore.Video.Media.ARTIST), "Artista desconhecido"),
                    album = "Arquivos MP4", albumId = -1,
                    durationMs = c.long(MediaStore.Video.Media.DURATION),
                    path = path, dateAdded = c.long(MediaStore.Video.Media.DATE_ADDED), fromVideo = true,
                )
            }
        }
    }

    private fun hasAudioTrack(uri: android.net.Uri): Boolean {
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(ctx, uri)
            r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_HAS_AUDIO) == "yes"
        } catch (e: Exception) { false } finally { runCatching { r.release() } }
    }

    /** Quando DATA vem vazio (Android 10+), monta o caminho com RELATIVE_PATH + nome (necessário para o filtro de pastas). */
    private fun fallbackPath(c: Cursor): String {
        if (Build.VERSION.SDK_INT < 29) return ""
        val name = c.str(MediaStore.Audio.Media.DISPLAY_NAME)
        return if (name.isEmpty()) "" else "/" + c.str(MediaStore.Audio.Media.RELATIVE_PATH) + name
    }

    companion object {
        /** Linha de vídeo (mime que começa com video/ ou extensão .mp4/.m4v). Áudio .m4a/.aac NÃO é afetado. */
        fun looksLikeVideo(mime: String, path: String): Boolean {
            val p = path.lowercase()
            return mime.lowercase().startsWith("video/") || p.endsWith(".mp4") || p.endsWith(".m4v")
        }
    }

    private fun clean(v: String, fallback: String) = if (v.isBlank() || v == "<unknown>") fallback else v
    private fun Cursor.str(col: String) = getString(getColumnIndexOrThrow(col)) ?: ""
    private fun Cursor.long(col: String) = getLong(getColumnIndexOrThrow(col))
}
