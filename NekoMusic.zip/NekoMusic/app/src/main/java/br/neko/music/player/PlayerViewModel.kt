package br.neko.music.player

import android.app.Application
import android.content.ComponentName
import android.database.ContentObserver
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import br.neko.music.media.MediaScanner
import br.neko.music.media.Permissions
import br.neko.music.data.database.*
import br.neko.music.media.Song
import android.app.RecoverableSecurityException
import android.content.IntentSender
import android.os.Build
import android.widget.Toast
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import br.neko.music.media.WhatsAppFilter
import android.content.Context
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import androidx.media3.common.Timeline
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import br.neko.music.visualizer.AudioVisualizerEngine
import com.google.common.util.concurrent.MoreExecutors
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/** Estado único do app: biblioteca + espelho do estado REAL do player (via MediaController). Sobrevive a mudanças de tela. */
class PlayerViewModel(app: Application) : AndroidViewModel(app) {
    private val scanner = MediaScanner(app)
    val visualizer = AudioVisualizerEngine()

    // Preferências simples (SharedPreferences, sem dependência extra)
    private val prefs = app.getSharedPreferences("neko_prefs", Context.MODE_PRIVATE)
    private val _showWhatsApp = MutableStateFlow(prefs.getBoolean(KEY_SHOW_WA, false)) // desligado por padrão
    val showWhatsApp: StateFlow<Boolean> = _showWhatsApp.asStateFlow()
    private val _showMp4 = MutableStateFlow(prefs.getBoolean(KEY_SHOW_MP4, false)) // desligado por padrão
    val showMp4: StateFlow<Boolean> = _showMp4.asStateFlow()

    /** Tudo o que o MediaStore devolveu. O filtro do WhatsApp é aplicado só na exibição (nada é apagado). */
    private val rawSongs = MutableStateFlow<List<Song>>(emptyList())
    val songs: StateFlow<List<Song>> = combine(rawSongs, _showWhatsApp) { all, show ->
        if (show) all else all.filterNot { WhatsAppFilter.isWhatsApp(it) }
    }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val whatsAppCount: StateFlow<Int> = rawSongs.map { l -> l.count { WhatsAppFilter.isWhatsApp(it) } }
        .stateIn(viewModelScope, SharingStarted.Eagerly, 0)
    private val _scanning = MutableStateFlow(false); val scanning = _scanning.asStateFlow()
    private val _scanned = MutableStateFlow(false); val scanned = _scanned.asStateFlow()
    private val _current = MutableStateFlow<Song?>(null); val current = _current.asStateFlow()
    private val _playing = MutableStateFlow(false); val playing = _playing.asStateFlow()
    private val _position = MutableStateFlow(0L); val position = _position.asStateFlow()
    private val _duration = MutableStateFlow(0L); val duration = _duration.asStateFlow()
    private val _shuffle = MutableStateFlow(false); val shuffle = _shuffle.asStateFlow()
    private val _repeat = MutableStateFlow(Player.REPEAT_MODE_OFF); val repeat = _repeat.asStateFlow()
    private val _sessionId = MutableStateFlow<Int?>(null); val audioSessionId = _sessionId.asStateFlow()
    private val _error = MutableStateFlow<String?>(null); val error = _error.asStateFlow()
    private val _queue = MutableStateFlow<List<Song>>(emptyList()); val queue = _queue.asStateFlow()
    /** true = o player está tocando de verdade (ou carregando a próxima faixa com "tocar" ligado). Pausa/parada/fim => false. */
    private val _active = MutableStateFlow(false); val playbackActive: StateFlow<Boolean> = _active.asStateFlow()
    private val _queueIndex = MutableStateFlow(0); val queueIndex = _queueIndex.asStateFlow()

    // Persistência local (Room): favoritos e playlists continuam salvos depois de fechar o app
    private val dao = NekoDatabase.get(app).dao()
    val favoriteKeys: StateFlow<List<String>> = dao.favoriteKeys().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val playlists: StateFlow<List<PlaylistSummary>> = dao.playlists().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    fun playlistKeys(id: Long): Flow<List<String>> = dao.playlistKeys(id)

    private var byKey: Map<String, Song> = emptyMap()
    private var controller: MediaController? = null
    private var scanJob: Job? = null
    private var observerJob: Job? = null

    // Detecta músicas novas no aparelho e atualiza a biblioteca (com debounce)
    private val observer = object : ContentObserver(Handler(Looper.getMainLooper())) {
        override fun onChange(selfChange: Boolean) {
            observerJob?.cancel()
            observerJob = viewModelScope.launch { delay(1500); refresh() }
        }
    }

    private val listener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) { _playing.value = isPlaying; syncCurrent(); updateActive() }
        override fun onPlayWhenReadyChanged(playWhenReady: Boolean, reason: Int) { updateActive() }
        override fun onMediaItemTransition(item: MediaItem?, reason: Int) { syncCurrent() }
        override fun onPlaybackStateChanged(state: Int) { syncCurrent(); updateActive() }
        override fun onShuffleModeEnabledChanged(enabled: Boolean) { _shuffle.value = enabled }
        override fun onTimelineChanged(timeline: Timeline, reason: Int) { syncQueue() }
        override fun onRepeatModeChanged(mode: Int) { _repeat.value = mode }
        override fun onPlayerError(e: PlaybackException) {
            // Arquivo inválido/incompatível: avisa e pula para a próxima faixa
            _error.value = "Não foi possível reproduzir \"${_current.value?.title ?: "este arquivo"}\"."
            controller?.let { if (it.hasNextMediaItem()) { it.seekToNextMediaItem(); it.prepare(); it.play() } }
        }
    }

    init {
        connect()
        app.contentResolver.registerContentObserver(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, true, observer)
        viewModelScope.launch {
            while (true) { controller?.let { if (it.isPlaying) _position.value = it.currentPosition }; delay(if (_playing.value) 250 else 1000) }
        }
        refresh()
    }

    private fun connect() {
        val app = getApplication<Application>()
        val token = SessionToken(app, ComponentName(app, PlaybackService::class.java))
        val future = MediaController.Builder(app, token).buildAsync()
        future.addListener({
            val c = runCatching { future.get() }.getOrNull() ?: return@addListener
            controller = c
            c.addListener(listener)
            _shuffle.value = c.shuffleModeEnabled; _repeat.value = c.repeatMode; _playing.value = c.isPlaying
            _sessionId.value = c.sessionExtras.getInt(PlaybackService.KEY_AUDIO_SESSION, -1).takeIf { it > 0 }
            syncCurrent(); syncQueue(); updateActive()
        }, MoreExecutors.directExecutor())
    }

    fun refresh() {
        if (!Permissions.hasLibrary(getApplication())) return
        if (scanJob?.isActive == true) return
        scanJob = viewModelScope.launch {
            _scanning.value = true
            try {
                val result = scanner.scan(includeMp4 = _showMp4.value)
                rawSongs.value = result; byKey = result.associateBy { it.key }
                _scanned.value = true
                syncCurrent(); syncQueue()
            } finally {
                _scanning.value = false // também ao cancelar uma varredura em andamento
            }
        }
    }

    private fun syncCurrent() {
        val c = controller ?: return
        val item = c.currentMediaItem
        // Se a Activity foi recriada enquanto o serviço toca, reconstrói a faixa pelos metadados (sem esperar a varredura)
        val s = item?.mediaId?.let { byKey[it] } ?: item?.let { songFromItem(it) }
        _current.value = s
        _duration.value = if (c.duration > 0) c.duration else s?.durationMs ?: 0L
        _position.value = c.currentPosition.coerceAtLeast(0)
        _queueIndex.value = c.currentMediaItemIndex
    }

    /** Define a fila com a lista exibida na tela e começa a tocar a faixa escolhida. */
    fun play(list: List<Song>, index: Int) {
        val c = controller ?: return
        _error.value = null
        c.setMediaItems(list.map { it.toMediaItem() }, index, 0L)
        c.prepare(); c.play()
    }

    fun togglePlay() {
        val c = controller ?: return
        if (c.isPlaying) c.pause() else { if (c.playbackState == Player.STATE_IDLE) c.prepare(); c.play() }
    }
    fun next() { controller?.seekToNext() }
    fun previous() { controller?.seekToPrevious() }
    fun seekTo(ms: Long) { controller?.seekTo(ms); _position.value = ms }
    fun toggleShuffle() { controller?.let { it.shuffleModeEnabled = !it.shuffleModeEnabled } }
    /** Desligado -> repetir playlist -> repetir música */
    fun cycleRepeat() {
        controller?.let {
            it.repeatMode = when (it.repeatMode) {
                Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                else -> Player.REPEAT_MODE_OFF
            }
        }
    }
    fun dismissError() { _error.value = null }

    /** A opção muda o que é INDEXADO: salva, cancela a varredura atual e reindexa. */
    fun setShowMp4(show: Boolean) {
        prefs.edit().putBoolean(KEY_SHOW_MP4, show).apply()
        _showMp4.value = show
        scanJob?.cancel()
        refresh()
    }

    // ================= Exclusão de músicas (Scoped Storage) =================
    /** Pedido de autorização do sistema que a UI precisa abrir (Android 10+). */
    data class DeleteRequest(val song: Song, val sender: IntentSender)
    private val _deleteRequest = MutableStateFlow<DeleteRequest?>(null)
    val deleteRequest: StateFlow<DeleteRequest?> = _deleteRequest.asStateFlow()

    private fun toast(msg: String) = Toast.makeText(getApplication<Application>().applicationContext, msg, Toast.LENGTH_LONG).show()

    private fun exists(song: Song): Boolean = try {
        getApplication<Application>().contentResolver.query(song.uri, arrayOf(android.provider.MediaStore.MediaColumns._ID), null, null, null)
            ?.use { it.count > 0 } ?: false
    } catch (e: Exception) { false }

    /** Chamado só depois da confirmação explícita do usuário. Exclui APENAS o arquivo desta faixa (uri exata). */
    fun requestDelete(song: Song) {
        viewModelScope.launch {
            val resolver = getApplication<Application>().contentResolver
            try {
                if (Build.VERSION.SDK_INT >= 30) {
                    // Android 11+: o sistema pede a autorização e apaga o arquivo
                    val pi = android.provider.MediaStore.createDeleteRequest(resolver, listOf(song.uri))
                    _deleteRequest.value = DeleteRequest(song, pi.intentSender)
                } else {
                    withContext(Dispatchers.IO) { resolver.delete(song.uri, null, null) }
                    finishDelete(song)
                }
            } catch (e: SecurityException) {
                if (Build.VERSION.SDK_INT >= 29 && e is RecoverableSecurityException) {
                    // Android 10: pede autorização para este arquivo e tenta de novo
                    _deleteRequest.value = DeleteRequest(song, e.userAction.actionIntent.intentSender)
                } else toast("Não foi possível excluir: o Android negou a permissão de gravação neste arquivo.")
            } catch (e: Exception) {
                toast("Não foi possível excluir a música: ${e.message ?: "erro desconhecido"}")
            }
        }
    }

    /** Resultado da tela de autorização do sistema. */
    fun onDeleteResult(approved: Boolean) {
        val req = _deleteRequest.value ?: return
        _deleteRequest.value = null
        if (!approved) { toast("Exclusão cancelada. O arquivo foi mantido."); return }
        viewModelScope.launch {
            if (Build.VERSION.SDK_INT == 29) {
                // No Android 10 a autorização não apaga: repete a exclusão agora que há permissão
                runCatching { withContext(Dispatchers.IO) { getApplication<Application>().contentResolver.delete(req.song.uri, null, null) } }
            }
            finishDelete(req.song)
        }
    }

    /** Só remove da biblioteca se o arquivo realmente sumiu do armazenamento. */
    private suspend fun finishDelete(song: Song) {
        val gone = withContext(Dispatchers.IO) { !exists(song) }
        if (!gone) { toast("Não foi possível excluir \"${song.title}\". O arquivo continua no aparelho."); return }
        rawSongs.value = rawSongs.value.filterNot { it.key == song.key }
        byKey = byKey - song.key
        dao.removeFavorite(song.key); dao.removeFromAllPlaylists(song.key)
        controller?.let { c -> for (i in c.mediaItemCount - 1 downTo 0) if (c.getMediaItemAt(i).mediaId == song.key) c.removeMediaItem(i) }
        syncCurrent(); syncQueue()
        toast("Música excluída.")
    }

    fun setShowWhatsApp(show: Boolean) {
        prefs.edit().putBoolean(KEY_SHOW_WA, show).apply()
        _showWhatsApp.value = show
    }

    private fun updateActive() {
        val c = controller ?: return
        _active.value = c.playWhenReady && (c.playbackState == Player.STATE_READY || c.playbackState == Player.STATE_BUFFERING)
    }

    private fun syncQueue() {
        val c = controller ?: return
        _queue.value = (0 until c.mediaItemCount).mapNotNull { val m = c.getMediaItemAt(it); byKey[m.mediaId] ?: songFromItem(m) }
        _queueIndex.value = c.currentMediaItemIndex
    }
    /** Pula para um item da fila de reprodução. */
    fun playQueueIndex(i: Int) { controller?.let { it.seekTo(i, 0L); it.play() } }

    // ----- Favoritos -----
    fun toggleFavorite(song: Song) = viewModelScope.launch {
        if (song.key in favoriteKeys.value) dao.removeFavorite(song.key)
        else dao.addFavorite(FavoriteEntity(song.key, System.currentTimeMillis()))
    }

    // ----- Playlists -----
    /** Cria a playlist e, se informado, já adiciona a música. */
    fun createPlaylist(name: String, thenAdd: Song? = null) = viewModelScope.launch {
        val id = dao.insertPlaylist(PlaylistEntity(name = name.trim(), createdAt = System.currentTimeMillis()))
        thenAdd?.let { dao.addToPlaylist(PlaylistSongEntity(id, it.key, System.currentTimeMillis())) }
    }
    fun renamePlaylist(id: Long, name: String) = viewModelScope.launch { dao.renamePlaylist(id, name.trim()) }
    fun deletePlaylist(id: Long) = viewModelScope.launch { dao.deletePlaylist(id) }
    fun addToPlaylist(id: Long, song: Song) = viewModelScope.launch { dao.addToPlaylist(PlaylistSongEntity(id, song.key, System.currentTimeMillis())) }
    fun removeFromPlaylist(id: Long, song: Song) = viewModelScope.launch { dao.removeFromPlaylist(id, song.key) }

    private fun Song.toMediaItem(): MediaItem = MediaItem.Builder()
        .setMediaId(key)
        .setRequestMetadata(MediaItem.RequestMetadata.Builder().setMediaUri(uri).build())
        .setUri(uri)
        .setMediaMetadata(
            MediaMetadata.Builder().setTitle(title).setArtist(artist).setAlbumTitle(album)
                .setArtworkUri(ArtUri.build(this))   // o NekoBitmapLoader resolve a capa (e o display Y2K) a partir daqui
                .setExtras(toExtras())
                .build()
        ).build()

    private fun Song.toExtras() = android.os.Bundle().apply {
        putLong("neko_id", id); putString("neko_uri", uri.toString()); putLong("neko_album_id", albumId)
        putLong("neko_duration", durationMs); putString("neko_path", path); putLong("neko_date", dateAdded)
        putBoolean("neko_video", fromVideo)
    }

    private fun songFromItem(item: MediaItem): Song? {
        val md = item.mediaMetadata
        val ex = md.extras ?: return null
        val u = ex.getString("neko_uri") ?: return null
        return Song(
            id = ex.getLong("neko_id"), uri = Uri.parse(u), title = md.title?.toString() ?: "", artist = md.artist?.toString() ?: "",
            album = md.albumTitle?.toString() ?: "", albumId = ex.getLong("neko_album_id"), durationMs = ex.getLong("neko_duration"),
            path = ex.getString("neko_path") ?: "", dateAdded = ex.getLong("neko_date"), fromVideo = ex.getBoolean("neko_video"),
        )
    }

    override fun onCleared() {
        getApplication<Application>().contentResolver.unregisterContentObserver(observer)
        visualizer.stop()
        controller?.release()
        super.onCleared()
    }
}

private const val KEY_SHOW_WA = "show_whatsapp"
private const val KEY_SHOW_MP4 = "show_mp4"
