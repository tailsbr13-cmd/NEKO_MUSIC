package br.neko.music.presentation.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import android.Manifest
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.automirrored.filled.QueueMusic
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.media3.common.Player
import br.neko.music.media.Permissions
import br.neko.music.player.PlayerViewModel
import br.neko.music.presentation.components.AudioVisualizer
import br.neko.music.presentation.components.CoverArt
import br.neko.music.presentation.components.SongRow
import br.neko.music.presentation.components.formatTime
import br.neko.music.presentation.theme.Neko
import br.neko.music.visualizer.AudioVisualizerEngine

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PlayerScreen(vm: PlayerViewModel, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val song by vm.current.collectAsStateWithLifecycle()
    val playing by vm.playing.collectAsStateWithLifecycle()
    val position by vm.position.collectAsStateWithLifecycle()
    val durationState by vm.duration.collectAsStateWithLifecycle()
    val shuffle by vm.shuffle.collectAsStateWithLifecycle()
    val repeat by vm.repeat.collectAsStateWithLifecycle()
    val sessionId by vm.audioSessionId.collectAsStateWithLifecycle()
    val vizStatus by vm.visualizer.status.collectAsStateWithLifecycle()

    var micGranted by remember { mutableStateOf(Permissions.hasMic(ctx)) }
    val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { micGranted = it }

    // O visualizador só existe enquanto a tela do player está aberta (economiza bateria)
    DisposableEffect(sessionId, micGranted) {
        sessionId?.let { vm.visualizer.start(ctx, it) }
        onDispose { vm.visualizer.stop() }
    }

    val favKeys by vm.favoriteKeys.collectAsStateWithLifecycle()
    val queue by vm.queue.collectAsStateWithLifecycle()
    val queueIndex by vm.queueIndex.collectAsStateWithLifecycle()
    var showQueue by remember { mutableStateOf(false) }
    var showMenu by remember { mutableStateOf(false) }
    val isFav = song?.key?.let { it in favKeys } ?: false

    val duration = if (durationState > 0) durationState else song?.durationMs ?: 0L
    var dragging by remember { mutableStateOf<Float?>(null) }
    val progress = dragging ?: if (duration > 0) (position.toFloat() / duration).coerceIn(0f, 1f) else 0f

    Column(
        Modifier.fillMaxSize().background(Neko.Background).statusBarsPadding().navigationBarsPadding()
            .verticalScroll(rememberScrollState()).padding(horizontal = 20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClose) { Icon(Icons.Filled.KeyboardArrowDown, "Fechar player", tint = Neko.IceWhite, modifier = Modifier.size(30.dp)) }
            Text("AGORA TOCANDO", Modifier.weight(1f), color = Neko.Cyan, fontFamily = FontFamily.Monospace, fontSize = 12.sp,
                letterSpacing = 3.sp, textAlign = TextAlign.Center)
            IconButton({ song?.let(vm::toggleFavorite) }, Modifier.size(38.dp)) {
                Icon(if (isFav) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder, "Favoritar", tint = if (isFav) Neko.Cyan else Neko.IceWhite)
            }
            IconButton({ showQueue = true }, Modifier.size(38.dp)) { Icon(Icons.AutoMirrored.Filled.QueueMusic, "Fila de reprodução", tint = Neko.IceWhite) }
            IconButton({ showMenu = true }, Modifier.size(38.dp)) { Icon(Icons.Filled.MoreVert, "Mais opções", tint = Neko.IceWhite) }
        }

        // Capa em destaque com reflexo "vidro"
        val coverShape = RoundedCornerShape(8.dp)
        Box(Modifier.fillMaxWidth().aspectRatio(1f).padding(vertical = 8.dp).clip(coverShape).border(2.dp, Neko.Cyan.copy(alpha = 0.6f), coverShape)) {
            CoverArt(song, Modifier.fillMaxSize(), px = 768)
            Box(Modifier.fillMaxWidth().fillMaxHeight(0.42f).background(Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.20f), Color.Transparent))))
        }

        Spacer(Modifier.height(8.dp))
        Text(song?.title ?: "—", color = Neko.IceWhite, fontWeight = FontWeight.Bold, fontSize = 22.sp, maxLines = 2, textAlign = TextAlign.Center)
        Text(song?.artist ?: "", color = Neko.SteelGray, fontSize = 15.sp, maxLines = 1)

        // Equalizador real
        Spacer(Modifier.height(14.dp))
        val vizShape = RoundedCornerShape(6.dp)
        Box(Modifier.fillMaxWidth().height(104.dp).clip(vizShape).background(Neko.Navy.copy(alpha = 0.85f))
            .border(1.dp, Neko.SteelGray.copy(alpha = 0.4f), vizShape).padding(10.dp), contentAlignment = Alignment.Center) {
            AudioVisualizer(vm.visualizer, active = playing && vizStatus == AudioVisualizerEngine.Status.ACTIVE, modifier = Modifier.fillMaxSize())
            if (vizStatus == AudioVisualizerEngine.Status.NO_PERMISSION || !micGranted) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("O equalizador precisa de permissão de áudio do Android (o app não grava o microfone).", color = Neko.IceWhite, fontSize = 11.sp, textAlign = TextAlign.Center)
                    TextButton({ micLauncher.launch(Manifest.permission.RECORD_AUDIO) }) { Text("ATIVAR EQUALIZADOR", color = Neko.Cyan, fontFamily = FontFamily.Monospace, fontSize = 12.sp) }
                }
            } else if (vizStatus == AudioVisualizerEngine.Status.ERROR) {
                Text("Equalizador indisponível neste aparelho.", color = Neko.SteelGray, fontSize = 12.sp)
            }
        }

        // Progresso
        Spacer(Modifier.height(10.dp))
        Slider(
            value = progress,
            onValueChange = { dragging = it },
            onValueChangeFinished = { dragging?.let { vm.seekTo((it * duration).toLong()) }; dragging = null },
            colors = SliderDefaults.colors(thumbColor = Neko.Cyan, activeTrackColor = Neko.Cyan, inactiveTrackColor = Neko.Deep),
        )
        Row(Modifier.fillMaxWidth()) {
            Text(formatTime((progress * duration).toLong()), color = Neko.SteelGray, fontFamily = FontFamily.Monospace, fontSize = 12.sp)
            Spacer(Modifier.weight(1f))
            Text(formatTime(duration), color = Neko.SteelGray, fontFamily = FontFamily.Monospace, fontSize = 12.sp)
        }

        // Controles
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth().padding(bottom = 24.dp), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
            IconButton(vm::toggleShuffle) { Icon(Icons.Filled.Shuffle, "Aleatório", tint = if (shuffle) Neko.Cyan else Neko.SteelGray) }
            IconButton(vm::previous) { Icon(Icons.Filled.SkipPrevious, "Anterior", tint = Neko.IceWhite, modifier = Modifier.size(36.dp)) }
            Box(
                Modifier.size(72.dp).clip(CircleShape)
                    .background(Brush.verticalGradient(listOf(Color.White, Neko.Cyan, Neko.Electric)))
                    .border(2.dp, Neko.IceWhite.copy(alpha = 0.8f), CircleShape),
                contentAlignment = Alignment.Center,
            ) {
                IconButton(vm::togglePlay, Modifier.fillMaxSize()) {
                    Icon(if (playing) Icons.Filled.Pause else Icons.Filled.PlayArrow, if (playing) "Pausar" else "Reproduzir", tint = Neko.Navy, modifier = Modifier.size(38.dp))
                }
            }
            IconButton(vm::next) { Icon(Icons.Filled.SkipNext, "Próxima", tint = Neko.IceWhite, modifier = Modifier.size(36.dp)) }
            IconButton(vm::cycleRepeat) {
                Icon(if (repeat == Player.REPEAT_MODE_ONE) Icons.Filled.RepeatOne else Icons.Filled.Repeat,
                    when (repeat) { Player.REPEAT_MODE_ONE -> "Repetir música"; Player.REPEAT_MODE_ALL -> "Repetir playlist"; else -> "Repetição desligada" },
                    tint = if (repeat == Player.REPEAT_MODE_OFF) Neko.SteelGray else Neko.Cyan)
            }
        }
    }

    if (showQueue) {
        ModalBottomSheet(onDismissRequest = { showQueue = false }, containerColor = Neko.Deep) {
            Text("FILA DE REPRODUÇÃO", color = Neko.Cyan, fontFamily = FontFamily.Monospace, fontSize = 12.sp, letterSpacing = 2.sp,
                modifier = Modifier.padding(horizontal = 18.dp, vertical = 6.dp))
            val state = rememberLazyListState(queueIndex.coerceAtLeast(0))
            LazyColumn(Modifier.heightIn(max = 480.dp), state = state) {
                itemsIndexed(queue) { i, s -> SongRow(s, i == queueIndex) { vm.playQueueIndex(i) } }
            }
        }
    }
    if (showMenu) song?.let { SongActionsDialog(vm, it, null) { showMenu = false } }
}
