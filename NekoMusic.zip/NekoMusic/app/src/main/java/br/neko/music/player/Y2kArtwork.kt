package br.neko.music.player

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import androidx.core.graphics.ColorUtils
import br.neko.music.R

/**
 * Gera a CAPA que o Android mostra no cartão de mídia e na tela de bloqueio (única parte visual
 * que o app controla nesses locais): a capa do álbum dentro de um "display de mini system" dos anos 2000.
 * Sem capa, desenha um display completo do NEKO MUSIC (logo + barras + progresso). Elementos decorativos
 * (barras/segmentos) são estáticos — o Android não permite animação nem texto dinâmico nesse cartão.
 */
object Y2kArtwork {
    private const val S = 512
    private val CYAN = 0xFF69EAD8.toInt()
    private val ELECTRIC = 0xFF1749D8.toInt()
    private val DEEP = 0xFF102B83.toInt()
    private val NAVY = 0xFF080F26.toInt()
    private val ICE = 0xFFEAF4FF.toInt()
    private val STEEL = 0xFF879BBF.toInt()
    private val PURPLE = 0xFF9B6BFF.toInt()
    private val MONO = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)

    fun frame(ctx: Context, cover: Bitmap?): Bitmap {
        val out = Bitmap.createBitmap(S, S, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        val full = S.toFloat()

        // 1) corpo prateado do aparelho
        p.shader = LinearGradient(0f, 0f, 0f, full, intArrayOf(0xFFF2F5FA.toInt(), 0xFFB9C3D8.toInt(), 0xFF7E8BAA.toInt()), floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP)
        c.drawRoundRect(RectF(0f, 0f, full, full), 44f, 44f, p)

        // 2) tela (LCD)
        val lcd = RectF(16f, 16f, full - 16f, full - 16f)
        p.shader = LinearGradient(0f, lcd.top, 0f, lcd.bottom, DEEP, NAVY, Shader.TileMode.CLAMP)
        c.drawRoundRect(lcd, 30f, 30f, p)
        p.shader = null

        c.save()
        c.clipPath(Path().apply { addRoundRect(lcd, 30f, 30f, Path.Direction.CW) })
        if (cover != null) { drawCover(c, cover, lcd); drawStrip(c, lcd) } else drawDisplay(ctx, c, lcd)

        // reflexo de vidro no topo
        p.shader = LinearGradient(0f, lcd.top, 0f, lcd.top + lcd.height() * 0.4f, 0x44FFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP)
        c.drawRect(lcd.left, lcd.top, lcd.right, lcd.top + lcd.height() * 0.4f, p)
        p.shader = null
        c.restore()

        // borda neon (roxo suave por fora, ciano por dentro)
        p.style = Paint.Style.STROKE
        p.strokeWidth = 8f; p.color = ColorUtils.setAlphaComponent(PURPLE, 70)
        c.drawRoundRect(lcd, 30f, 30f, p)
        p.strokeWidth = 3f; p.color = ColorUtils.setAlphaComponent(CYAN, 220)
        c.drawRoundRect(lcd, 30f, 30f, p)
        return out
    }

    private fun drawCover(c: Canvas, cover: Bitmap, dst: RectF) {
        val side = minOf(cover.width, cover.height)
        val src = Rect((cover.width - side) / 2, (cover.height - side) / 2, (cover.width + side) / 2, (cover.height + side) / 2)
        c.drawBitmap(cover, src, dst, Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG))
    }

    /** Faixa inferior sobre a capa: nome do aparelho + LEDs. */
    private fun drawStrip(c: Canvas, lcd: RectF) {
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        val top = lcd.bottom - 62f
        p.shader = LinearGradient(0f, top, 0f, lcd.bottom, 0x00080F26, 0xEB080F26.toInt(), Shader.TileMode.CLAMP)
        c.drawRect(lcd.left, top, lcd.right, lcd.bottom, p)
        p.shader = null
        text(c, "NEKO MUSIC", lcd.left + 24f, lcd.bottom - 22f, 26f, CYAN)
        for (i in 0 until 6) {
            p.color = ColorUtils.blendARGB(CYAN, PURPLE, i / 5f)
            p.alpha = if (i % 2 == 0) 255 else 150
            val x = lcd.right - 24f - (6 - i) * 20f
            c.drawRoundRect(RectF(x, lcd.bottom - 40f, x + 14f, lcd.bottom - 20f), 3f, 3f, p)
        }
    }

    /** Display completo (sem capa), no estilo do painel de referência: cabeçalho, logo, barras e progresso. */
    private fun drawDisplay(ctx: Context, c: Canvas, lcd: RectF) {
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        // cabeçalho azul com setas
        p.shader = LinearGradient(0f, lcd.top, 0f, lcd.top + 58f, ELECTRIC, DEEP, Shader.TileMode.CLAMP)
        c.drawRect(lcd.left, lcd.top, lcd.right, lcd.top + 58f, p); p.shader = null
        p.color = ICE
        c.drawPath(Path().apply { moveTo(64f, 45f); lineTo(88f, 31f); lineTo(88f, 59f); close() }, p)
        c.drawPath(Path().apply { moveTo(120f, 45f); lineTo(96f, 31f); lineTo(96f, 59f); close() }, p)
        text(c, "NEKO MUSIC", 168f, 56f, 30f, ICE)

        // logo em moldura
        val box = RectF(40f, 96f, 236f, 292f)
        p.color = ELECTRIC; c.drawRect(box, p)
        BitmapFactory.decodeResource(ctx.resources, R.drawable.neko_logo)?.let {
            c.drawBitmap(it, Rect(0, 0, it.width, it.height), box, Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG))
        }
        p.style = Paint.Style.STROKE; p.strokeWidth = 3f; p.color = CYAN; c.drawRect(box, p); p.style = Paint.Style.FILL

        // barras segmentadas (decorativas)
        val heights = floatArrayOf(0.38f, 0.62f, 0.48f, 0.92f, 0.72f, 0.52f, 0.84f, 0.42f, 0.68f, 0.96f, 0.58f, 0.34f)
        val left = 262f; val right = 478f; val top = 100f; val bottom = 296f
        val n = heights.size; val barW = (right - left - 4f * (n - 1)) / n
        val cell = 7f; val gap = 2.5f
        val maxRows = ((bottom - top) / (cell + gap)).toInt()
        for (i in 0 until n) {
            val rows = (maxRows * heights[i]).toInt()
            for (r in 0 until rows) {
                val y = bottom - (r + 1) * cell - r * gap
                p.color = if (r == rows - 1) ICE else ColorUtils.blendARGB(CYAN, PURPLE, r / maxRows.toFloat())
                c.drawRect(left + i * (barW + 4f), y, left + i * (barW + 4f) + barW, y + cell, p)
            }
        }

        text(c, "TRACK:", 40f, 336f, 20f, STEEL)
        text(c, "NEKO MUSIC", 124f, 336f, 26f, ICE)
        text(c, "TRACK PROGRESS:", 40f, 382f, 18f, STEEL)
        // segmentos de progresso (decorativos)
        for (i in 0 until 20) {
            val x = 40f + i * 22.6f
            if (i < 11) { p.style = Paint.Style.FILL; p.color = ColorUtils.blendARGB(CYAN, PURPLE, i / 10f) }
            else { p.style = Paint.Style.STROKE; p.strokeWidth = 2f; p.color = ColorUtils.setAlphaComponent(STEEL, 140) }
            c.drawRect(x, 396f, x + 17f, 420f, p)
        }
        p.style = Paint.Style.FILL
    }

    private fun text(c: Canvas, s: String, x: Float, y: Float, size: Float, color: Int) {
        val t = Paint(Paint.ANTI_ALIAS_FLAG)
        t.typeface = MONO; t.textSize = size; t.color = color; t.letterSpacing = 0.08f
        t.setShadowLayer(10f, 0f, 0f, CYAN)
        c.drawText(s, x, y, t)
    }
}
