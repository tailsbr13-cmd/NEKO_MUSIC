package br.neko.music.presentation.theme

import java.time.DayOfWeek
import java.time.LocalDate

/*
 * Parte PURA do sistema de temas (sem Compose, sem Android): paletas, calendário festivo e resolução
 * do tema ativo. É testável na JVM e independente da interface. Para criar um novo tema festivo basta
 * acrescentar um item em [Themes.festive]; nada mais no app precisa mudar.
 */

/** Cores como ARGB (Long). Os tokens têm o mesmo papel que na paleta BLUE original. */
data class Palette(
    val electric: Long,   // preenchimentos de botões/abas
    val deep: Long,       // superfícies e trilhos
    val navy: Long,       // base escura (ou texto sobre o destaque, em temas claros)
    val cyan: Long,       // cor de destaque
    val ice: Long,        // texto/ícones principais
    val steel: Long,      // texto secundário
    val bg: List<Long>,   // gradiente de fundo (cima -> baixo)
    val light: Boolean = false,
)

/** Efeito decorativo desenhado atrás do conteúdo (sempre leve e sem interceptar toques). */
enum class Decor { NONE, BUBBLES, NEON_SPARK, FIREWORKS, CONFETTI, EGGS, PETALS, BUNTING, HEARTS, SNOW, BATS, XMAS }

data class ThemeSpec(val id: String, val label: String, val blurb: String, val palette: Palette, val decor: Decor)

data class DateSpan(val from: LocalDate, val to: LocalDate) {
    operator fun contains(d: LocalDate) = !d.isBefore(from) && !d.isAfter(to)
}

/** Tema festivo: [spans] devolve os períodos que COMEÇAM no ano dado; [priority] resolve sobreposições. */
class Festive(val spec: ThemeSpec, val priority: Int, val spans: (Int) -> List<DateSpan>) {
    fun isActive(d: LocalDate): Boolean = (d.year - 1..d.year).any { y -> spans(y).any { d in it } }
}

object FestiveCalendar {
    /** Domingo de Páscoa (algoritmo de Meeus/Jones/Butcher, calendário gregoriano). */
    fun easter(year: Int): LocalDate {
        val a = year % 19; val b = year / 100; val c = year % 100
        val d = b / 4; val e = b % 4; val f = (b + 8) / 25; val g = (b - f + 1) / 3
        val h = (19 * a + b - d - g + 15) % 30
        val i = c / 4; val k = c % 4
        val l = (32 + 2 * e + 2 * i - h - k) % 7
        val m = (a + 11 * h + 22 * l) / 451
        val month = (h + l - 7 * m + 114) / 31
        val day = (h + l - 7 * m + 114) % 31 + 1
        return LocalDate.of(year, month, day)
    }

    /** Terça-feira de Carnaval = 47 dias antes da Páscoa. */
    fun carnivalTuesday(year: Int): LocalDate = easter(year).minusDays(47)

    /** Segundo domingo de maio (Dia das Mães no Brasil). */
    fun mothersDay(year: Int): LocalDate {
        var d = LocalDate.of(year, 5, 1)
        while (d.dayOfWeek != DayOfWeek.SUNDAY) d = d.plusDays(1)
        return d.plusDays(7)
    }
}

object Themes {
    private fun p(e: Long, d: Long, n: Long, c: Long, i: Long, s: Long, bg: List<Long>, light: Boolean = false) = Palette(e, d, n, c, i, s, bg, light)

    val blue = ThemeSpec("blue", "Azul NEKO", "A identidade original: azul elétrico e ciano.",
        p(0xFF1749D8, 0xFF102B83, 0xFF080F26, 0xFF69EAD8, 0xFFEAF4FF, 0xFF879BBF, listOf(0xFF102B83, 0xFF0B1A52, 0xFF080F26)), Decor.NONE)
    val aero = ThemeSpec("aero", "Frutiger Aero", "Azul, verde e ciano com vidro, brilho e bolhas.",
        p(0xFF1FA2E8, 0xFF0B6FA8, 0xFF05324F, 0xFF8CF5C8, 0xFFF2FFFF, 0xFFA6D2E4, listOf(0xFF2DB6E8, 0xFF1590B5, 0xFF0A4F6E)), Decor.BUBBLES)
    val neon = ThemeSpec("neon", "Neon", "Fundo escuro com ciano, roxo e rosa luminosos.",
        p(0xFF7A2BFF, 0xFF2A0F5C, 0xFF07030F, 0xFF00F0FF, 0xFFF4EAFF, 0xFFA58BD0, listOf(0xFF1B0B3D, 0xFF110626, 0xFF07030F)), Decor.NEON_SPARK)
    val pastel = ThemeSpec("pastel", "Cores Pastéis", "Rosa, lilás, azul e verde suaves.",
        p(0xFFBCA6F5, 0xFFE4D9FF, 0xFF2F2552, 0xFFD94C8A, 0xFF2F2552, 0xFF6B6094, listOf(0xFFFFF1FA, 0xFFF1EAFF, 0xFFDDF3FF), light = true), Decor.NONE)
    val dark = ThemeSpec("dark", "Dark", "Preto e cinza-escuro, minimalista.",
        p(0xFF3A3F4B, 0xFF1E2128, 0xFF0B0C0F, 0xFFC7D2E6, 0xFFECEFF4, 0xFF8B93A3, listOf(0xFF1A1C21, 0xFF111317, 0xFF08090B)), Decor.NONE)

    /** Temas permanentes que o usuário escolhe. O primeiro é o padrão. */
    val permanent: List<ThemeSpec> = listOf(blue, aero, neon, pastel, dark)

    private fun d(y: Int, m: Int, day: Int) = LocalDate.of(y, m, day)

    val festive: List<Festive> = listOf(
        Festive(ThemeSpec("newyear", "Ano Novo", "Azul-escuro, dourado e prata com fogos.",
            p(0xFF1D3A9E, 0xFF0F1F5C, 0xFF060B24, 0xFFFFD36B, 0xFFF4F6FF, 0xFFB5BED6, listOf(0xFF14246B, 0xFF0B1442, 0xFF050A20)), Decor.FIREWORKS), 5) {
            listOf(DateSpan(d(it, 12, 29), d(it + 1, 1, 6)))
        },
        Festive(ThemeSpec("carnival", "Carnaval", "Rosa, amarelo, roxo e ciano com confetes.",
            p(0xFFE0299A, 0xFF5B1A9E, 0xFF1E0B3D, 0xFFFFE04A, 0xFFFFF7FF, 0xFFE6B8F5, listOf(0xFF7B2BD0, 0xFF4A1A8F, 0xFF1E0B3D)), Decor.CONFETTI), 4) {
            val e = FestiveCalendar.easter(it); listOf(DateSpan(e.minusDays(51), e.minusDays(46)))   // sexta -> quarta de cinzas
        },
        Festive(ThemeSpec("easter", "Páscoa", "Tons pastéis, ovinhos e flores de primavera.",
            p(0xFFC7B2F2, 0xFFE6F6D8, 0xFF3F2F5E, 0xFFE05A9A, 0xFF3B2E5A, 0xFF6F6590, listOf(0xFFFFF8D6, 0xFFEAF8E2, 0xFFF3E6FF), light = true), Decor.EGGS), 4) {
            val e = FestiveCalendar.easter(it); listOf(DateSpan(e.minusDays(7), e.plusDays(1)))     // Domingo de Ramos -> Segunda de Páscoa
        },
        Festive(ThemeSpec("mothers", "Dia das Mães", "Rosa, lilás e branco com flores delicadas.",
            p(0xFFF2A6C8, 0xFFF9D9E8, 0xFF4A2250, 0xFFC2417F, 0xFF4A2250, 0xFF84628D, listOf(0xFFFFF0F6, 0xFFFBE4F0, 0xFFEFE3FF), light = true), Decor.PETALS), 2) {
            listOf(DateSpan(d(it, 5, 1), FestiveCalendar.mothersDay(it)))                           // 1º de maio -> 2º domingo
        },
        Festive(ThemeSpec("junina", "Festa Junina", "Vermelho, amarelo, laranja e azul com bandeirinhas.",
            p(0xFFD8341F, 0xFF7A1C10, 0xFF2A0E08, 0xFFFFC53D, 0xFFFFF4E0, 0xFFE0B27A, listOf(0xFF9B2A12, 0xFF5A1A0E, 0xFF2A0E08)), Decor.BUNTING), 1) {
            listOf(DateSpan(d(it, 6, 1), d(it, 6, 30)))
        },
        Festive(ThemeSpec("valentines", "Dia dos Namorados", "Rosa e vermelho com corações e luz suave.",
            p(0xFFE0245E, 0xFF8A1038, 0xFF2A0614, 0xFFFF9EBD, 0xFFFFF0F4, 0xFFE8A3B8, listOf(0xFFB3173F, 0xFF6E0E2C, 0xFF2A0614)), Decor.HEARTS), 3) {
            listOf(DateSpan(d(it, 6, 6), d(it, 6, 12)))                                             // termina em 12/06
        },
        Festive(ThemeSpec("winter", "Inverno", "Azul-gelo, branco e lilás com flocos de neve.",
            p(0xFF5E7FD8, 0xFF2D3F86, 0xFF0E1433, 0xFFBFE9FF, 0xFFF2F8FF, 0xFFB3B8E8, listOf(0xFF5069B8, 0xFF2B3C80, 0xFF0E1433)), Decor.SNOW), 1) {
            listOf(DateSpan(d(it, 7, 1), d(it, 7, 31)))
        },
        Festive(ThemeSpec("halloween", "Halloween", "Preto, roxo e laranja com morcegos e estrelas.",
            p(0xFF6A1FC2, 0xFF2D0F52, 0xFF0A0510, 0xFFFF8A1E, 0xFFFFF1E0, 0xFFB69AD6, listOf(0xFF3B1470, 0xFF1A0A30, 0xFF0A0510)), Decor.BATS), 3) {
            listOf(DateSpan(d(it, 10, 15), d(it, 11, 2)))
        },
        Festive(ThemeSpec("christmas", "Natal", "Verde, vermelho e dourado com luzes e neve.",
            p(0xFFC4202D, 0xFF0F5A36, 0xFF05241A, 0xFFFFD66B, 0xFFFFFBF2, 0xFFB8D8C4, listOf(0xFF146B40, 0xFF0B3F27, 0xFF05241A)), Decor.XMAS), 3) {
            listOf(DateSpan(d(it, 12, 1), d(it, 12, 28)))
        },
    )

    fun byId(id: String?): ThemeSpec? = permanent.firstOrNull { it.id == id } ?: festive.firstOrNull { it.spec.id == id }?.spec
}

enum class ThemeMode { AUTO, MANUAL }

/** Preferências que definem o tema. [previewId] e [simDate] só valem na sessão (não são salvos). */
data class ThemeSettings(
    val mode: ThemeMode = ThemeMode.AUTO,
    val permanentId: String = Themes.blue.id,
    val festivalsEnabled: Boolean = true,
    val previewId: String? = null,
    val simDate: LocalDate? = null,
)

enum class ThemeSource { PERMANENT, FESTIVE, PREVIEW }

data class ResolvedTheme(val spec: ThemeSpec, val source: ThemeSource, val date: LocalDate)

object ThemeResolver {
    /** Festividade em vigor na data (a de maior prioridade quando há sobreposição). */
    fun festiveOn(date: LocalDate): Festive? = Themes.festive.filter { it.isActive(date) }.maxByOrNull { it.priority }

    fun resolve(s: ThemeSettings, realToday: LocalDate): ResolvedTheme {
        val date = s.simDate ?: realToday
        Themes.byId(s.previewId)?.let { return ResolvedTheme(it, ThemeSource.PREVIEW, date) }
        if (s.mode == ThemeMode.AUTO && s.festivalsEnabled) festiveOn(date)?.let { return ResolvedTheme(it.spec, ThemeSource.FESTIVE, date) }
        val perm = Themes.permanent.firstOrNull { it.id == s.permanentId } ?: Themes.blue
        return ResolvedTheme(perm, ThemeSource.PERMANENT, date)
    }
}
