package br.neko.music.visualizer

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.media.audiofx.Visualizer
import androidx.core.content.ContextCompat
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlin.math.hypot
import kotlin.math.pow

/**
 * Análise REAL do áudio: usa android.media.audiofx.Visualizer ligado à sessão de áudio do ExoPlayer,
 * lê a FFT e agrupa em barras com escala logarítmica (graves à esquerda, agudos à direita).
 * Se a permissão faltar ou o aparelho não suportar, o estado informa isso — nada é simulado.
 */
class AudioVisualizerEngine {
    enum class Status { IDLE, ACTIVE, NO_PERMISSION, ERROR }

    private val _levels = MutableStateFlow(FloatArray(BARS))
    val levels: StateFlow<FloatArray> = _levels.asStateFlow()
    private val _status = MutableStateFlow(Status.IDLE)
    val status: StateFlow<Status> = _status.asStateFlow()

    private var visualizer: Visualizer? = null

    fun start(ctx: Context, sessionId: Int) {
        stop()
        if (sessionId <= 0) return
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            _status.value = Status.NO_PERMISSION; return
        }
        try {
            val v = Visualizer(sessionId)
            v.captureSize = Visualizer.getCaptureSizeRange()[1].coerceAtMost(1024)
            v.setDataCaptureListener(object : Visualizer.OnDataCaptureListener {
                override fun onWaveFormDataCapture(vis: Visualizer?, wave: ByteArray?, rate: Int) {}
                override fun onFftDataCapture(vis: Visualizer?, fft: ByteArray?, rate: Int) { if (fft != null) process(fft) }
            }, Visualizer.getMaxCaptureRate(), false, true)
            v.enabled = true
            visualizer = v
            _status.value = Status.ACTIVE
        } catch (e: Exception) {
            _status.value = Status.ERROR
        }
    }

    fun stop() {
        visualizer?.let { runCatching { it.enabled = false; it.release() } }
        visualizer = null
        _levels.value = FloatArray(BARS)
        if (_status.value == Status.ACTIVE) _status.value = Status.IDLE
    }

    /** fft = [re0, reN/2, re1, im1, re2, im2, ...] (bytes com sinal). */
    private fun process(fft: ByteArray) {
        val n = fft.size / 2
        val maxBin = (n * 0.7f).toInt().coerceAtLeast(BARS + 1)   // acima disso quase não há energia útil
        val out = FloatArray(BARS)
        for (i in 0 until BARS) {
            val lo = (maxBin.toDouble().pow(i.toDouble() / BARS)).toInt().coerceAtLeast(1)
            val hi = (maxBin.toDouble().pow((i + 1).toDouble() / BARS)).toInt().coerceAtLeast(lo + 1).coerceAtMost(n - 1)
            var peak = 0f
            for (k in lo..hi) {
                val re = fft[2 * k].toFloat(); val im = fft[2 * k + 1].toFloat()
                peak = maxOf(peak, hypot(re, im))
            }
            val tilt = 1f + 1.2f * i / BARS      // compensa a queda natural de energia nos agudos
            out[i] = (peak * tilt / 110f).coerceIn(0f, 1f).pow(0.8f)
        }
        _levels.value = out
    }

    companion object { const val BARS = 24 }
}
