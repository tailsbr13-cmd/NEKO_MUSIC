package br.neko.music.presentation.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.PlaylistPlay
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import br.neko.music.media.Song
import br.neko.music.player.PlayerViewModel
import br.neko.music.presentation.components.SongRow
import br.neko.music.presentation.theme.Neko

/** Id reservado para a lista "Favoritas" (que não é uma playlist do banco). */
const val FAV_ID = -1L

private data class OpenList(val id: Long, val name: String)
private sealed interface PlDialog {
    data object Create : PlDialog
    data class Rename(val id: Long, val name: String) : PlDialog
    data class Delete(val id: Long, val name: String) : PlDialog
}

/** Aba Playlists: Favoritas + playlists do usuário (criar, renomear, excluir, abrir). */
@Composable
fun PlaylistsTab(vm: PlayerViewModel, songs: List<Song>, activeKey: String?) {
    val playlists by vm.playlists.collectAsStateWithLifecycle()
    val favKeys by vm.favoriteKeys.collectAsStateWithLifecycle()
    val byKey = remember(songs) { songs.associateBy { it.key } }
    var open by remember { mutableStateOf<OpenList?>(null) }
    var dialog by remember { mutableStateOf<PlDialog?>(null) }
    var actionSong by remember { mutableStateOf<Song?>(null) }
    BackHandler(enabled = open != null) { open = null }

    val o = open
    if (o == null) {
        LazyColumn(Modifier.fillMaxSize()) {
            item {
                TextButton({ dialog = PlDialog.Create }, Modifier.padding(horizontal = 8.dp)) {
                    Icon(Icons.Filled.Add, null, tint = Neko.Cyan)
                    Spacer(Modifier.width(6.dp))
                    Text("NOVA PLAYLIST", color = Neko.Cyan, fontFamily = FontFamily.Monospace, letterSpacing = 1.sp)
                }
            }
            item { ListRow("Favoritas", "${favKeys.size} músicas", true) { open = OpenList(FAV_ID, "Favoritas") } }
            items(playlists, key = { it.id }) { p ->
                var menu by remember { mutableStateOf(false) }
                ListRow(p.name, "${p.total} música${if (p.total == 1) "" else "s"}", false, trailing = {
                    Box {
                        IconButton({ menu = true }) { Icon(Icons.Filled.MoreVert, "Opções da playlist", tint = Neko.SteelGray) }
                        DropdownMenu(menu, { menu = false }) {
                            DropdownMenuItem({ Text("Renomear") }, { menu = false; dialog = PlDialog.Rename(p.id, p.name) })
                            DropdownMenuItem({ Text("Excluir") }, { menu = false; dialog = PlDialog.Delete(p.id, p.name) })
                        }
                    }
                }) { open = OpenList(p.id, p.name) }
            }
        }
    } else {
        // Conteúdo da lista aberta (favoritas ou playlist)
        val flow = remember(o.id) { if (o.id == FAV_ID) vm.favoriteKeys else vm.playlistKeys(o.id) }
        val keys by flow.collectAsStateWithLifecycle(emptyList())
        val list = remember(keys, byKey) { keys.mapNotNull { byKey[it] } }
        Column(Modifier.fillMaxSize()) {
            Text("‹ ${o.name}", color = Neko.Cyan, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold,
                modifier = Modifier.fillMaxWidth().clickable { open = null }.padding(14.dp))
            if (list.isEmpty()) {
                Text(if (o.id == FAV_ID) "Toque no coração do player ou em ⋮ para favoritar músicas." else "Playlist vazia. Use ⋮ em uma música para adicioná-la.",
                    color = Neko.IceWhite, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(32.dp))
            } else LazyColumn(Modifier.fillMaxSize()) {
                itemsIndexed(list, key = { _, s -> s.key }) { i, s ->
                    SongRow(s, s.key == activeKey, onMore = { actionSong = s }) { vm.play(list, i) }
                }
            }
        }
    }

    actionSong?.let { SongActionsDialog(vm, it, open?.id) { actionSong = null } }

    when (val d = dialog) {
        PlDialog.Create -> NameDialog("Nova playlist", "", "Criar", { dialog = null }) { vm.createPlaylist(it); dialog = null }
        is PlDialog.Rename -> NameDialog("Renomear playlist", d.name, "Salvar", { dialog = null }) { vm.renamePlaylist(d.id, it); dialog = null }
        is PlDialog.Delete -> AlertDialog(
            onDismissRequest = { dialog = null }, containerColor = Neko.Deep, titleContentColor = Neko.IceWhite, textContentColor = Neko.IceWhite,
            title = { Text("Excluir playlist?") }, text = { Text("\"${d.name}\" será removida. As músicas continuam no aparelho.") },
            confirmButton = { TextButton({ vm.deletePlaylist(d.id); dialog = null }) { Text("Excluir", color = Neko.Cyan) } },
            dismissButton = { TextButton({ dialog = null }) { Text("Cancelar", color = Neko.SteelGray) } },
        )
        null -> {}
    }
}

/** Ações de uma música: favoritar, adicionar a playlist e (quando aberta numa playlist) remover. */
@Composable
fun SongActionsDialog(vm: PlayerViewModel, song: Song, playlistId: Long?, onDismiss: () -> Unit) {
    val favKeys by vm.favoriteKeys.collectAsStateWithLifecycle()
    val playlists by vm.playlists.collectAsStateWithLifecycle()
    var picker by remember { mutableStateOf(false) }
    var creating by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    val fav = song.key in favKeys

    when {
        confirmDelete -> AlertDialog(
            onDismissRequest = onDismiss, containerColor = Neko.Deep, titleContentColor = Neko.IceWhite, textContentColor = Neko.IceWhite,
            title = { Text(song.title, maxLines = 2) },
            text = { Text("Deseja realmente excluir esta música? O arquivo será removido do dispositivo.") },
            confirmButton = { TextButton({ vm.requestDelete(song); onDismiss() }) { Text("Excluir", color = Neko.Cyan) } },
            dismissButton = { TextButton(onDismiss) { Text("Cancelar", color = Neko.SteelGray) } },
        )
        creating -> NameDialog("Nova playlist", "", "Criar e adicionar", onDismiss) { vm.createPlaylist(it, song); onDismiss() }
        picker -> AlertDialog(
            onDismissRequest = onDismiss, containerColor = Neko.Deep, titleContentColor = Neko.IceWhite, textContentColor = Neko.IceWhite,
            title = { Text("Adicionar à playlist") },
            text = {
                Column {
                    ActionItem("+ Nova playlist") { creating = true }
                    playlists.forEach { p -> ActionItem(p.name) { vm.addToPlaylist(p.id, song); onDismiss() } }
                }
            },
            confirmButton = {}, dismissButton = { TextButton(onDismiss) { Text("Cancelar", color = Neko.SteelGray) } },
        )
        else -> AlertDialog(
            onDismissRequest = onDismiss, containerColor = Neko.Deep, titleContentColor = Neko.IceWhite, textContentColor = Neko.IceWhite,
            title = { Text(song.title, maxLines = 2) },
            text = {
                Column {
                    ActionItem(if (fav) "Remover dos favoritos" else "Favoritar") { vm.toggleFavorite(song); onDismiss() }
                    ActionItem("Adicionar à playlist") { picker = true }
                    if (playlistId != null && playlistId != FAV_ID) ActionItem("Remover desta playlist") { vm.removeFromPlaylist(playlistId, song); onDismiss() }
                    ActionItem("Excluir música") { confirmDelete = true }
                }
            },
            confirmButton = {}, dismissButton = { TextButton(onDismiss) { Text("Fechar", color = Neko.SteelGray) } },
        )
    }
}

@Composable
private fun ActionItem(text: String, onClick: () -> Unit) {
    Text(text, color = Neko.IceWhite, modifier = Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 12.dp))
}

@Composable
private fun NameDialog(title: String, initial: String, confirm: String, onDismiss: () -> Unit, onConfirm: (String) -> Unit) {
    var text by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss, containerColor = Neko.Deep, titleContentColor = Neko.IceWhite, textContentColor = Neko.IceWhite,
        title = { Text(title) },
        text = {
            TextField(text, { text = it }, singleLine = true, placeholder = { Text("Nome", color = Neko.SteelGray) },
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = Color.Transparent, unfocusedContainerColor = Color.Transparent,
                    focusedTextColor = Neko.IceWhite, unfocusedTextColor = Neko.IceWhite, cursorColor = Neko.Cyan,
                    focusedIndicatorColor = Neko.Cyan, unfocusedIndicatorColor = Neko.SteelGray))
        },
        confirmButton = { TextButton({ if (text.isNotBlank()) onConfirm(text.trim()) }) { Text(confirm, color = Neko.Cyan) } },
        dismissButton = { TextButton(onDismiss) { Text("Cancelar", color = Neko.SteelGray) } },
    )
}

@Composable
private fun ListRow(title: String, subtitle: String, heart: Boolean, trailing: @Composable (() -> Unit)? = null, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier.size(52.dp).clip(RoundedCornerShape(6.dp)).background(Brush.verticalGradient(listOf(Neko.Electric, Neko.Deep))),
            contentAlignment = Alignment.Center,
        ) { Icon(if (heart) Icons.Filled.Favorite else Icons.AutoMirrored.Filled.PlaylistPlay, null, tint = Neko.Cyan) }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = Neko.IceWhite, fontWeight = FontWeight.SemiBold, fontSize = 15.sp, maxLines = 1)
            Text(subtitle, color = Neko.SteelGray, fontSize = 12.sp)
        }
        trailing?.invoke()
    }
}
