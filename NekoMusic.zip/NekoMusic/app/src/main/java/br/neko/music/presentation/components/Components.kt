package br.neko.music.presentation.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import br.neko.music.R
import br.neko.music.media.CoverLoader
import br.neko.music.media.Song
import br.neko.music.presentation.theme.Neko
import br.neko.music.visualizer.AudioVisualizerEngine
import kotlin.math.abs
import kotlin.math.roundToInt

/** Capa da faixa; sem capa, usa a arte padrão do NEKO MUSIC. */
@Composable
fun CoverArt(song: Song?, modifier: Modifier = Modifier, px: Int = 256) {
    val ctx = LocalContext.current
    val bmp by produceState<androidx.compose.ui.graphics.ImageBitmap?>(null, song?.key) {
        value = song?.let { CoverLoader.load(ctx, it, px)?.asImageBitmap() }
    }
    val shape = RoundedCornerShape(6.dp)
    Box(modifier.clip(shape).background(Neko.Deep).border(1.dp, Neko.Cyan.copy(alpha = 0.45f), shape)) {
        val b = bmp
        if (b != null) Image(b, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        else Image(painterResource(R.drawable.neko_logo), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
    }
}

@Composable
fun SongRow(song: Song, active: Boolean, onMore: (() -> Unit)? = null, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick)
            .background(if (active) Neko.Electric.copy(alpha = 0.28f) else Color.Transparent)
            .padding(horizontal = 14.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        CoverArt(song, Modifier.size(52.dp), px = 128)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(song.title, color = if (active) Neko.Cyan else Neko.IceWhite, fontWeight = FontWeight.SemiBold,
                fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(song.artist, color = Neko.SteelGray, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text("${song.album} · ${formatTime(song.durationMs)}${if (song.fromVideo) " · MP4" else ""}",
                color = Neko.SteelGray.copy(alpha = 0.7f), fontSize = 11.sp, fontFamily = FontFamily.Monospace,
                maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        if (onMore != null) IconButton(onMore) { Icon(Icons.Filled.MoreVert, "Mais opções", tint = Neko.SteelGray) }
    }
}

/** Mini player com aparência de "aparelho": corpo azul metálico, brilho no topo e barra de progresso. */
@Composable
fun MiniPlayer(
    song: Song, playing: Boolean, progress: Float,
    onToggle: () -> Unit, onNext: () -> Unit, onClick: () -> Unit, modifier: Modifier = Modifier,
) {
    val shape = RoundedCornerShape(10.dp)
    Column(
        modifier.padding(horizontal = 10.dp, vertical = 6.dp).clip(shape)
            .background(Brush.verticalGradient(listOf(Color(0xFF3068F0), Neko.Electric, Neko.Deep)))
            .border(1.dp, Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.7f), Neko.SteelGray.copy(alpha = 0.25f))), shape)
            .clickable(onClick = onClick)
    ) {
        Row(Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            CoverArt(song, Modifier.size(44.dp), px = 128)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(song.title, color = Neko.IceWhite, fontWeight = FontWeight.Bold, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(song.artist, color = Neko.IceWhite.copy(alpha = 0.75f), fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(if (playing) "● REPRODUZINDO" else "❚❚ PAUSADO", color = Neko.Cyan, fontSize = 9.sp, fontFamily = FontFamily.Monospace, letterSpacing = 1.sp)
            }
            IconButton(onToggle) { Icon(if (playing) Icons.Filled.Pause else Icons.Filled.PlayArrow, if (playing) "Pausar" else "Reproduzir", tint = Neko.IceWhite) }
            IconButton(onNext) { Icon(Icons.Filled.SkipNext, "Próxima", tint = Neko.IceWhite) }
        }
        LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth().height(3.dp), color = Neko.Cyan, trackColor = Neko.Navy.copy(alpha = 0.6f))
    }
}

/**
 * Barras segmentadas estilo equalizador dos anos 2000.
 * Os alvos vêm da FFT real (AudioVisualizerEngine); aqui só suavizamos a 60fps (subida rápida, queda lenta),
 * porque a Visualizer API entrega poucas amostras por segundo. O loop de frames para quando tudo zera.
 */
@Composable
fun AudioVisualizer(engine: AudioVisualizerEngine, active: Boolean, modifier: Modifier = Modifier) {
    val targets = rememberUpdatedState(engine.levels.collectAsStateWithLifecycle().value)
    val display = remember { FloatArray(AudioVisualizerEngine.BARS) }
    var frame by remember { mutableLongStateOf(0L) }

    LaunchedEffect(active) {
        while (true) {
            var moving = false
            androidx.compose.runtime.withFrameNanos { t ->
                val src = targets.value
                for (i in display.indices) {
                    val goal = if (active) src.getOrElse(i) { 0f } else 0f
                    val d = display[i]
                    val nd = d + (goal - d) * (if (goal > d) 0.5f else 0.10f)
                    display[i] = if (abs(nd) < 0.004f) 0f else nd
                    if (display[i] > 0f) moving = true
                }
                frame = t
            }
            if (!active && !moving) break
        }
    }

    Canvas(modifier) {
        frame // lê o frame para redesenhar
        val n = display.size; val rows = 14
        val gap = 2.dp.toPx()
        val barW = (size.width - gap * (n - 1)) / n
        val cellH = (size.height - gap * (rows - 1)) / rows
        for (i in 0 until n) {
            val lit = (display[i] * rows).roundToInt()
            for (r in 0 until rows) {
                val y = size.height - (r + 1) * cellH - r * gap
                val color = when {
                    r >= lit -> Neko.SteelGray.copy(alpha = 0.10f)
                    r == lit - 1 && r > 0 -> Neko.IceWhite
                    else -> lerp(Neko.Cyan, Neko.Electric, r / (rows - 1f))
                }
                drawRoundRect(color, Offset(i * (barW + gap), y), Size(barW, cellH), CornerRadius(1.5.dp.toPx()))
            }
        }
    }
}

fun formatTime(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    return "%d:%02d".format(s / 60, s % 60)
}
