package br.neko.music.audio

import kotlin.math.ln

/** Modelo puro do equalizador (sem Android): bandas, presets e o mapeamento para as bandas físicas do aparelho. */
object EqModel {
    /** As 7 bandas mostradas na tela (Hz). */
    val FREQS = floatArrayOf(60f, 150f, 400f, 1000f, 2400f, 6000f, 15000f)
    const val MIN_DB = -12f
    const val MAX_DB = 12f

    /**
     * O Equalizer do Android tem poucas bandas físicas (normalmente 5), com frequências próprias.
     * Para cada uma, interpolamos a curva das 7 bandas da tela na escala logarítmica de frequência.
     */
    fun gainAtHz(bands: List<Float>, hz: Float): Float {
        if (hz <= FREQS.first()) return bands.first()
        if (hz >= FREQS.last()) return bands.last()
        for (i in 0 until FREQS.size - 1) {
            val a = FREQS[i]; val b = FREQS[i + 1]
            if (hz in a..b) {
                val t = ln(hz / a) / ln(b / a)
                return bands[i] + (bands[i + 1] - bands[i]) * t
            }
        }
        return bands.last()
    }

    /** Nível (milibéis) para uma banda física: curva do usuário + preamp, limitado ao alcance do aparelho. */
    fun deviceLevelMb(bands: List<Float>, preampDb: Float, centerHz: Float, minMb: Int, maxMb: Int): Int =
        Math.round((gainAtHz(bands, centerHz) + preampDb) * 100f).coerceIn(minMb, maxMb)
}

enum class EqPreset(val label: String, val gains: List<Float>?) {
    //                                   60   150   400   1k    2.4k  6k    15k
    FLAT("Flat", listOf(0f, 0f, 0f, 0f, 0f, 0f, 0f)),
    POP("Pop", listOf(-1f, 2f, 3.5f, 4f, 2.5f, 0.5f, -1f)),
    ROCK("Rock", listOf(5f, 3.5f, -2f, -3f, 0.5f, 3.5f, 5f)),
    JAZZ("Jazz", listOf(3.5f, 2.5f, 1f, 2f, -1.5f, 1.5f, 3f)),
    CLASSICAL("Clássica", listOf(4f, 3f, 2f, 0f, 0f, 2f, 3f)),
    BASS("Bass Boost", listOf(8f, 6f, 3f, 0f, 0f, 0f, 0f)),
    TREBLE("Treble Boost", listOf(0f, 0f, 0f, 0f, 3f, 6f, 8f)),
    VOCAL("Vocal", listOf(-3f, -2f, 1f, 4f, 4f, 2f, -1f)),
    CUSTOM("Customizado", null),
}
