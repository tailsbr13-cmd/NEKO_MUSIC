package br.neko.music.data.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [FavoriteEntity::class, PlaylistEntity::class, PlaylistSongEntity::class], version = 1, exportSchema = false)
abstract class NekoDatabase : RoomDatabase() {
    abstract fun dao(): NekoDao

    companion object {
        @Volatile private var instance: NekoDatabase? = null
        fun get(ctx: Context): NekoDatabase = instance ?: synchronized(this) {
            instance ?: Room.databaseBuilder(ctx.applicationContext, NekoDatabase::class.java, "neko.db").build().also { instance = it }
        }
    }
}
