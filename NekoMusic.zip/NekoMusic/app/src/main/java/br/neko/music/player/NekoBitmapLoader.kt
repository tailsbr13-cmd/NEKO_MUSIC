package br.neko.music.player

import android.content.ContentUris
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.util.LruCache
import android.util.Size
import androidx.annotation.OptIn
import androidx.media3.common.util.BitmapLoader
import androidx.media3.common.util.UnstableApi
import br.neko.music.media.Song
import com.google.common.util.concurrent.ListenableFuture
import com.google.common.util.concurrent.ListeningExecutorService
import com.google.common.util.concurrent.MoreExecutors
import java.util.concurrent.Callable
import java.util.concurrent.Executors

/** Endereço da capa de uma faixa. Carrega tudo o que o loader precisa para achar a capa (não depende do MediaStore "albumart"). */
object ArtUri {
    class Request(val songUri: Uri, val albumId: Long, val fromVideo: Boolean)

    fun build(song: Song): Uri = Uri.Builder().scheme("neko-art").authority("cover")
        .appendQueryParameter("u", song.uri.toString())
        .appendQueryParameter("a", song.albumId.toString())
        .appendQueryParameter("v", if (song.fromVideo) "1" else "0")
        .build()

    fun parse(uri: Uri): Request? {
        if (uri.scheme != "neko-art") return null
        val u = uri.getQueryParameter("u") ?: return null
        return Request(Uri.parse(u), uri.getQueryParameter("a")?.toLongOrNull() ?: -1L, uri.getQueryParameter("v") == "1")
    }
}

/**
 * BitmapLoader da MediaSession: notificação, cartão de mídia e tela de bloqueio pedem a capa aqui.
 * Resultado: capa real do álbum (embutida) dentro do display Y2K; sem capa, o display NEKO. Nunca falha em branco.
 */
@OptIn(UnstableApi::class)
class NekoBitmapLoader(private val ctx: Context) : BitmapLoader {
    private val executor: ListeningExecutorService = MoreExecutors.listeningDecorator(Executors.newSingleThreadExecutor())
    private val cache = LruCache<String, Bitmap>(8)

    override fun supportsMimeType(mimeType: String): Boolean = mimeType.startsWith("image/")

    override fun decodeBitmap(data: ByteArray): ListenableFuture<Bitmap> = executor.submit(Callable<Bitmap> {
        Y2kArtwork.frame(ctx, BitmapFactory.decodeByteArray(data, 0, data.size))
    })

    override fun loadBitmap(uri: Uri): ListenableFuture<Bitmap> = executor.submit(Callable<Bitmap> {
        val key = uri.toString()
        cache.get(key) ?: Y2kArtwork.frame(ctx, loadCover(uri)).also { cache.put(key, it) }
    })

    private fun loadCover(uri: Uri): Bitmap? = try {
        val req = ArtUri.parse(uri)
        if (req == null) {
            ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
        } else if (req.fromVideo) {
            null
        } else if (Build.VERSION.SDK_INT >= 29) {
            ctx.contentResolver.loadThumbnail(req.songUri, Size(512, 512), null)   // capa embutida no arquivo
        } else {
            val art = ContentUris.withAppendedId(Uri.parse("content://media/external/audio/albumart"), req.albumId)
            ctx.contentResolver.openInputStream(art)?.use { BitmapFactory.decodeStream(it) }
        }
    } catch (e: Exception) { null }
}
