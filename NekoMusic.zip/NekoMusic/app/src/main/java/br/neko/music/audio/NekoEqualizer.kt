package br.neko.music.audio

import android.content.Context
import android.content.SharedPreferences
import android.media.audiofx.Equalizer
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

data class EqState(
    val enabled: Boolean = true,
    val preset: EqPreset = EqPreset.FLAT,
    val bands: List<Float> = List(7) { 0f },     // valores atuais dos 7 sliders (dB)
    val custom: List<Float> = List(7) { 0f },    // último ajuste manual (preset "Customizado")
    val preamp: Float = 0f,                      // ganho geral (dB)
    val available: Boolean = false,              // efeito criado com sucesso na sessão do player
)

/**
 * Equalizador REAL: android.media.audiofx.Equalizer ligado à MESMA sessão de áudio do ExoPlayer
 * (a que o PlaybackService gera e fixa no player). Vive no processo do app, então continua valendo com a tela
 * fechada. Estado e persistência ficam aqui; a UI só chama os setters.
 */
object NekoEqualizer {
    private val _state = MutableStateFlow(EqState())
    val state: StateFlow<EqState> = _state.asStateFlow()

    private var prefs: SharedPreferences? = null
    private var eq: Equalizer? = null

    /** Carrega as configurações salvas (idempotente). */
    fun init(ctx: Context) {
        if (prefs != null) return
        val p = ctx.applicationContext.getSharedPreferences("neko_eq", Context.MODE_PRIVATE)
        prefs = p
        _state.update {
            EqState(
                enabled = p.getBoolean("enabled", true),
                preset = runCatching { EqPreset.valueOf(p.getString("preset", "FLAT") ?: "FLAT") }.getOrDefault(EqPreset.FLAT),
                bands = parse(p.getString("bands", null)), custom = parse(p.getString("custom", null)),
                preamp = p.getFloat("preamp", 0f), available = eq != null,
            )
        }
        apply()
    }

    /** Chamado pelo PlaybackService com o audioSessionId do player (nunca cria outra sessão). */
    fun attach(sessionId: Int) {
        release()
        try {
            eq = Equalizer(0, sessionId)
            _state.update { it.copy(available = true) }
            apply()
        } catch (e: Exception) {
            eq = null
            _state.update { it.copy(available = false) }
        }
    }

    fun release() {
        eq?.let { runCatching { it.release() } }
        eq = null
        _state.update { it.copy(available = false) }
    }

    // ----------------------------------------------------------------- ações da UI
    fun setEnabled(on: Boolean) { _state.update { it.copy(enabled = on) }; commit() }

    fun setPreset(p: EqPreset) {
        _state.update { s ->
            val gains = p.gains ?: s.custom
            s.copy(preset = p, bands = gains)
        }
        commit()
    }

    /** Mexer num slider ativa automaticamente o preset "Customizado" e guarda o ajuste. */
    fun setBand(index: Int, db: Float) {
        _state.update { s ->
            val nb = s.bands.toMutableList().also { it[index] = db.coerceIn(EqModel.MIN_DB, EqModel.MAX_DB) }
            s.copy(preset = EqPreset.CUSTOM, bands = nb, custom = nb)
        }
        commit()
    }

    fun setPreamp(db: Float) { _state.update { it.copy(preamp = db.coerceIn(EqModel.MIN_DB, EqModel.MAX_DB)) }; commit() }

    /** Restaura tudo ao padrão (mantém ligado/desligado). */
    fun reset() {
        _state.update { it.copy(preset = EqPreset.FLAT, bands = List(7) { 0f }, custom = List(7) { 0f }, preamp = 0f) }
        commit()
    }

    // ----------------------------------------------------------------- interno
    private fun commit() { apply(); save() }

    /** Aplica na hora (efeito em tempo real). Desligado: efeito desativado, mas os ajustes são mantidos. */
    private fun apply() {
        val e = eq ?: return
        val s = _state.value
        try {
            e.enabled = s.enabled
            val range = e.bandLevelRange
            val min = range[0].toInt(); val max = range[1].toInt()
            for (b in 0 until e.numberOfBands.toInt()) {
                val hz = e.getCenterFreq(b.toShort()) / 1000f   // milliHz -> Hz
                val mb = EqModel.deviceLevelMb(s.bands, s.preamp, hz, min, max)
                e.setBandLevel(b.toShort(), mb.toShort())
            }
        } catch (ex: Exception) {
            _state.update { it.copy(available = false) }
        }
    }

    private fun save() {
        val s = _state.value
        prefs?.edit()
            ?.putBoolean("enabled", s.enabled)?.putString("preset", s.preset.name)
            ?.putString("bands", s.bands.joinToString(","))?.putString("custom", s.custom.joinToString(","))
            ?.putFloat("preamp", s.preamp)?.apply()
    }

    private fun parse(s: String?): List<Float> {
        val l = s?.split(",")?.mapNotNull { it.toFloatOrNull() }
        return if (l != null && l.size == EqModel.FREQS.size) l else List(EqModel.FREQS.size) { 0f }
    }
}
