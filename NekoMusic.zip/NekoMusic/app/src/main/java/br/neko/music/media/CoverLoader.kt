package br.neko.music.media

import android.content.ContentUris
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.util.LruCache
import android.util.Size
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Carrega a capa incorporada/álbum. Retorna null quando não existe (a UI usa a arte padrão do NEKO). */
object CoverLoader {
    private val cache = LruCache<String, Bitmap>(60)

    suspend fun load(ctx: Context, song: Song, px: Int): Bitmap? = withContext(Dispatchers.IO) {
        if (song.fromVideo) return@withContext null
        val k = "${song.key}@$px"
        cache.get(k)?.let { return@withContext it }
        val bmp = try {
            if (Build.VERSION.SDK_INT >= 29) ctx.contentResolver.loadThumbnail(song.uri, Size(px, px), null)
            else {
                val art = ContentUris.withAppendedId(Uri.parse("content://media/external/audio/albumart"), song.albumId)
                ctx.contentResolver.openInputStream(art)?.use { BitmapFactory.decodeStream(it) }
            }
        } catch (e: Exception) { null }
        bmp?.also { cache.put(k, it) }
    }
}
