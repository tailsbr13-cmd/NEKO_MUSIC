package br.neko.music.player

import android.media.AudioManager
import android.os.Bundle
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import com.google.common.collect.ImmutableList
import com.google.common.util.concurrent.Futures
import com.google.common.util.concurrent.ListenableFuture

/**
 * Serviço em primeiro plano: mantém o ExoPlayer tocando com a tela bloqueada / app fechado.
 * O Media3 publica a notificação (anterior / play-pause / próxima) e os controles da tela de bloqueio
 * a partir da MediaSession.
 */
class PlaybackService : MediaSessionService() {
    private var session: MediaSession? = null

    override fun onCreate() {
        super.onCreate()
        // Sessão de áudio própria: é nela que o Visualizer se conecta
        val sessionId = getSystemService(AudioManager::class.java).generateAudioSessionId()
        val player = ExoPlayer.Builder(this)
            .setAudioAttributes(
                AudioAttributes.Builder().setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_MUSIC).build(), true
            )
            .setHandleAudioBecomingNoisy(true) // pausa ao desconectar fones
            .build()
        player.audioSessionId = sessionId
        // MP4: toca só a trilha de áudio
        player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
            .setTrackTypeDisabled(C.TRACK_TYPE_VIDEO, true).build()

        session = MediaSession.Builder(this, player)
            .setCallback(object : MediaSession.Callback {
                // O controller envia apenas o uri em requestMetadata; aqui reconstruímos o item tocável
                override fun onAddMediaItems(
                    mediaSession: MediaSession, controller: MediaSession.ControllerInfo, mediaItems: MutableList<MediaItem>,
                ): ListenableFuture<MutableList<MediaItem>> {
                    val resolved = mediaItems.map { it.buildUpon().setUri(it.requestMetadata.mediaUri ?: it.localConfiguration?.uri).build() }
                    return Futures.immediateFuture(ImmutableList.copyOf(resolved).toMutableList())
                }
            })
            .setSessionExtras(Bundle().apply { putInt(KEY_AUDIO_SESSION, sessionId) })
            .build()
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = session

    override fun onTaskRemoved(rootIntent: android.content.Intent?) {
        // Se não estiver tocando, encerra o serviço ao fechar o app
        val p = session?.player
        if (p == null || !p.playWhenReady || p.mediaItemCount == 0) stopSelf()
    }

    override fun onDestroy() {
        session?.run { player.release(); release() }
        session = null
        super.onDestroy()
    }

    companion object { const val KEY_AUDIO_SESSION = "neko_audio_session" }
}
