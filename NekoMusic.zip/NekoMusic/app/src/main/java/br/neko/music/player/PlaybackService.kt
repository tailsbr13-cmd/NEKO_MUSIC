package br.neko.music.player

import android.app.PendingIntent
import android.content.Intent
import android.media.AudioManager
import android.os.Bundle
import androidx.annotation.OptIn
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.DefaultMediaNotificationProvider
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import br.neko.music.MainActivity
import br.neko.music.R
import com.google.common.collect.ImmutableList
import com.google.common.util.concurrent.Futures
import com.google.common.util.concurrent.ListenableFuture

/**
 * ÚNICO serviço de reprodução: mantém o ExoPlayer tocando com a tela bloqueada / app fechado.
 * O Media3 publica a notificação nativa (anterior / play-pause / próxima) e os controles da tela de bloqueio
 * a partir da MediaSession. Esta classe só configura: toque para abrir o app, capa Y2K, canal e ícone.
 */
@OptIn(UnstableApi::class)
class PlaybackService : MediaSessionService() {
    private var session: MediaSession? = null

    override fun onCreate() {
        super.onCreate()
        // Sessão de áudio própria: é nela que o Visualizer se conecta
        val sessionId = getSystemService(AudioManager::class.java).generateAudioSessionId()
        val player = ExoPlayer.Builder(this)
            .setAudioAttributes(
                AudioAttributes.Builder().setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_MUSIC).build(), true
            )
            .setHandleAudioBecomingNoisy(true) // pausa ao desconectar fones
            .build()
        player.audioSessionId = sessionId
        // MP4: toca só a trilha de áudio
        player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
            .setTrackTypeDisabled(C.TRACK_TYPE_VIDEO, true).build()

        // Notificação nativa: canal e ícone do NEKO (nome aparece em Configurações > Notificações)
        val provider = DefaultMediaNotificationProvider.Builder(this)
            .setChannelId(CHANNEL_ID).setChannelName(R.string.playback_channel_name).build()
        provider.setSmallIcon(R.drawable.ic_stat_neko)
        setMediaNotificationProvider(provider)

        // CORREÇÃO PRINCIPAL: sem sessionActivity o cartão de mídia/notificação não tem "toque para abrir".
        // NEW_TASK é obrigatório porque a Intent é disparada pelo sistema (fora do app); SINGLE_TOP + launchMode
        // singleTask reaproveitam a tela já aberta. IMMUTABLE é exigido no Android 12+.
        val openApp = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java).apply {
                putExtra(MainActivity.EXTRA_OPEN_PLAYER, true)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )

        session = MediaSession.Builder(this, player)
            .setId("neko_main")                          // uma única sessão
            .setSessionActivity(openApp)
            .setBitmapLoader(NekoBitmapLoader(this))     // capa dentro do display Y2K
            .setCallback(object : MediaSession.Callback {
                // O controller envia apenas o uri em requestMetadata; aqui reconstruímos o item tocável
                override fun onAddMediaItems(
                    mediaSession: MediaSession, controller: MediaSession.ControllerInfo, mediaItems: MutableList<MediaItem>,
                ): ListenableFuture<MutableList<MediaItem>> {
                    val resolved = mediaItems.map { it.buildUpon().setUri(it.requestMetadata.mediaUri ?: it.localConfiguration?.uri).build() }
                    return Futures.immediateFuture(ImmutableList.copyOf(resolved).toMutableList())
                }
            })
            .setSessionExtras(Bundle().apply { putInt(KEY_AUDIO_SESSION, sessionId) })
            .build()
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = session

    override fun onTaskRemoved(rootIntent: Intent?) {
        // Fechar/deslizar o app NÃO interrompe a música. Só encerra o serviço se nada estiver tocando.
        val p = session?.player
        if (p == null || !p.playWhenReady || p.mediaItemCount == 0) stopSelf()
    }

    override fun onDestroy() {
        session?.run { player.release(); release() }
        session = null
        super.onDestroy()
    }

    companion object {
        const val KEY_AUDIO_SESSION = "neko_audio_session"
        const val CHANNEL_ID = "neko_playback"
    }
}
