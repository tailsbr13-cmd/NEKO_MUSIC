package br.neko.music.presentation.splash

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.res.imageResource
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import br.neko.music.R
import br.neko.music.presentation.components.blockTouchesBehind
import br.neko.music.presentation.theme.Neko
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.random.Random

/*
 * Splash do NEKO MUSIC — uma única linha do tempo (t em ms) que comanda tudo; cada elemento é uma função de t.
 * Sem vídeo, sem imagens de partículas: só 2 imagens da Neko + desenho em Canvas (leve, ~4,4 s, toque para pular).
 *
 *   0 ─ 600     Neko entra (fade + escala com leve "pulo")
 *   760 ─ 1250  Neko pisca (troca para o frame de olho fechado)
 *   800 ─ 2500  Estrelas mágicas: anel de energia, brilhos e estrelas cartoon em volta da Neko
 *   1850 ─ 2500 Neko some suavemente
 *   1850 ─ 4300 Chuva de estrelas cadentes (menos estrelas com o tempo)
 *   3800 ─ 4400 Tudo esmaece e revela a biblioteca (que já está carregando por baixo)
 */
private const val TOTAL = 4400f

private val LightBlue = Color(0xFF9FD8FF)
private val Cyan = Color(0xFF69EAD8)
private val Lilac = Color(0xFFC8A8FF)
private val Purple = Color(0xFF9B6BFF)
private val OutlineBlue = Color(0xFF1B2F7A)
private val OutlinePurple = Color(0xFF4B2A9A)

private class Burst(val ax: Float, val ay: Float, val size: Float, val delay: Float, val spin: Float, val fill: Color, val outline: Color)
private class Sparkle(val ax: Float, val ay: Float, val size: Float, val delay: Float, val color: Color)
private class Shooter(
    val ts: Float, val dur: Float, val x0: Float, val y0: Float, val angle: Float, val travel: Float,
    val size: Float, val trail: Float, val bright: Float, val color: Color, val phase: Float, val spin: Float,
)
private class Dust(val x: Float, val y: Float, val r: Float, val phase: Float, val color: Color)

private fun seg(t: Float, a: Float, b: Float) = ((t - a) / (b - a)).coerceIn(0f, 1f)
private fun smooth(x: Float) = x * x * (3f - 2f * x)
private fun easeOut(x: Float) = 1f - (1f - x).pow(3)
private fun easeOutBack(x: Float): Float { val c1 = 1.70158f; val c3 = c1 + 1f; return 1f + c3 * (x - 1f).pow(3) + c1 * (x - 1f).pow(2) }

private fun Path.star(cx: Float, cy: Float, outer: Float, inner: Float, points: Int, rotDeg: Float) {
    reset()
    val rot = rotDeg * PI / 180.0 - PI / 2
    for (i in 0 until points * 2) {
        val r = if (i % 2 == 0) outer else inner
        val a = rot + i * PI / points
        val x = cx + (r * cos(a)).toFloat(); val y = cy + (r * sin(a)).toFloat()
        if (i == 0) moveTo(x, y) else lineTo(x, y)
    }
    close()
}

private fun DrawScope.glow(c: Offset, radius: Float, color: Color, a: Float) {
    if (a <= 0.01f || radius <= 0f) return
    drawCircle(Brush.radialGradient(listOf(color.copy(alpha = a), color.copy(alpha = 0f)), center = c, radius = radius), radius = radius, center = c)
}

/** Estrela "cartoon": contorno escuro arredondado + preenchimento claro + brilhinho. */
private fun DrawScope.cartoonStar(path: Path, c: Offset, r: Float, rot: Float, fill: Color, outline: Color, a: Float) {
    if (a <= 0.01f || r <= 0f) return
    path.star(c.x, c.y, r, r * 0.5f, 5, rot)
    drawPath(path, outline.copy(alpha = a), style = Stroke(width = r * 0.32f, join = StrokeJoin.Round))
    drawPath(path, fill.copy(alpha = a))
    drawCircle(Color.White.copy(alpha = 0.8f * a), radius = r * 0.12f, center = Offset(c.x - r * 0.2f, c.y - r * 0.2f))
}

@Composable
fun NekoSplash(onFinished: () -> Unit) {
    val open = ImageBitmap.imageResource(R.drawable.neko_splash_open)
    val blink = ImageBitmap.imageResource(R.drawable.neko_splash_blink)

    // Partículas geradas uma vez, com semente fixa (mesma abertura sempre, sem custo por frame)
    val bursts = remember {
        val r = Random(11)
        val fills = listOf(LightBlue, Cyan, Lilac, Purple)
        List(16) { i ->
            val a = (i / 16f) * 2f * PI.toFloat() + r.nextFloat() * 0.35f
            val f = 0.72f + r.nextFloat() * 0.28f
            val k = i % 4
            Burst(cos(a) * f, sin(a) * f, 0.032f + r.nextFloat() * 0.04f, r.nextFloat() * 380f,
                (if (r.nextBoolean()) 1f else -1f) * (25f + r.nextFloat() * 50f), fills[k], if (k >= 2) OutlinePurple else OutlineBlue)
        }
    }
    val sparkles = remember {
        val r = Random(5)
        List(14) {
            val a = r.nextFloat() * 2f * PI.toFloat(); val f = 0.35f + r.nextFloat() * 0.75f
            Sparkle(cos(a) * f, sin(a) * f, 0.012f + r.nextFloat() * 0.022f, r.nextFloat() * 700f,
                if (r.nextInt(3) == 0) Color.White else if (r.nextBoolean()) Cyan else Lilac)
        }
    }
    val shooters = remember {
        val r = Random(23)
        val palette = listOf(LightBlue, Cyan, Lilac, Purple, Color.White)
        List(30) {
            val depth = r.nextFloat()                                   // 0 = longe (pequena, lenta, fraca), 1 = perto
            Shooter(
                ts = 1850f + r.nextFloat().pow(1.5f) * 1150f,          // concentra no começo: a chuva vai rareando
                dur = 1350f - 600f * depth,
                x0 = -0.2f + r.nextFloat() * 1.15f, y0 = 0.3f + r.nextFloat() * 0.85f,
                angle = -(0.70f + r.nextFloat() * 0.25f),               // diagonal para cima e para a direita
                travel = 0.55f + r.nextFloat() * 0.5f,
                size = 0.016f + 0.036f * depth, trail = 0.10f + 0.20f * depth, bright = 0.5f + 0.5f * depth,
                color = palette[r.nextInt(palette.size)], phase = r.nextFloat() * 6.28f, spin = 40f + r.nextFloat() * 90f,
            )
        }
    }
    val dust = remember {
        val r = Random(3)
        List(36) { Dust(r.nextFloat(), r.nextFloat(), 0.0016f + r.nextFloat() * 0.003f, r.nextFloat() * 6.28f, if (r.nextBoolean()) LightBlue else Lilac) }
    }
    val path = remember { Path() }

    val clock = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        clock.animateTo(TOTAL, tween(TOTAL.toInt(), easing = LinearEasing))
        onFinished()
    }

    Box(
        Modifier.fillMaxSize()
            .blockTouchesBehind()                                              // nenhum toque chega na biblioteca durante a splash
            .pointerInput(Unit) { detectTapGestures { onFinished() } }         // toque para pular
            .graphicsLayer { alpha = 1f - smooth(seg(clock.value, 3800f, TOTAL)) } // transição final sem corte
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val t = clock.value
            val w = size.width; val h = size.height; val unit = hypot(w, h)
            val cx = w / 2f; val cy = h * 0.46f

            // Mesmo gradiente da biblioteca: a transição final não tem "troca" de cor
            drawRect(Neko.Background)

            // ---------- Neko (etapa 1) ----------
            val intro = seg(t, 0f, 600f)
            val outro = seg(t, 1850f, 2500f)
            val nekoAlpha = smooth(intro) * (1f - smooth(outro))

            // brilho místico atrás da Neko, pulsa quando ela pisca
            val pulse = smooth(seg(t, 700f, 1000f)) * (1f - smooth(seg(t, 1000f, 2300f)))
            glow(Offset(cx, cy), w * 0.75f, Purple, 0.20f * nekoAlpha + 0.30f * pulse)
            glow(Offset(cx, cy), w * 0.5f, Cyan, 0.12f * nekoAlpha + 0.22f * pulse)

            if (nekoAlpha > 0.01f) {
                val winking = t in 760f..1250f
                val img = if (winking) blink else open
                val fit = min(w * 0.68f / open.width, h * 0.56f / open.height)
                val dw = open.width * fit; val dh = open.height * fit
                val bob = sin(t / 450f) * h * 0.006f - h * 0.02f * outro
                val sc = (0.82f + 0.18f * easeOutBack(intro)) * (1f + 0.025f * sin(PI.toFloat() * seg(t, 760f, 1000f))) * (1f + 0.06f * outro)
                scale(sc, Offset(cx, cy + bob)) {
                    drawImage(
                        img, dstOffset = IntOffset((cx - dw / 2f).roundToInt(), (cy + bob - dh / 2f).roundToInt()),
                        dstSize = IntSize(dw.roundToInt(), dh.roundToInt()), alpha = nekoAlpha, filterQuality = FilterQuality.Medium,
                    )
                }
            }

            // ---------- Estrelas mágicas (etapa 2) ----------
            val rx = w * 0.46f; val ry = h * 0.27f
            val ring = seg(t, 800f, 1500f)
            if (ring in 0.001f..0.999f) {
                val e = easeOut(ring)
                drawCircle(Cyan.copy(alpha = (1f - ring) * 0.55f), radius = w * (0.08f + 0.55f * e), center = Offset(cx, cy), style = Stroke(width = w * 0.012f * (1f - ring) + 1f))
                drawCircle(Lilac.copy(alpha = (1f - ring) * 0.35f), radius = w * (0.05f + 0.40f * e), center = Offset(cx, cy), style = Stroke(width = w * 0.008f * (1f - ring) + 1f))
            }
            for (s in sparkles) {
                val u = seg(t, 800f + s.delay, 800f + s.delay + 420f)
                if (u <= 0f || u >= 1f) continue
                val pop = sin(PI.toFloat() * u)
                val p = Offset(cx + s.ax * rx * easeOut(u), cy + s.ay * ry * easeOut(u))
                val r = s.size * w * pop
                path.star(p.x, p.y, r * 1.6f, r * 0.28f, 4, 0f)           // brilho de 4 pontas
                drawPath(path, s.color.copy(alpha = 0.95f * pop))
                glow(p, r * 3f, s.color, 0.45f * pop)
            }
            for (b in bursts) {
                val start = 800f + b.delay
                val u = seg(t, start, start + 480f)
                if (u <= 0f) continue
                val a = 1f - smooth(seg(t, 1850f + b.delay * 0.4f, 2500f))
                if (a <= 0f) continue
                val grow = easeOutBack(u).coerceAtLeast(0f)
                val reach = 0.3f + 0.7f * easeOut(u)
                val floatT = (t - start) / 1000f
                val p = Offset(
                    cx + b.ax * rx * reach + sin(floatT * 2.2f + b.spin) * w * 0.006f,
                    cy + b.ay * ry * reach + cos(floatT * 1.8f + b.spin) * h * 0.004f,
                )
                val r = b.size * w * grow
                glow(p, r * 2.6f, b.fill, 0.5f * a * min(1f, u * 2f))
                cartoonStar(path, p, r, b.spin * floatT, b.fill, b.outline, a * min(1f, u * 3f))
            }

            // ---------- Chuva de estrelas cadentes (etapa 3) ----------
            val sky = smooth(seg(t, 1800f, 2300f)) * (1f - smooth(seg(t, 3700f, 4300f)))
            if (sky > 0.01f) {
                for (d in dust) {
                    val tw = 0.5f + 0.5f * sin(t * 0.006f + d.phase)
                    drawCircle(d.color.copy(alpha = 0.55f * tw * sky), radius = d.r * w, center = Offset(d.x * w, d.y * h))
                }
            }
            for (s in shooters) {
                val u = (t - s.ts) / s.dur
                if (u <= 0f || u >= 1f) continue
                val env = smooth(seg(u, 0f, 0.12f)) * (1f - smooth(seg(u, 0.6f, 1f))) * s.bright // rastro some gradualmente
                val dir = Offset(cos(s.angle), sin(s.angle))
                val head = Offset(s.x0 * w, s.y0 * h) + dir * (s.travel * unit * u)
                val len = s.trail * unit * (0.35f + 0.65f * smooth(seg(u, 0f, 0.3f)))
                val tail = head - dir * len
                val twinkle = 0.85f + 0.15f * sin(t * 0.03f + s.phase)
                val sz = s.size * w

                drawLine(
                    Brush.linearGradient(listOf(s.color.copy(alpha = 0f), s.color.copy(alpha = 0.45f * env), s.color.copy(alpha = 0.9f * env)), start = tail, end = head),
                    start = tail, end = head, strokeWidth = sz * 0.55f, cap = StrokeCap.Round,
                )
                val coreTail = head - dir * (len * 0.55f)
                drawLine(
                    Brush.linearGradient(listOf(Color.White.copy(alpha = 0f), Color.White.copy(alpha = 0.95f * env)), start = coreTail, end = head),
                    start = coreTail, end = head, strokeWidth = sz * 0.16f, cap = StrokeCap.Round,
                )
                glow(head, sz * 2.4f * twinkle, s.color, 0.55f * env)
                path.star(head.x, head.y, sz * 0.5f * twinkle, sz * 0.22f * twinkle, 5, s.spin * u)
                drawPath(path, Color.White.copy(alpha = 0.95f * env))
            }
        }
    }
}
