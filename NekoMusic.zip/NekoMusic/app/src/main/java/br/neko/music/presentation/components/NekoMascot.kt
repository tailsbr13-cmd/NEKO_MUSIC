package br.neko.music.presentation.components

import android.provider.Settings
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.imageResource
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import br.neko.music.R
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sin

/*
 * Mascote do cabeçalho: ocupa EXATAMENTE o espaço da antiga logo (o tamanho e o recorte vêm de quem chama).
 *  - playing = false  -> Neko dormindo (2 frames em "respiração" + Zzz subindo)
 *  - playing = true   -> Neko dançando (6 frames em loop com fusão suave + notas musicais flutuando)
 * `playing` vem do estado real do player; `running` pausa o relógio quando a tela não está visível.
 * Todos os frames são os originais enviados (só recortados). Efeitos (Zzz, notas, brilhos) são desenhados no Canvas.
 */
private val SleepIds = intArrayOf(R.drawable.neko_sleep_1, R.drawable.neko_sleep_2)
private val DanceIds = intArrayOf(
    R.drawable.neko_dance_1, R.drawable.neko_dance_2, R.drawable.neko_dance_3,
    R.drawable.neko_dance_4, R.drawable.neko_dance_5, R.drawable.neko_dance_6,
)

private val LightBlue = Color(0xFFBFE4FF)
private val CyanFx = Color(0xFF7FF2E2)
private val LilacFx = Color(0xFFE0CFFF)
private val PurpleFx = Color(0xFFB58CFF)
private val OutlineFx = Color(0xFF0B1A52)
private val ZColors = listOf(Color(0xFFE6D8FF), Color(0xFFB8F7EE), Color(0xFFCDE6FF))

private class NoteP(
    val period: Float, val offset: Float, val x: Float, val y0: Float, val y1: Float,
    val size: Float, val double: Boolean, val color: Color, val sway: Float,
)
private val Notes = listOf(
    NoteP(2600f, 0f, 0.10f, 0.80f, 0.30f, 0.20f, false, LightBlue, 1.0f),
    NoteP(3100f, 900f, 0.90f, 0.75f, 0.12f, 0.24f, true, LilacFx, -1.0f),
    NoteP(2800f, 1700f, 0.15f, 0.55f, 0.08f, 0.17f, true, CyanFx, 0.8f),
    NoteP(3300f, 400f, 0.85f, 0.92f, 0.42f, 0.17f, false, PurpleFx, -0.8f),
    NoteP(2400f, 1300f, 0.07f, 0.45f, 0.10f, 0.15f, false, LilacFx, 1.3f),
)

private fun smooth(x: Float) = x * x * (3f - 2f * x)
private fun seg(t: Float, a: Float, b: Float) = ((t - a) / (b - a)).coerceIn(0f, 1f)

@Composable
fun NekoMascot(playing: Boolean, running: Boolean, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    // "Remover animações" ligado no Android: mostra só o frame parado do estado atual
    val reduced = remember { Settings.Global.getFloat(ctx.contentResolver, Settings.Global.ANIMATOR_DURATION_SCALE, 1f) == 0f }
    val sleep = SleepIds.map { ImageBitmap.imageResource(it) }
    val dance = DanceIds.map { ImageBitmap.imageResource(it) }

    // Transição suave entre dormir e dançar (0 = dormindo, 1 = dançando); nasce já no estado atual
    val mix = remember { Animatable(if (playing) 1f else 0f) }
    LaunchedEffect(playing) { mix.animateTo(if (playing) 1f else 0f, tween(300, easing = FastOutSlowInEasing)) }

    // Relógio a ~30 fps, só enquanto a tela está visível (sem custo em segundo plano)
    var tick by remember { mutableLongStateOf(0L) }
    LaunchedEffect(running, reduced) {
        if (!running || reduced) return@LaunchedEffect
        var last = 0L
        while (true) withFrameNanos { n -> if (n - last >= 33_000_000L) { last = n; tick = n } }
    }

    Box(modifier) {
        Canvas(Modifier.fillMaxSize()) {
            tick // lido só aqui: atualiza apenas o desenho, sem recompor a tela
            val s = size.minDimension
            val animate = !reduced
            val t = if (animate) ((tick / 1_000_000L) % 1_000_000L).toFloat() else 0f
            val m = mix.value
            drawBackdrop()
            if (m < 0.999f) drawSleeping(sleep, t, s, 1f - m, animate)
            if (m > 0.001f) drawDancing(dance, t, s, m, animate)
        }
    }
}

/** Fundo azul no lugar do antigo fundo da logo: mantém o quadrado de cantos arredondados e dá contraste ao cabelo escuro. */
private fun DrawScope.drawBackdrop() {
    drawRect(Brush.verticalGradient(listOf(Color(0xFF8CBBFF), Color(0xFF2E63E8), Color(0xFF102B83))))
    drawRoundRect(
        Color(0xFF69EAD8).copy(alpha = 0.55f), cornerRadius = CornerRadius(size.minDimension * 0.21f),
        style = Stroke(width = size.minDimension * 0.04f),
    )
}

private fun DrawScope.frame(img: ImageBitmap, maxW: Float, maxH: Float, cx: Float, bottom: Float, a: Float, scale: Float = 1f) {
    if (a <= 0.005f) return
    val fit = min(maxW / img.width, maxH / img.height) * scale
    val dw = img.width * fit
    val dh = img.height * fit
    drawImage(
        img, dstOffset = IntOffset((cx - dw / 2f).roundToInt(), (bottom - dh).roundToInt()),
        dstSize = IntSize(dw.roundToInt(), dh.roundToInt()), alpha = a.coerceIn(0f, 1f), filterQuality = FilterQuality.Medium,
    )
}

// ---------------------------------------------------------------- dormindo
private fun DrawScope.drawSleeping(f: List<ImageBitmap>, t: Float, s: Float, a: Float, animate: Boolean) {
    val ph = (t % 5200f) / 2600f
    val w = if (animate) 0.5f - 0.5f * cos(PI.toFloat() * ph) else 0f     // 0 -> 1 -> 0: respiração lenta
    val breath = 1f + 0.018f * w
    frame(f[0], s * 0.88f, s * 0.7f, s * 0.47f, s * 0.97f, a, breath)
    frame(f[1], s * 0.88f, s * 0.7f, s * 0.47f, s * 0.97f, a * w, breath)
    if (!animate) return
    for (i in 0 until 3) {                                                   // Zzz: sobem, somem e reaparecem
        val u = ((t + i * 1000f) % 3000f) / 3000f
        val env = sin(PI.toFloat() * u).pow(0.8f) * a
        val c = Offset(s * (0.62f + 0.24f * u) + sin(u * 9f + i) * s * 0.02f, s * (0.44f - 0.38f * u))
        zee(c, s * (0.09f + 0.07f * u) * (if (i == 1) 0.85f else 1f), ZColors[i], env)
    }
}

private fun DrawScope.zee(c: Offset, size: Float, color: Color, a: Float) {
    if (a <= 0.01f) return
    val p = Path().apply {
        moveTo(c.x - size / 2f, c.y - size / 2f); lineTo(c.x + size / 2f, c.y - size / 2f)
        lineTo(c.x - size / 2f, c.y + size / 2f); lineTo(c.x + size / 2f, c.y + size / 2f)
    }
    drawPath(p, OutlineFx.copy(alpha = 0.55f * a), style = Stroke(width = size * 0.36f, cap = StrokeCap.Round, join = StrokeJoin.Round))
    drawPath(p, color.copy(alpha = a), style = Stroke(width = size * 0.2f, cap = StrokeCap.Round, join = StrokeJoin.Round))
}

// ---------------------------------------------------------------- dançando
private fun DrawScope.drawDancing(f: List<ImageBitmap>, t: Float, s: Float, a: Float, animate: Boolean) {
    val pos = if (animate) t / 150f else 0f                                  // 150 ms por frame
    val i = floor(pos).toInt()
    val blend = if (animate) smooth(((pos - i - 0.55f) / 0.45f).coerceIn(0f, 1f)) else 0f  // fusão no fim de cada frame: loop sem corte
    val bounce = if (animate) abs(sin(PI.toFloat() * pos)) * s * 0.022f else 0f             // pulinho no ritmo dos frames
    val bottom = s * 0.97f - bounce
    frame(f[i % f.size], s * 0.9f, s * 0.9f, s * 0.5f, bottom, a)
    frame(f[(i + 1) % f.size], s * 0.9f, s * 0.9f, s * 0.5f, bottom, a * blend)
    if (!animate) return

    for (n in Notes) {                                                       // notas ♪ ♫ flutuando pelas laterais
        val u = ((t + n.offset) % n.period) / n.period
        val env = smooth(seg(u, 0f, 0.18f)) * (1f - smooth(seg(u, 0.65f, 1f))) * a
        if (env <= 0.01f) continue
        val sz = n.size * s * (0.8f + 0.3f * sin(PI.toFloat() * u))
        val c = Offset(
            s * n.x + sin(u * 7.5f + n.sway * 2f) * s * 0.035f,
            s * (n.y0 + (n.y1 - n.y0) * u),
        )
        glow(c, sz * 1.3f, n.color, 0.35f * env)
        note(c, sz * 1.12f, n.double, OutlineFx, env * 0.55f)                // contorno escuro para contraste
        note(c, sz, n.double, n.color, env)
        if (u in 0.25f..0.6f) {                                              // cintilação
            val tw = 0.5f + 0.5f * sin(t * 0.02f + n.sway * 3f)
            sparkle(Offset(c.x + sz * 0.5f, c.y - sz * 0.6f), sz * 0.3f, Color.White, env * tw)
        }
    }
}

private fun DrawScope.glow(c: Offset, radius: Float, color: Color, a: Float) {
    if (a <= 0.01f || radius <= 0f) return
    drawCircle(Brush.radialGradient(listOf(color.copy(alpha = a), color.copy(alpha = 0f)), center = c, radius = radius), radius = radius, center = c)
}

private fun DrawScope.sparkle(c: Offset, r: Float, color: Color, a: Float) {
    if (a <= 0.01f) return
    val p = Path().apply {
        moveTo(c.x, c.y - r); quadraticBezierTo(c.x, c.y, c.x + r, c.y)
        quadraticBezierTo(c.x, c.y, c.x, c.y + r); quadraticBezierTo(c.x, c.y, c.x - r, c.y)
        quadraticBezierTo(c.x, c.y, c.x, c.y - r); close()
    }
    drawPath(p, color.copy(alpha = a))
}

/** ♪ (double = false) e ♫ (double = true) desenhados com formas: não dependem de fonte do aparelho. */
private fun DrawScope.note(c: Offset, s: Float, double: Boolean, color: Color, a: Float) {
    if (a <= 0.01f) return
    val col = color.copy(alpha = a)
    val hw = s * 0.52f
    val hh = s * 0.36f
    val sw = s * 0.11f
    fun head(x: Float, y: Float) = rotate(-22f, Offset(x, y)) { drawOval(col, Offset(x - hw / 2f, y - hh / 2f), Size(hw, hh)) }
    if (!double) {
        val hx = c.x - s * 0.18f
        val hy = c.y + s * 0.38f
        head(hx, hy)
        val sx = hx + hw * 0.42f
        val top = c.y - s * 0.55f
        drawLine(col, Offset(sx, hy - s * 0.04f), Offset(sx, top), strokeWidth = sw, cap = StrokeCap.Round)
        val flag = Path().apply { moveTo(sx, top); quadraticBezierTo(sx + s * 0.42f, top + s * 0.12f, sx + s * 0.3f, top + s * 0.5f) }
        drawPath(flag, col, style = Stroke(width = sw * 1.1f, cap = StrokeCap.Round))
    } else {
        val h1x = c.x - s * 0.40f
        val h1y = c.y + s * 0.40f
        val h2x = c.x + s * 0.20f
        val h2y = c.y + s * 0.28f
        head(h1x, h1y); head(h2x, h2y)
        val s1 = h1x + hw * 0.42f
        val s2 = h2x + hw * 0.42f
        val top = c.y - s * 0.45f
        drawLine(col, Offset(s1, h1y - s * 0.04f), Offset(s1, top), strokeWidth = sw, cap = StrokeCap.Round)
        drawLine(col, Offset(s2, h2y - s * 0.04f), Offset(s2, top - s * 0.12f), strokeWidth = sw, cap = StrokeCap.Round)
        drawLine(col, Offset(s1, top), Offset(s2, top - s * 0.12f), strokeWidth = sw * 1.5f)
    }
}
