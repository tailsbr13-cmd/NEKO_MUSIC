package br.neko.music.media

/**
 * Identifica áudios do WhatsApp / WhatsApp Business (mensagens de voz e áudios recebidos).
 * Só classifica: nada é apagado, movido ou alterado no aparelho.
 *
 * Dois critérios (qualquer um basta):
 *  1. Alguma PASTA do caminho começa com "whatsapp" ou é "com.whatsapp*"
 *     (cobre WhatsApp/Media/WhatsApp Audio, WhatsApp Voice Notes, WhatsApp Business/Media/WhatsApp Business Audio
 *      e o caminho novo Android/media/com.whatsapp/WhatsApp/...).
 *  2. Nome no padrão do app: AUD-20230510-WA0002, PTT-..., VOICE-..., VID-... (mesmo copiado para outra pasta).
 *
 * Músicas com artista/álbum desconhecido ou baixadas de outras fontes NÃO são afetadas.
 */
object WhatsAppFilter {
    private val namePattern = Regex("""^(AUD|PTT|VOICE|VID)-\d{8}-WA\d{3,5}(\D.*)?$""", RegexOption.IGNORE_CASE)

    fun isWhatsApp(song: Song): Boolean = isWhatsAppPath(song.path)

    fun isWhatsAppPath(path: String): Boolean {
        val normalized = path.replace('\\', '/')
        val folders = normalized.split('/').dropLast(1)
        val inWhatsAppFolder = folders.any {
            val f = it.trim().lowercase()
            f.startsWith("whatsapp") || f == "com.whatsapp" || f.startsWith("com.whatsapp.")
        }
        return inWhatsAppFolder || namePattern.matches(normalized.substringAfterLast('/'))
    }
}
