package br.neko.music.presentation.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.snap
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import br.neko.music.audio.EqModel
import br.neko.music.presentation.theme.Neko
import br.neko.music.visualizer.AudioVisualizerEngine
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.roundToInt
import kotlin.math.sin

private val SilverCap = listOf(Color(0xFFF6F8FC), Color(0xFFB8C1D3), Color(0xFF6B7489))

fun fmtDb(v: Float): String = (if (v > 0f) "+" else "") + (if (v % 1f == 0f) v.toInt().toString() else "%.1f".format(v))

// ====================================================================== fader vertical metálico
private fun faderValue(y: Float, height: Float, capH: Float): Float {
    val top = capH / 2f
    val bottom = height - capH / 2f
    val frac = ((y - top) / (bottom - top)).coerceIn(0f, 1f)
    val raw = EqModel.MAX_DB - frac * (EqModel.MAX_DB - EqModel.MIN_DB)
    return (raw * 2f).roundToInt() / 2f   // passos de 0,5 dB
}

/** Slider vertical com cursor prateado, LED ciano, escala e preenchimento luminoso. Toque duplo = 0 dB. */
@Composable
fun EqFader(value: Float, label: String, enabled: Boolean, onChange: (Float) -> Unit, modifier: Modifier = Modifier, height: Dp = 190.dp) {
    var dragging by remember { mutableStateOf(false) }
    val shown by animateFloatAsState(value, animationSpec = if (dragging) snap() else tween(240), label = "fader")
    val change by rememberUpdatedState(onChange)

    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(fmtDb(value), color = if (enabled) Neko.Cyan else Neko.SteelGray, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 11.sp, maxLines = 1)
        Spacer(Modifier.height(4.dp))
        Canvas(
            Modifier.height(height).fillMaxWidth()
                .pointerInput(Unit) {
                    val capH = 24.dp.toPx()
                    detectDragGestures(
                        onDragStart = { dragging = true; change(faderValue(it.y, size.height.toFloat(), capH)) },
                        onDragEnd = { dragging = false }, onDragCancel = { dragging = false },
                    ) { c, _ -> c.consume(); change(faderValue(c.position.y, size.height.toFloat(), capH)) }
                }
                .pointerInput(Unit) {
                    val capH = 24.dp.toPx()
                    detectTapGestures(onDoubleTap = { change(0f) }, onTap = { change(faderValue(it.y, size.height.toFloat(), capH)) })
                }
        ) {
            val on = if (enabled) 1f else 0.35f
            val capH = 24.dp.toPx()
            val capW = minOf(size.width, 40.dp.toPx())
            val top = capH / 2f
            val bottom = size.height - capH / 2f
            val cx = size.width / 2f
            val y = top + (EqModel.MAX_DB - shown) / (EqModel.MAX_DB - EqModel.MIN_DB) * (bottom - top)

            // escala: um traço a cada 3 dB, o do 0 dB em destaque
            for (k in 0..8) {
                val ty = top + k / 8f * (bottom - top)
                val major = k == 4
                val len = if (major) 10.dp.toPx() else 6.dp.toPx()
                val c = if (major) Neko.Cyan.copy(alpha = 0.9f * on) else Neko.SteelGray.copy(alpha = 0.55f)
                drawLine(c, Offset(cx - 22.dp.toPx(), ty), Offset(cx - 22.dp.toPx() + len, ty), strokeWidth = 1.5.dp.toPx())
                drawLine(c, Offset(cx + 22.dp.toPx(), ty), Offset(cx + 22.dp.toPx() - len, ty), strokeWidth = 1.5.dp.toPx())
            }
            // fenda
            drawRoundRect(Color(0xFF04060A), Offset(cx - 5.dp.toPx(), top - 2.dp.toPx()), Size(10.dp.toPx(), bottom - top + 4.dp.toPx()), CornerRadius(5.dp.toPx()))
            // preenchimento ciano abaixo do cursor (como nos faders do aparelho de referência)
            drawRoundRect(Neko.Cyan.copy(alpha = 0.22f * on), Offset(cx - 8.dp.toPx(), y), Size(16.dp.toPx(), bottom - y + 4.dp.toPx()), CornerRadius(8.dp.toPx()))
            drawRoundRect(
                Brush.verticalGradient(listOf(Neko.Cyan.copy(alpha = on), Color(0xFF1E6BFF).copy(alpha = on)), startY = y, endY = bottom),
                Offset(cx - 3.dp.toPx(), y), Size(6.dp.toPx(), bottom - y + 2.dp.toPx()), CornerRadius(3.dp.toPx()),
            )
            // cursor metálico
            val capTop = y - capH / 2f
            drawRoundRect(Color.Black.copy(alpha = 0.5f), Offset(cx - capW / 2f + 1.dp.toPx(), capTop + 3.dp.toPx()), Size(capW, capH), CornerRadius(4.dp.toPx()))
            drawRoundRect(Brush.verticalGradient(SilverCap, startY = capTop, endY = capTop + capH), Offset(cx - capW / 2f, capTop), Size(capW, capH), CornerRadius(4.dp.toPx()))
            drawRoundRect(Color(0xFF2A3040), Offset(cx - capW / 2f, capTop), Size(capW, capH), CornerRadius(4.dp.toPx()), style = Stroke(1.dp.toPx()))
            drawRoundRect(Color.White.copy(alpha = 0.7f), Offset(cx - capW / 2f + 3.dp.toPx(), capTop + 1.5.dp.toPx()), Size(capW - 6.dp.toPx(), 1.5.dp.toPx()), CornerRadius(1.dp.toPx()))
            // LED ciano no meio do cursor
            drawRoundRect(Neko.Cyan.copy(alpha = 0.35f * on), Offset(cx - capW / 2f + 2.dp.toPx(), y - 3.5.dp.toPx()), Size(capW - 4.dp.toPx(), 7.dp.toPx()), CornerRadius(3.dp.toPx()))
            drawRoundRect(Neko.Cyan.copy(alpha = on), Offset(cx - capW / 2f + 5.dp.toPx(), y - 1.5.dp.toPx()), Size(capW - 10.dp.toPx(), 3.dp.toPx()), CornerRadius(1.5.dp.toPx()))
        }
        Spacer(Modifier.height(4.dp))
        Text(label, color = Neko.IceWhite, fontFamily = FontFamily.Monospace, fontSize = 10.sp, maxLines = 1)
    }
}

// ====================================================================== botão giratório (preamp)
private fun angleOf(x: Float, y: Float, w: Float, h: Float): Float =
    Math.toDegrees(atan2((x - w / 2f).toDouble(), -(y - h / 2f).toDouble())).toFloat()   // 0° = cima, horário positivo

/** Botão rotativo metálico: arraste em círculo. LEDs ciano mostram o ganho. Toque duplo = 0 dB. */
@Composable
fun EqKnob(value: Float, enabled: Boolean, onChange: (Float) -> Unit, modifier: Modifier = Modifier) {
    var dragging by remember { mutableStateOf(false) }
    val shown by animateFloatAsState(value, animationSpec = if (dragging) snap() else tween(200), label = "knob")
    val change by rememberUpdatedState(onChange)
    val current by rememberUpdatedState(value)

    Canvas(
        modifier.aspectRatio(1f)
            .pointerInput(Unit) {
                var last = 0f
                var raw = 0f
                detectDragGestures(
                    onDragStart = { dragging = true; last = angleOf(it.x, it.y, size.width.toFloat(), size.height.toFloat()); raw = current },
                    onDragEnd = { dragging = false }, onDragCancel = { dragging = false },
                ) { c, _ ->
                    c.consume()
                    val a = angleOf(c.position.x, c.position.y, size.width.toFloat(), size.height.toFloat())
                    var d = a - last
                    if (d > 180f) d -= 360f
                    if (d < -180f) d += 360f
                    last = a
                    raw = (raw + d / 135f * EqModel.MAX_DB).coerceIn(EqModel.MIN_DB, EqModel.MAX_DB)   // acumula: sem saltos
                    change((raw * 2f).roundToInt() / 2f)
                }
            }
            .pointerInput(Unit) { detectTapGestures(onDoubleTap = { change(0f) }) }
    ) {
        val on = if (enabled) 1f else 0.4f
        val c = center
        val r = size.minDimension / 2f
        val ang = shown / EqModel.MAX_DB * 135f

        // anel de LEDs (21 pontos em 270°): acendem do centro até o valor atual
        for (i in 0 until 21) {
            val a = -135f + 270f * i / 20f
            val rad = Math.toRadians(a.toDouble())
            val p = Offset(c.x + (sin(rad) * r * 0.9f).toFloat(), c.y - (cos(rad) * r * 0.9f).toFloat())
            val lit = (ang >= 0f && a >= -0.01f && a <= ang + 0.01f) || (ang < 0f && a <= 0.01f && a >= ang - 0.01f)
            val dot = r * (if (i == 10) 0.06f else 0.045f)
            if (lit) {
                drawCircle(Neko.Cyan.copy(alpha = 0.28f * on), radius = dot * 2.2f, center = p)
                drawCircle(Neko.Cyan.copy(alpha = on), radius = dot, center = p)
            } else drawCircle(Neko.SteelGray.copy(alpha = 0.3f), radius = dot, center = p)
        }
        // corpo
        drawCircle(Color.Black.copy(alpha = 0.5f), radius = r * 0.76f, center = Offset(c.x + r * 0.02f, c.y + r * 0.05f))
        drawCircle(
            Brush.radialGradient(listOf(Color(0xFF626A7C), Color(0xFF1A1D25)), center = Offset(c.x - r * 0.2f, c.y - r * 0.25f), radius = r * 0.95f),
            radius = r * 0.74f, center = c,
        )
        drawCircle(Color(0xFF05070B), radius = r * 0.74f, center = c, style = Stroke(r * 0.03f))
        for (k in 0 until 36) {                                   // serrilhado da borda
            val rad = Math.toRadians(k * 10.0)
            val p1 = Offset(c.x + (sin(rad) * r * 0.62f).toFloat(), c.y - (cos(rad) * r * 0.62f).toFloat())
            val p2 = Offset(c.x + (sin(rad) * r * 0.72f).toFloat(), c.y - (cos(rad) * r * 0.72f).toFloat())
            drawLine(Color.White.copy(alpha = 0.14f), p1, p2, strokeWidth = r * 0.016f)
        }
        drawCircle(
            Brush.radialGradient(listOf(Color(0xFF3B4352), Color(0xFF0C0E13)), center = Offset(c.x - r * 0.15f, c.y - r * 0.2f), radius = r * 0.62f),
            radius = r * 0.52f, center = c,
        )
        // indicador luminoso
        val ir = Math.toRadians(ang.toDouble())
        val p1 = Offset(c.x + (sin(ir) * r * 0.2f).toFloat(), c.y - (cos(ir) * r * 0.2f).toFloat())
        val p2 = Offset(c.x + (sin(ir) * r * 0.45f).toFloat(), c.y - (cos(ir) * r * 0.45f).toFloat())
        drawCircle(Brush.radialGradient(listOf(Neko.Cyan.copy(alpha = 0.6f * on), Neko.Cyan.copy(alpha = 0f)), center = p2, radius = r * 0.16f), radius = r * 0.16f, center = p2)
        drawLine(Neko.Cyan.copy(alpha = on), p1, p2, strokeWidth = r * 0.07f, cap = StrokeCap.Round)
    }
}

// ====================================================================== botões "físicos"
/** Botão de painel: corpo metálico escuro em relevo; selecionado = borda e texto ciano com brilho. */
@Composable
fun MetalButton(text: String, selected: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier, fontSize: TextUnit = 13.sp, height: Dp = 44.dp) {
    val shape = RoundedCornerShape(8.dp)
    Box(
        modifier.height(height).clip(shape)
            .background(Brush.verticalGradient(if (selected) listOf(Color(0xFF1F4A8F), Color(0xFF0D2347)) else listOf(Color(0xFF414653), Color(0xFF1A1D25))))
            .border(1.dp, if (selected) Brush.verticalGradient(listOf(Neko.Cyan, Neko.Cyan)) else Brush.verticalGradient(listOf(Color(0xFF8A93A6), Color(0xFF0A0C10))), shape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Text(text, color = if (selected) Neko.Cyan else Neko.IceWhite, fontWeight = FontWeight.Bold, fontSize = fontSize, maxLines = 1, textAlign = TextAlign.Center, modifier = Modifier.padding(horizontal = 4.dp))
    }
}

/** Botão ON/OFF azul com LED, como os botões "ON" do painel de referência. */
@Composable
fun PowerButton(on: Boolean, onToggle: () -> Unit, modifier: Modifier = Modifier) {
    val shape = RoundedCornerShape(7.dp)
    Box(
        modifier.height(36.dp).clip(shape)
            .background(Brush.verticalGradient(if (on) listOf(Color(0xFF2F7BFF), Color(0xFF0B3FA8)) else listOf(Color(0xFF3A3F4B), Color(0xFF16181F))))
            .border(1.dp, if (on) Brush.verticalGradient(listOf(Color(0xFF9CD0FF), Color(0xFF1749D8))) else Brush.verticalGradient(listOf(Color(0xFF7B8497), Color(0xFF0A0C10))), shape)
            .clickable(onClick = onToggle),
        contentAlignment = Alignment.Center,
    ) {
        Text(if (on) "ON" else "OFF", color = if (on) Color.White else Neko.SteelGray, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, fontSize = 13.sp, modifier = Modifier.padding(horizontal = 14.dp))
    }
}

// ====================================================================== display de espectro colorido
private val SpecStops = listOf(
    0f to Color(0xFF69EAD8), 0.3f to Color(0xFF46F06A), 0.55f to Color(0xFFFFE94A), 0.78f to Color(0xFFFF9A3C), 1f to Color(0xFFB45CFF),
)

private fun specColor(f: Float): Color {
    for (i in 0 until SpecStops.size - 1) {
        val (a, ca) = SpecStops[i]
        val (b, cb) = SpecStops[i + 1]
        if (f <= b) return lerp(ca, cb, ((f - a) / (b - a)).coerceIn(0f, 1f))
    }
    return SpecStops.last().second
}

/**
 * Display preto com espectro REAL (FFT da Visualizer API, a mesma do player) em colunas segmentadas
 * ciano -> verde -> amarelo -> laranja -> roxo, com marcador de pico e linha luminosa no topo.
 * O relógio de frames só roda enquanto há movimento (para quando a música para).
 */
@Composable
fun EqSpectrum(engine: AudioVisualizerEngine, active: Boolean, modifier: Modifier = Modifier) {
    val targets = engine.levels.collectAsStateWithLifecycle()
    val n = AudioVisualizerEngine.BARS
    val display = remember { FloatArray(n) }
    val peaks = remember { FloatArray(n) }
    var frame by remember { mutableLongStateOf(0L) }

    LaunchedEffect(active) {
        while (true) {
            var moving = false
            withFrameNanos { t ->
                val src = targets.value
                for (i in 0 until n) {
                    val goal = if (active) src.getOrElse(i) { 0f } else 0f
                    val d = display[i]
                    val nd = d + (goal - d) * (if (goal > d) 0.5f else 0.10f)
                    display[i] = if (nd < 0.004f) 0f else nd
                    peaks[i] = max(display[i], peaks[i] - 0.012f).let { if (it < 0.004f) 0f else it }
                    if (display[i] > 0f || peaks[i] > 0f) moving = true
                }
                frame = t
            }
            if (!active && !moving) break
        }
    }

    Canvas(modifier) {
        frame
        drawRect(Brush.verticalGradient(listOf(Color(0xFF05070B), Color(0xFF0B1022))))
        val rows = 18
        val gap = 2.dp.toPx()
        val barW = (size.width - gap * (n - 1)) / n
        val cellH = (size.height - gap * (rows - 1)) / rows
        for (i in 0 until n) {
            val lit = (display[i] * rows).roundToInt()
            val x = i * (barW + gap)
            for (r in 0 until rows) {
                val y = size.height - (r + 1) * cellH - r * gap
                val col = when {
                    r < lit -> specColor(r / (rows - 1f))
                    else -> Color.White.copy(alpha = 0.05f)
                }
                drawRoundRect(col, Offset(x, y), Size(barW, cellH), CornerRadius(1.5.dp.toPx()))
            }
            val pr = (peaks[i] * rows).roundToInt() - 1
            if (pr >= lit && pr in 0 until rows) {
                val y = size.height - (pr + 1) * cellH - pr * gap
                drawRoundRect(Color.White.copy(alpha = 0.9f), Offset(x, y), Size(barW, cellH), CornerRadius(1.5.dp.toPx()))
            }
        }
        // linha luminosa no topo das colunas
        val line = Path()
        for (i in 0 until n) {
            val px = i * (barW + gap) + barW / 2f
            val py = size.height - display[i] * size.height * 0.94f
            if (i == 0) line.moveTo(px, py) else line.lineTo(px, py)
        }
        drawPath(line, Neko.Cyan.copy(alpha = 0.22f), style = Stroke(width = 6.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
        drawPath(line, Color.White.copy(alpha = 0.75f), style = Stroke(width = 1.5.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
    }
}
