package br.neko.music.presentation.components

import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.repeatOnLifecycle
import br.neko.music.presentation.theme.Decor
import br.neko.music.presentation.theme.ThemeManager
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.sin

/**
 * Camada decorativa do tema (neve, confetes, corações...). Fica por cima das telas mas NÃO recebe toques
 * (é só um Canvas, sem pointerInput). Leve: ~20 partículas calculadas por fórmula (nada alocado por quadro),
 * ~30 fps, e o relógio só roda com o app visível (RESUMED). Com "remover animações" do Android fica parada.
 */
@Composable
fun ThemeDecor(modifier: Modifier = Modifier) {
    val decor = ThemeManager.resolved.spec.decor
    if (decor == Decor.NONE) return
    val ctx = LocalContext.current
    val reduced = remember { Settings.Global.getFloat(ctx.contentResolver, Settings.Global.ANIMATOR_DURATION_SCALE, 1f) == 0f }
    var tick by remember { mutableLongStateOf(0L) }
    LaunchedEffect(reduced) {
        if (reduced) return@LaunchedEffect
        val owner = ctx as? ComponentActivity ?: return@LaunchedEffect
        owner.lifecycle.repeatOnLifecycle(Lifecycle.State.RESUMED) {
            var last = 0L
            while (true) withFrameNanos { n -> if (n - last >= 33_000_000L) { last = n; tick = n } }
        }
    }
    Canvas(modifier.fillMaxSize()) {
        tick
        val t = if (reduced) 3f else (tick / 1_000_000L % 100_000_000L) / 1000f
        when (decor) {
            Decor.SNOW -> snow(t, 30)
            Decor.XMAS -> { snow(t, 22); xmasLights(t) }
            Decor.CONFETTI -> confetti(t)
            Decor.HEARTS -> hearts(t)
            Decor.FIREWORKS -> fireworks(t)
            Decor.BUBBLES -> bubbles(t)
            Decor.NEON_SPARK -> neonSparks(t)
            Decor.EGGS -> eggs(t)
            Decor.PETALS -> petals(t)
            Decor.BUNTING -> { bunting(t); embers(t) }
            Decor.BATS -> { stars(t); bats(t) }
            Decor.NONE -> {}
        }
    }
}

// ------------------------------------------------------------------ utilidades
/** Número pseudo-aleatório estável em [0,1) por (partícula, canal): sem estado e sem alocação. */
internal fun rnd(i: Int, k: Int): Float { val x = sin(i * 12.9898f + k * 78.233f) * 43758.547f; return x - floor(x) }
private fun DrawScope.dp(v: Float) = v * density
private val Gold = Color(0xFFFFD36B); private val Silver = Color(0xFFE6ECFF)
private val Party = listOf(Color(0xFFFF4FB0), Color(0xFFFFE04A), Color(0xFF2EE6E0), Color(0xFFB36BFF), Color(0xFFFF9A3D))

private fun DrawScope.fall(i: Int, t: Float, speedDp: Float, swayDp: Float, period: Float = 1f): Offset {
    val h = size.height + dp(40f)
    val y = ((t * dp(speedDp) * (0.6f + rnd(i, 1)) + rnd(i, 2) * h) % h) - dp(20f)
    val x = rnd(i, 0) * size.width + sin(t * period + i) * dp(swayDp)
    return Offset(x, y)
}
private fun DrawScope.rise(i: Int, t: Float, speedDp: Float, swayDp: Float): Offset {
    val h = size.height + dp(60f)
    val y = size.height + dp(30f) - ((t * dp(speedDp) * (0.6f + rnd(i, 1)) + rnd(i, 2) * h) % h)
    return Offset(rnd(i, 0) * size.width + sin(t * 0.8f + i * 1.7f) * dp(swayDp), y)
}

// ------------------------------------------------------------------ efeitos
private fun DrawScope.snow(t: Float, n: Int) {
    for (i in 0 until n) {
        val p = fall(i, t, 26f, 14f, 0.7f)
        drawCircle(Color.White.copy(alpha = 0.35f + 0.4f * rnd(i, 3)), dp(1.2f + 2.2f * rnd(i, 4)), p)
    }
}

private fun DrawScope.xmasLights(t: Float) {
    val top = dp(30f)
    val colors = listOf(Color(0xFFFF4D4D), Gold, Color(0xFF4DFF88), Color(0xFF7FD4FF))
    val n = 14
    val path = Path().apply { moveTo(0f, top); quadraticTo(size.width / 2f, top + dp(16f), size.width, top) }
    drawPath(path, Color(0xFF0A2A1A).copy(alpha = 0.7f), style = Stroke(dp(1.2f)))
    for (k in 0..n) {
        val u = k / n.toFloat()
        val x = u * size.width
        val y = top + 4f * dp(8f) * u * (1f - u)
        val tw = 0.55f + 0.45f * sin(t * 2.2f + k * 1.3f)
        val c = colors[k % colors.size]
        drawCircle(c.copy(alpha = 0.25f * tw), dp(7f), Offset(x, y + dp(4f)))
        drawCircle(c.copy(alpha = 0.9f * tw), dp(2.6f), Offset(x, y + dp(4f)))
    }
}

private fun DrawScope.confetti(t: Float) {
    for (i in 0 until 26) {
        val p = fall(i, t, 40f, 18f, 1.1f)
        val c = Party[i % Party.size].copy(alpha = 0.8f)
        rotate((t * 140f * (0.5f + rnd(i, 5)) + i * 40f) % 360f, p) {
            drawRect(c, Offset(p.x - dp(3f), p.y - dp(1.5f)), Size(dp(6f), dp(3f)))
        }
    }
}

internal fun DrawScope.heartPath(c: Offset, s: Float): Path = Path().apply {
    moveTo(c.x, c.y + s * 0.9f)
    cubicTo(c.x - s * 1.6f, c.y - s * 0.1f, c.x - s * 0.9f, c.y - s * 1.2f, c.x, c.y - s * 0.4f)
    cubicTo(c.x + s * 0.9f, c.y - s * 1.2f, c.x + s * 1.6f, c.y - s * 0.1f, c.x, c.y + s * 0.9f)
    close()
}

private fun DrawScope.hearts(t: Float) {
    for (i in 0 until 16) {
        val p = rise(i, t, 28f, 12f)
        val fade = (p.y / size.height).coerceIn(0f, 1f).let { minOf(1f, it * 3f) }
        val s = dp(4f + 6f * rnd(i, 4))
        val c = if (i % 3 == 0) Color(0xFFFF9EBD) else Color(0xFFFF3D6E)
        drawPath(heartPath(p, s * 1.6f), c.copy(alpha = 0.18f * fade))
        drawPath(heartPath(p, s), c.copy(alpha = 0.6f * fade))
    }
}

private fun DrawScope.decorSparkle(c: Offset, r: Float, col: Color, a: Float) {
    if (a <= 0.01f) return
    drawLine(col.copy(alpha = a), Offset(c.x - r, c.y), Offset(c.x + r, c.y), dp(1.2f))
    drawLine(col.copy(alpha = a), Offset(c.x, c.y - r), Offset(c.x, c.y + r), dp(1.2f))
    drawCircle(col.copy(alpha = a * 0.5f), r * 0.35f, c)
}

private fun DrawScope.fireworks(t: Float) {
    for (i in 0 until 20) {
        val tw = 0.5f + 0.5f * sin(t * (1.5f + rnd(i, 3)) + i * 2f)
        decorSparkle(Offset(rnd(i, 0) * size.width, rnd(i, 1) * size.height), dp(2f + 3f * rnd(i, 4)), if (i % 2 == 0) Gold else Silver, 0.7f * tw)
    }
    for (b in 0 until 2) {                                   // dois estouros em ciclos de 6 s
        val cycle = (t + b * 3f) / 6f
        val u = (cycle - floor(cycle)) / 0.45f
        if (u >= 1f) continue
        val id = floor(cycle).toInt() * 2 + b
        val c = Offset(size.width * (0.2f + 0.6f * rnd(id, 7)), size.height * (0.12f + 0.3f * rnd(id, 8)))
        val r = dp(70f) * (1f - (1f - u) * (1f - u))
        val col = if (rnd(id, 9) > 0.5f) Gold else Color(0xFF8CE8FF)
        for (k in 0 until 14) {
            val a = k / 14f * 2f * PI.toFloat()
            val p = Offset(c.x + cos(a) * r, c.y + sin(a) * r + u * dp(10f))
            drawCircle(col.copy(alpha = (1f - u) * 0.9f), dp(2f), p)
            drawLine(col.copy(alpha = (1f - u) * 0.4f), Offset(c.x + cos(a) * r * 0.7f, c.y + sin(a) * r * 0.7f), p, dp(1f))
        }
    }
}

private fun DrawScope.bubbles(t: Float) {
    for (i in 0 until 14) {
        val p = rise(i, t, 22f, 10f)
        val r = dp(6f + 16f * rnd(i, 4))
        drawCircle(Color.White.copy(alpha = 0.07f), r, p)
        drawCircle(Color.White.copy(alpha = 0.4f), r, p, style = Stroke(dp(1f)))
        drawCircle(Color.White.copy(alpha = 0.55f), r * 0.18f, Offset(p.x - r * 0.4f, p.y - r * 0.4f))
    }
}

private fun DrawScope.neonSparks(t: Float) {
    val cols = listOf(Color(0xFF00F0FF), Color(0xFFFF3DDA), Color(0xFF9B5CFF))
    for (i in 0 until 16) {
        val tw = 0.5f + 0.5f * sin(t * (1f + rnd(i, 3) * 2f) + i * 3f)
        val c = cols[i % 3]
        val p = Offset(rnd(i, 0) * size.width, rnd(i, 1) * size.height)
        drawCircle(c.copy(alpha = 0.18f * tw), dp(7f), p)
        drawCircle(c.copy(alpha = 0.85f * tw), dp(1.6f), p)
    }
}

private fun DrawScope.eggs(t: Float) {
    val cols = listOf(Color(0xFFFFB3D1), Color(0xFFC9B6FF), Color(0xFFFFF0A0), Color(0xFFB8F0C8))
    for (i in 0 until 12) {
        val p = rise(i, t, 12f, 12f)
        val r = dp(5f + 4f * rnd(i, 4))
        val c = cols[i % cols.size]
        rotate(sin(t + i) * 12f, p) {
            drawOval(c.copy(alpha = 0.7f), Offset(p.x - r, p.y - r * 1.3f), Size(r * 2f, r * 2.6f))
            drawLine(Color.White.copy(alpha = 0.7f), Offset(p.x - r * 0.9f, p.y), Offset(p.x + r * 0.9f, p.y), dp(1.5f))
        }
    }
    for (i in 20 until 26) flower(fall(i, t, 14f, 8f), dp(3f), Color(0xFFFFFFFF), Color(0xFFFFD36B))
}

private fun DrawScope.flower(c: Offset, r: Float, petal: Color, core: Color, a: Float = 0.8f) {
    for (k in 0 until 5) {
        val ang = k / 5f * 2f * PI.toFloat()
        drawCircle(petal.copy(alpha = a), r, Offset(c.x + cos(ang) * r * 1.3f, c.y + sin(ang) * r * 1.3f))
    }
    drawCircle(core.copy(alpha = a), r * 0.8f, c)
}

private fun DrawScope.petals(t: Float) {
    for (i in 0 until 18) {
        val p = fall(i, t, 20f, 20f, 0.9f)
        rotate((t * 50f + i * 70f) % 360f, p) {
            drawOval(Color(0xFFFF9FC6).copy(alpha = 0.65f), Offset(p.x - dp(3f), p.y - dp(5f)), Size(dp(6f), dp(10f)))
        }
    }
    for (i in 30 until 34) flower(fall(i, t, 12f, 10f), dp(3.5f), Color(0xFFFFFFFF), Color(0xFFFFC857))
}

private fun DrawScope.bunting(t: Float) {
    val cols = listOf(Color(0xFFE53935), Color(0xFFFFC53D), Color(0xFF1E88E5), Color(0xFFFB8C00), Color(0xFF43A047))
    val y0 = dp(28f)
    val n = 10
    drawLine(Color(0xFF3B1A0C), Offset(0f, y0), Offset(size.width, y0 + dp(6f)), dp(1.2f))
    for (k in 0 until n) {
        val x = (k + 0.5f) / n * size.width
        val y = y0 + dp(6f) * x / size.width
        val sw = sin(t * 1.6f + k) * dp(1.5f)
        val w = size.width / n * 0.38f
        val flag = Path().apply { moveTo(x - w, y); lineTo(x + w, y); lineTo(x + sw, y + dp(16f)); close() }
        drawPath(flag, cols[k % cols.size].copy(alpha = 0.85f))
    }
}

private fun DrawScope.embers(t: Float) {
    for (i in 0 until 14) {
        val p = rise(i, t, 34f, 10f)
        val fade = (p.y / size.height).coerceIn(0f, 1f)
        val c = if (i % 2 == 0) Color(0xFFFFA733) else Color(0xFFFF5A1F)
        drawCircle(c.copy(alpha = 0.22f * fade), dp(5f), p)
        drawCircle(c.copy(alpha = 0.85f * fade), dp(1.5f), p)
    }
}

private fun DrawScope.stars(t: Float) {
    for (i in 0 until 14) {
        val tw = 0.4f + 0.6f * abs(sin(t * (0.8f + rnd(i, 3)) + i))
        decorSparkle(Offset(rnd(i, 0) * size.width, rnd(i, 1) * size.height * 0.8f), dp(2f + 2.5f * rnd(i, 4)), Color(0xFFFFC36B), 0.6f * tw)
    }
}

internal fun DrawScope.bat(c: Offset, s: Float, flap: Float, col: Color) {
    val w = s * (0.45f + 0.55f * abs(flap))
    val body = Path().apply {
        moveTo(c.x, c.y - s * 0.25f)
        quadraticTo(c.x - w * 0.5f, c.y - s * (0.7f + 0.3f * flap), c.x - w, c.y - s * 0.2f * flap)
        quadraticTo(c.x - w * 0.55f, c.y + s * 0.1f, c.x - w * 0.3f, c.y + s * 0.05f)
        quadraticTo(c.x, c.y + s * 0.4f, c.x + w * 0.3f, c.y + s * 0.05f)
        quadraticTo(c.x + w * 0.55f, c.y + s * 0.1f, c.x + w, c.y - s * 0.2f * flap)
        quadraticTo(c.x + w * 0.5f, c.y - s * (0.7f + 0.3f * flap), c.x, c.y - s * 0.25f)
        close()
    }
    drawPath(body, col)
}

private fun DrawScope.bats(t: Float) {
    for (i in 0 until 5) {
        val period = 14f + rnd(i, 1) * 8f
        val u = ((t + rnd(i, 2) * period) % period) / period
        val x = if (i % 2 == 0) u * (size.width + dp(60f)) - dp(30f) else size.width - u * (size.width + dp(60f)) + dp(30f)
        val y = size.height * (0.12f + 0.55f * rnd(i, 0)) + sin(u * 9f + i) * dp(18f)
        bat(Offset(x, y), dp(9f + 5f * rnd(i, 3)), sin(t * 11f + i * 2f), Color(0xFF05020A).copy(alpha = 0.85f))
    }
}
