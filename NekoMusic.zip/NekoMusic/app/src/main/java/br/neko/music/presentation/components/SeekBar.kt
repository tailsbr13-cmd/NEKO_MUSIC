package br.neko.music.presentation.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.unit.dp
import br.neko.music.presentation.theme.Neko

/**
 * Barra de progresso do player. Área de toque de 48 dp, toque direto posiciona e arrastar move
 * o cursor; o tempo é atualizado durante o arraste ([onScrub]) e a reprodução só salta ao soltar
 * ([onCommit]). Usa [lockedDrag], então a rolagem vertical da tela não interfere.
 */
@Composable
fun SeekBar(progress: Float, onScrub: (Float) -> Unit, onCommit: (Float) -> Unit, modifier: Modifier = Modifier) {
    var last = progress
    Canvas(
        modifier.fillMaxWidth().height(48.dp).lockedDrag(
            onDown = { p, s -> last = (p.x / s.width.toFloat()).coerceIn(0f, 1f); onScrub(last) },
            onMove = { p, s -> last = (p.x / s.width.toFloat()).coerceIn(0f, 1f); onScrub(last) },
            onEnd = { onCommit(last) },
        )
    ) {
        val pad = 0f
        val cy = size.height / 2f
        val w = size.width - pad * 2f
        val h = 4.dp.toPx()
        drawRoundRect(Neko.Deep, Offset(pad, cy - h / 2), Size(w, h), CornerRadius(h / 2))
        drawRoundRect(Neko.Cyan, Offset(pad, cy - h / 2), Size(w * progress.coerceIn(0f, 1f), h), CornerRadius(h / 2))
        val x = pad + w * progress.coerceIn(0f, 1f)
        drawCircle(Neko.Cyan.copy(alpha = 0.25f), 12.dp.toPx(), Offset(x, cy))
        drawCircle(Neko.Cyan, 7.dp.toPx(), Offset(x, cy))
    }
}
