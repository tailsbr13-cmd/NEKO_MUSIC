package br.neko.music

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import br.neko.music.player.PlayerViewModel
import br.neko.music.presentation.screens.HomeScreen
import br.neko.music.presentation.screens.PlayerScreen
import br.neko.music.presentation.screens.SettingsScreen
import br.neko.music.presentation.theme.NekoTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { NekoTheme { App() } }
    }
}

private enum class Screen { HOME, PLAYER, SETTINGS }

@Composable
private fun App(vm: PlayerViewModel = viewModel()) {
    var screen by rememberSaveable { mutableStateOf(Screen.HOME) }
    BackHandler(enabled = screen != Screen.HOME) { screen = Screen.HOME }

    Box(Modifier.fillMaxSize()) {
        HomeScreen(vm, onOpenPlayer = { screen = Screen.PLAYER }, onOpenSettings = { screen = Screen.SETTINGS })
        // O player desliza de baixo para cima (o estado fica no ViewModel, então nada se perde)
        AnimatedVisibility(screen == Screen.PLAYER, enter = slideInVertically { it } + fadeIn(), exit = slideOutVertically { it } + fadeOut()) {
            PlayerScreen(vm, onClose = { screen = Screen.HOME })
        }
        AnimatedVisibility(screen == Screen.SETTINGS, enter = slideInHorizontally { it }, exit = slideOutHorizontally { it }) {
            SettingsScreen(vm, onBack = { screen = Screen.HOME })
        }
    }
}
