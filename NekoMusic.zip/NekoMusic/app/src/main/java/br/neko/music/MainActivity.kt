package br.neko.music

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import android.app.Activity
import android.provider.Settings
import androidx.compose.ui.platform.LocalContext
import br.neko.music.presentation.splash.NekoSplash
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import br.neko.music.player.PlayerViewModel
import br.neko.music.presentation.screens.HomeScreen
import br.neko.music.presentation.screens.PlayerScreen
import br.neko.music.presentation.screens.SettingsScreen
import br.neko.music.presentation.theme.NekoTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { NekoTheme { App() } }
    }
}

private enum class Screen { HOME, PLAYER, SETTINGS }

@Composable
private fun App(vm: PlayerViewModel = viewModel()) {
    var screen by rememberSaveable { mutableStateOf(Screen.HOME) }
    BackHandler(enabled = screen != Screen.HOME) { screen = Screen.HOME }

    // Splash: só na abertura do app (rememberSaveable não repete ao navegar nem ao girar a tela).
    // Respeita "remover animações" do Android (escala de animação = 0): nesse caso nem aparece.
    val ctx = LocalContext.current
    val reducedMotion = remember { Settings.Global.getFloat(ctx.contentResolver, Settings.Global.ANIMATOR_DURATION_SCALE, 1f) == 0f }
    var showSplash by rememberSaveable { mutableStateOf(true) }
    BackHandler(enabled = showSplash) { showSplash = false }

    // Exclusão de música: o Android (Scoped Storage) pede a autorização do usuário nesta janela do sistema
    val deleteReq by vm.deleteRequest.collectAsStateWithLifecycle()
    val deleteLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { r ->
        vm.onDeleteResult(r.resultCode == Activity.RESULT_OK)
    }
    LaunchedEffect(deleteReq) { deleteReq?.let { deleteLauncher.launch(IntentSenderRequest.Builder(it.sender).build()) } }

    Box(Modifier.fillMaxSize()) {
        HomeScreen(vm, onOpenPlayer = { screen = Screen.PLAYER }, onOpenSettings = { screen = Screen.SETTINGS })
        // O player desliza de baixo para cima (o estado fica no ViewModel, então nada se perde)
        AnimatedVisibility(screen == Screen.PLAYER, enter = slideInVertically { it } + fadeIn(), exit = slideOutVertically { it } + fadeOut()) {
            PlayerScreen(vm, onClose = { screen = Screen.HOME })
        }
        AnimatedVisibility(screen == Screen.SETTINGS, enter = slideInHorizontally { it }, exit = slideOutHorizontally { it }) {
            SettingsScreen(vm, onBack = { screen = Screen.HOME })
        }
        // Camada mais alta: a biblioteca já está carregando por baixo, então a splash não atrasa o acesso
        if (showSplash && !reducedMotion) NekoSplash { showSplash = false }
    }
}
