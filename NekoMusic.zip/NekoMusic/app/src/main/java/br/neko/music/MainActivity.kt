package br.neko.music

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import android.app.Activity
import android.provider.Settings
import androidx.compose.ui.platform.LocalContext
import br.neko.music.presentation.splash.NekoSplash
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import br.neko.music.player.PlayerViewModel
import br.neko.music.presentation.screens.HomeScreen
import br.neko.music.presentation.screens.EqualizerScreen
import br.neko.music.presentation.screens.PlayerScreen
import br.neko.music.presentation.screens.SettingsScreen
import br.neko.music.presentation.theme.NekoTheme

class MainActivity : ComponentActivity() {
    companion object { const val EXTRA_OPEN_PLAYER = "br.neko.music.OPEN_PLAYER" }

    // Sobe a cada toque no cartão de mídia/notificação; a UI reage abrindo o player
    private val openPlayerSignal = mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        br.neko.music.presentation.theme.ThemeManager.init(applicationContext)
        enableEdgeToEdge()
        if (savedInstanceState == null && intent?.getBooleanExtra(EXTRA_OPEN_PLAYER, false) == true) openPlayerSignal.intValue++
        setContent { NekoTheme { App(openPlayerSignal.intValue) } }
    }

    override fun onResume() {
        super.onResume()
        br.neko.music.presentation.theme.ThemeManager.refreshDate()   // festividade entra/sai mesmo com o app fechado entre uma abertura e outra
    }

    // launchMode singleTask: com o app já aberto/em segundo plano, o toque chega aqui (sem criar outra tela)
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (intent.getBooleanExtra(EXTRA_OPEN_PLAYER, false)) openPlayerSignal.intValue++
    }
}

private enum class Screen { HOME, PLAYER, SETTINGS, EQUALIZER }

@Composable
private fun App(openPlayerSignal: Int, vm: PlayerViewModel = viewModel()) {
    var screen by rememberSaveable { mutableStateOf(Screen.HOME) }
    BackHandler(enabled = screen != Screen.HOME) { screen = if (screen == Screen.EQUALIZER) Screen.PLAYER else Screen.HOME }

    // Splash: só na abertura do app (rememberSaveable não repete ao navegar nem ao girar a tela).
    // Respeita "remover animações" do Android (escala de animação = 0): nesse caso nem aparece.
    val ctx = LocalContext.current
    val reducedMotion = remember { Settings.Global.getFloat(ctx.contentResolver, Settings.Global.ANIMATOR_DURATION_SCALE, 1f) == 0f }
    var showSplash by rememberSaveable { mutableStateOf(true) }
    BackHandler(enabled = showSplash) { showSplash = false }
    // Toque no cartão de mídia: pula a splash e abre o player
    LaunchedEffect(openPlayerSignal) { if (openPlayerSignal > 0) { showSplash = false; screen = Screen.PLAYER } }

    // Exclusão de música: o Android (Scoped Storage) pede a autorização do usuário nesta janela do sistema
    val deleteReq by vm.deleteRequest.collectAsStateWithLifecycle()
    val deleteLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { r ->
        vm.onDeleteResult(r.resultCode == Activity.RESULT_OK)
    }
    LaunchedEffect(deleteReq) { deleteReq?.let { deleteLauncher.launch(IntentSenderRequest.Builder(it.sender).build()) } }

    // Ícones da barra de status/navegação acompanham temas claros (pastel, Páscoa, Mães)
    val light = br.neko.music.presentation.theme.ThemeManager.colors.light
    val view = androidx.compose.ui.platform.LocalView.current
    SideEffect {
        val w = (view.context as Activity).window
        val c = androidx.core.view.WindowCompat.getInsetsController(w, view)
        c.isAppearanceLightStatusBars = light
        c.isAppearanceLightNavigationBars = light
    }
    // Meia-noite: relê a data para a festividade trocar mesmo com o app aberto
    LaunchedEffect(Unit) { while (true) { kotlinx.coroutines.delay(br.neko.music.presentation.theme.ThemeManager.msUntilMidnight()); br.neko.music.presentation.theme.ThemeManager.refreshDate() } }

    Box(Modifier.fillMaxSize()) {
        HomeScreen(
            vm, onOpenPlayer = { screen = Screen.PLAYER }, onOpenSettings = { screen = Screen.SETTINGS },
            mascotRunning = screen == Screen.HOME && !(showSplash && !reducedMotion),
        )
        // O player desliza de baixo para cima (o estado fica no ViewModel, então nada se perde)
        AnimatedVisibility(screen == Screen.PLAYER, enter = slideInVertically { it } + fadeIn(), exit = slideOutVertically { it } + fadeOut()) {
            PlayerScreen(vm, onClose = { screen = Screen.HOME }, onOpenEqualizer = { screen = Screen.EQUALIZER })
        }
        AnimatedVisibility(screen == Screen.SETTINGS, enter = slideInHorizontally { it }, exit = slideOutHorizontally { it }) {
            SettingsScreen(vm, onBack = { screen = Screen.HOME })
        }
        AnimatedVisibility(screen == Screen.EQUALIZER, enter = slideInHorizontally { it }, exit = slideOutHorizontally { it }) {
            EqualizerScreen(vm, onBack = { screen = Screen.PLAYER })
        }
        // Decoração do tema ativo (neve, confetes...): só desenha, não intercepta toques
        br.neko.music.presentation.components.ThemeDecor()
        // Faixa de saída da visualização de tema (vale para todas as telas)
        br.neko.music.presentation.screens.PreviewBanner(Modifier.align(androidx.compose.ui.Alignment.BottomCenter).navigationBarsPadding().padding(bottom = 96.dp))
        // Camada mais alta: a biblioteca já está carregando por baixo, então a splash não atrasa o acesso
        if (showSplash && !reducedMotion) NekoSplash { showSplash = false }
    }
}
