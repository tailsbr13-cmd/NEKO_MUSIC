package br.neko.music.data.database

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface NekoDao {
    // ----- Favoritos -----
    @Query("SELECT songKey FROM favorites ORDER BY addedAt DESC")
    fun favoriteKeys(): Flow<List<String>>
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun addFavorite(f: FavoriteEntity)
    @Query("DELETE FROM favorites WHERE songKey = :key")
    suspend fun removeFavorite(key: String)

    // ----- Playlists -----
    @Query("SELECT p.id AS id, p.name AS name, COUNT(ps.songKey) AS total FROM playlists p " +
        "LEFT JOIN playlist_songs ps ON ps.playlistId = p.id GROUP BY p.id ORDER BY p.name COLLATE NOCASE")
    fun playlists(): Flow<List<PlaylistSummary>>
    @Insert
    suspend fun insertPlaylist(p: PlaylistEntity): Long
    @Query("UPDATE playlists SET name = :name WHERE id = :id")
    suspend fun renamePlaylist(id: Long, name: String)
    @Query("DELETE FROM playlists WHERE id = :id")
    suspend fun deletePlaylist(id: Long)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun addToPlaylist(e: PlaylistSongEntity)
    @Query("DELETE FROM playlist_songs WHERE playlistId = :pid AND songKey = :key")
    suspend fun removeFromPlaylist(pid: Long, key: String)
    /** Usado quando a música é excluída do aparelho. */
    @Query("DELETE FROM playlist_songs WHERE songKey = :key")
    suspend fun removeFromAllPlaylists(key: String)
    @Query("SELECT songKey FROM playlist_songs WHERE playlistId = :pid ORDER BY addedAt")
    fun playlistKeys(pid: Long): Flow<List<String>>
}
