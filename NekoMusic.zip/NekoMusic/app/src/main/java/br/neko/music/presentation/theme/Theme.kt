package br.neko.music.presentation.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

/** Paleta BLUE do NEKO MUSIC */
object Neko {
    val Electric = Color(0xFF1749D8)
    val Deep = Color(0xFF102B83)
    val Navy = Color(0xFF080F26)
    val Cyan = Color(0xFF69EAD8)
    val IceWhite = Color(0xFFEAF4FF)
    val SteelGray = Color(0xFF879BBF)
    val Background = Brush.verticalGradient(listOf(Deep, Color(0xFF0B1A52), Navy))
}

private val scheme = darkColorScheme(
    primary = Neko.Cyan, onPrimary = Neko.Navy,
    secondary = Neko.Electric, background = Neko.Navy, onBackground = Neko.IceWhite,
    surface = Neko.Deep, onSurface = Neko.IceWhite, onSurfaceVariant = Neko.SteelGray,
)

@Composable
fun NekoTheme(content: @Composable () -> Unit) = MaterialTheme(colorScheme = scheme, content = content)
