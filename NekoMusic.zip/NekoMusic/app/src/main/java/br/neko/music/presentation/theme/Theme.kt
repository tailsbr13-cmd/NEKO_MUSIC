package br.neko.music.presentation.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

/**
 * Paleta ativa do NEKO MUSIC. Os nomes são os da paleta BLUE original, mas os valores vêm do tema
 * em vigor ([ThemeManager]); assim TODAS as telas mudam juntas, sem duplicar layouts.
 */
object Neko {
    val Electric: Color get() = ThemeManager.colors.electric
    val Deep: Color get() = ThemeManager.colors.deep
    val Navy: Color get() = ThemeManager.colors.navy
    val Cyan: Color get() = ThemeManager.colors.cyan
    val IceWhite: Color get() = ThemeManager.colors.ice
    val SteelGray: Color get() = ThemeManager.colors.steel
    val Background: Brush get() = ThemeManager.colors.background
}

@Composable
fun NekoTheme(content: @Composable () -> Unit) {
    val c = ThemeManager.colors
    val scheme = if (c.light) lightColorScheme(
        primary = c.cyan, onPrimary = Color.White, secondary = c.electric, background = c.navy, onBackground = c.ice,
        surface = c.deep, onSurface = c.ice, onSurfaceVariant = c.steel,
    ) else darkColorScheme(
        primary = c.cyan, onPrimary = c.navy, secondary = c.electric, background = c.navy, onBackground = c.ice,
        surface = c.deep, onSurface = c.ice, onSurfaceVariant = c.steel,
    )
    MaterialTheme(colorScheme = scheme, content = content)
}
