package br.neko.music.presentation.screens

import android.Manifest
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import br.neko.music.audio.EqModel
import br.neko.music.audio.EqPreset
import br.neko.music.audio.NekoEqualizer
import br.neko.music.media.Permissions
import br.neko.music.player.PlayerViewModel
import br.neko.music.presentation.components.EqFader
import br.neko.music.presentation.components.EqKnob
import br.neko.music.presentation.components.EqSpectrum
import br.neko.music.presentation.components.MetalButton
import br.neko.music.presentation.components.PowerButton
import br.neko.music.presentation.components.blockTouchesBehind
import br.neko.music.presentation.components.fmtDb
import br.neko.music.presentation.theme.Neko
import br.neko.music.visualizer.AudioVisualizerEngine

private val FreqLabels = listOf("60Hz", "150Hz", "400Hz", "1kHz", "2.4kHz", "6kHz", "15kHz")

/** Tela do equalizador: display de espectro, presets, 7 faders e botão de ganho. Tudo age no áudio em tempo real. */
@Composable
fun EqualizerScreen(vm: PlayerViewModel, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val st by NekoEqualizer.state.collectAsStateWithLifecycle()
    val playing by vm.playing.collectAsStateWithLifecycle()
    val sessionId by vm.audioSessionId.collectAsStateWithLifecycle()
    val vizStatus by vm.visualizer.status.collectAsStateWithLifecycle()

    var micGranted by remember { mutableStateOf(Permissions.hasMic(ctx)) }
    val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { micGranted = it }
    // O visualizador é compartilhado com o player (contagem de usuários): abrir/fechar esta tela não afeta a reprodução
    DisposableEffect(sessionId, micGranted) {
        sessionId?.let { vm.visualizer.start(ctx, it) }
        onDispose { vm.visualizer.stop() }
    }

    Column(
        Modifier.fillMaxSize().blockTouchesBehind()
            .background(Brush.verticalGradient(listOf(Color(0xFF0B0F1A), Color(0xFF04060A))))
            .statusBarsPadding().navigationBarsPadding()
            .verticalScroll(rememberScrollState()).padding(horizontal = 12.dp, vertical = 6.dp)
    ) {
        // ---------------- cabeçalho
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Voltar ao player", tint = Neko.IceWhite) }
            Text("EQUALIZADOR", color = Neko.Cyan, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 14.sp, letterSpacing = 2.sp, modifier = Modifier.weight(1f))
            PowerButton(st.enabled, { NekoEqualizer.setEnabled(!st.enabled) })
            Spacer(Modifier.width(8.dp))
            MetalButton("RESET", false, { NekoEqualizer.reset() }, Modifier.width(72.dp), fontSize = 12.sp, height = 36.dp)
        }
        Spacer(Modifier.height(6.dp))

        // ---------------- chassi do "mini system"
        val chassis = RoundedCornerShape(18.dp)
        Column(
            Modifier.fillMaxWidth().clip(chassis)
                .background(Brush.verticalGradient(listOf(Color(0xFF2C3140), Color(0xFF14171F), Color(0xFF0D0F15))))
                .border(2.dp, Brush.verticalGradient(listOf(Color(0xFFB9C2D6), Color(0xFF3A4152), Color(0xFF151822))), chassis)
                .padding(12.dp)
        ) {
            // display
            val lcd = RoundedCornerShape(10.dp)
            Box(
                Modifier.fillMaxWidth().height(132.dp).clip(lcd).border(2.dp, Color(0xFF05070B), lcd).border(1.dp, Color(0xFF3A4152), lcd).padding(6.dp)
            ) {
                EqSpectrum(vm.visualizer, active = playing && vizStatus == AudioVisualizerEngine.Status.ACTIVE, modifier = Modifier.fillMaxSize())
                if (vizStatus == AudioVisualizerEngine.Status.NO_PERMISSION || !micGranted) {
                    Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("O espectro precisa da permissão de áudio do Android (o app não grava o microfone).", color = Neko.IceWhite, fontSize = 11.sp, textAlign = TextAlign.Center)
                        TextButton({ micLauncher.launch(Manifest.permission.RECORD_AUDIO) }) { Text("ATIVAR ESPECTRO", color = Neko.Cyan, fontFamily = FontFamily.Monospace, fontSize = 12.sp) }
                    }
                } else if (vizStatus == AudioVisualizerEngine.Status.ERROR) {
                    Text("Espectro indisponível neste aparelho.", color = Neko.SteelGray, fontSize = 12.sp, modifier = Modifier.align(Alignment.Center))
                }
            }
            if (!st.available) {
                Text("Equalizador do sistema indisponível nesta sessão de áudio. Toque uma música; se persistir, o aparelho não oferece o efeito.", color = Color(0xFFFFB86B), fontSize = 11.sp, modifier = Modifier.padding(top = 8.dp))
            }
            Spacer(Modifier.height(12.dp))

            // presets (3 x 3)
            val presets = EqPreset.values().toList()
            for (row in presets.chunked(3)) {
                Row(Modifier.fillMaxWidth().padding(bottom = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    for (p in row) MetalButton(p.label, st.preset == p, { NekoEqualizer.setPreset(p) }, Modifier.weight(1f))
                }
            }
            Spacer(Modifier.height(4.dp))

            // faders
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top) {
                Column(Modifier.width(26.dp).padding(top = 32.dp).height(166.dp), verticalArrangement = Arrangement.SpaceBetween, horizontalAlignment = Alignment.End) {
                    for (t in listOf("+12", "0", "-12")) Text(t, color = Neko.SteelGray, fontFamily = FontFamily.Monospace, fontSize = 9.sp)
                }
                Row(Modifier.weight(1f)) {
                    for (i in 0 until 7) {
                        EqFader(st.bands[i], FreqLabels[i], st.enabled, { NekoEqualizer.setBand(i, it) }, Modifier.weight(1f))
                    }
                }
            }
            Spacer(Modifier.height(14.dp))

            // botão de ganho geral (preamp)
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
                EqKnob(st.preamp, st.enabled, { NekoEqualizer.setPreamp(it) }, Modifier.size(128.dp))
                Spacer(Modifier.width(18.dp))
                Column {
                    Text("PREAMP", color = Neko.IceWhite, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 14.sp, letterSpacing = 2.sp)
                    Text(fmtDb(st.preamp) + " dB", color = if (st.enabled) Neko.Cyan else Neko.SteelGray, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 22.sp)
                    Text("Gire o botão. Toque duplo zera.", color = Neko.SteelGray, fontSize = 11.sp)
                }
            }
        }
        Spacer(Modifier.height(8.dp))
        Text(
            "Ajuste de ${fmtDb(EqModel.MIN_DB)} a ${fmtDb(EqModel.MAX_DB)} dB por banda. Toque duplo em um fader zera a banda.",
            color = Neko.SteelGray, fontSize = 11.sp, modifier = Modifier.padding(horizontal = 4.dp, vertical = 4.dp),
        )
    }
}
