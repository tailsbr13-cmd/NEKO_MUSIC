package br.neko.music.presentation.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import android.Manifest
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import br.neko.music.media.Permissions
import br.neko.music.player.PlayerViewModel
import br.neko.music.presentation.components.blockTouchesBehind
import br.neko.music.presentation.theme.Neko

@Composable
fun SettingsScreen(vm: PlayerViewModel, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val songs by vm.songs.collectAsStateWithLifecycle()
    val scanning by vm.scanning.collectAsStateWithLifecycle()
    val showWa by vm.showWhatsApp.collectAsStateWithLifecycle()
    val waCount by vm.whatsAppCount.collectAsStateWithLifecycle()
    val showMp4 by vm.showMp4.collectAsStateWithLifecycle()
    var mic by remember { mutableStateOf(Permissions.hasMic(ctx)) }
    val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { mic = it }
    val version = remember { runCatching { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName }.getOrNull() ?: "?" }

    Column(Modifier.fillMaxSize().blockTouchesBehind().background(Neko.Background).statusBarsPadding().navigationBarsPadding()) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(4.dp)) {
            IconButton(onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Voltar", tint = Neko.IceWhite) }
            Text("CONFIGURAÇÕES", color = Neko.IceWhite, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
        }
        Section("BIBLIOTECA") {
            Text("${songs.size} faixas encontradas", color = Neko.IceWhite)
            Spacer(Modifier.height(8.dp))
            Button({ vm.refresh() }, enabled = !scanning, shape = RoundedCornerShape(6.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Neko.Cyan, contentColor = Neko.Navy)) {
                Text(if (scanning) "Atualizando…" else "Atualizar biblioteca")
            }
            Spacer(Modifier.height(16.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Mostrar áudios do WhatsApp", color = Neko.IceWhite)
                    Text(
                        "Mensagens de voz e áudios do WhatsApp e WhatsApp Business" + if (waCount > 0) " ($waCount no aparelho)" else "",
                        color = Neko.SteelGray, fontSize = 12.sp,
                    )
                }
                Switch(
                    checked = showWa, onCheckedChange = { vm.setShowWhatsApp(it) },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Neko.Navy, checkedTrackColor = Neko.Cyan,
                        uncheckedThumbColor = Neko.SteelGray, uncheckedTrackColor = Neko.Deep,
                    ),
                )
            }
            Spacer(Modifier.height(16.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Mostrar áudios de vídeos (MP4)", color = Neko.IceWhite)
                    Text("Inclui na biblioteca a faixa de áudio de arquivos de vídeo MP4", color = Neko.SteelGray, fontSize = 12.sp)
                }
                Switch(
                    checked = showMp4, onCheckedChange = { vm.setShowMp4(it) },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Neko.Navy, checkedTrackColor = Neko.Cyan,
                        uncheckedThumbColor = Neko.SteelGray, uncheckedTrackColor = Neko.Deep,
                    ),
                )
            }
        }
        Section("EQUALIZADOR") {
            Text(if (mic) "Análise de áudio ativa (permissão concedida)." else "Permissão de áudio necessária para o visualizador.", color = Neko.IceWhite)
            if (!mic) {
                Spacer(Modifier.height(8.dp))
                Button({ micLauncher.launch(Manifest.permission.RECORD_AUDIO) }, shape = RoundedCornerShape(6.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Neko.Cyan, contentColor = Neko.Navy)) { Text("Conceder permissão") }
            }
        }
        Section("SOBRE") {
            Text("NEKO MUSIC", color = Neko.IceWhite, fontWeight = FontWeight.Bold)
            Text("Versão $version", color = Neko.SteelGray, fontFamily = FontFamily.Monospace)
        }
    }
}

@Composable
private fun Section(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp)) {
        Text(title, color = Neko.Cyan, fontFamily = FontFamily.Monospace, fontSize = 12.sp, letterSpacing = 2.sp)
        Spacer(Modifier.height(8.dp))
        content()
    }
}
