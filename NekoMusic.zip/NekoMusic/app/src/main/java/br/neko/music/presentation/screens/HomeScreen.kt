package br.neko.music.presentation.screens

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Sort
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import br.neko.music.R
import br.neko.music.media.Permissions
import br.neko.music.media.Song
import br.neko.music.player.PlayerViewModel
import br.neko.music.presentation.components.*
import br.neko.music.presentation.theme.Neko

enum class LibTab(val label: String) { SONGS("Músicas"), ARTISTS("Artistas"), ALBUMS("Álbuns"), PLAYLISTS("Playlists"), FOLDERS("Pastas") }
enum class SortMode(val label: String) { TITLE("Título"), ARTIST("Artista"), RECENT("Mais recentes"), DURATION("Duração") }
private data class Group(val title: String, val songs: List<Song>)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(vm: PlayerViewModel, onOpenPlayer: () -> Unit, onOpenSettings: () -> Unit, mascotRunning: Boolean = true) {
    val ctx = LocalContext.current
    val songs by vm.songs.collectAsStateWithLifecycle()
    val scanning by vm.scanning.collectAsStateWithLifecycle()
    val scanned by vm.scanned.collectAsStateWithLifecycle()
    val current by vm.current.collectAsStateWithLifecycle()
    val playing by vm.playing.collectAsStateWithLifecycle()
    val mascotPlaying by vm.playbackActive.collectAsStateWithLifecycle()
    val position by vm.position.collectAsStateWithLifecycle()
    val duration by vm.duration.collectAsStateWithLifecycle()
    val error by vm.error.collectAsStateWithLifecycle()

    var granted by remember { mutableStateOf(Permissions.hasLibrary(ctx)) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        granted = Permissions.hasLibrary(ctx); if (granted) vm.refresh()
    }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { granted = Permissions.hasLibrary(ctx); if (granted) vm.refresh() }

    var tab by rememberSaveable { mutableStateOf(LibTab.SONGS) }
    var sort by rememberSaveable { mutableStateOf(SortMode.TITLE) }
    var query by rememberSaveable { mutableStateOf("") }
    var searching by rememberSaveable { mutableStateOf(false) }
    var sortMenu by remember { mutableStateOf(false) }
    var drill by remember { mutableStateOf<Group?>(null) }
    var actionSong by remember { mutableStateOf<Song?>(null) }
    BackHandler(enabled = drill != null) { drill = null }

    val visible = remember(songs, query, sort) {
        val q = query.trim()
        val f = if (q.isEmpty()) songs else songs.filter { it.title.contains(q, true) || it.artist.contains(q, true) || it.album.contains(q, true) }
        when (sort) {
            SortMode.TITLE -> f.sortedBy { it.title.lowercase() }
            SortMode.ARTIST -> f.sortedWith(compareBy({ it.artist.lowercase() }, { it.title.lowercase() }))
            SortMode.RECENT -> f.sortedByDescending { it.dateAdded }
            SortMode.DURATION -> f.sortedByDescending { it.durationMs }
        }
    }
    val groups = remember(visible, tab) {
        val keyFn: ((Song) -> String)? = when (tab) {
            LibTab.ARTISTS -> Song::artist
            LibTab.ALBUMS -> Song::album
            LibTab.FOLDERS -> Song::folder
            else -> null
        }
        keyFn?.let { f -> visible.groupBy(f).map { Group(it.key.ifEmpty { "Pasta desconhecida" }, it.value) }.sortedBy { it.title.lowercase() } } ?: emptyList()
    }

    Column(Modifier.fillMaxSize().background(Neko.Background).statusBarsPadding()) {
        // ---------- Cabeçalho ----------
        if (searching) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                TextField(
                    value = query, onValueChange = { query = it }, singleLine = true, modifier = Modifier.weight(1f),
                    placeholder = { Text("Buscar música, artista ou álbum", color = Neko.SteelGray) },
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = Color.Transparent, unfocusedContainerColor = Color.Transparent,
                        focusedTextColor = Neko.IceWhite, unfocusedTextColor = Neko.IceWhite, cursorColor = Neko.Cyan,
                        focusedIndicatorColor = Neko.Cyan, unfocusedIndicatorColor = Neko.SteelGray,
                    ),
                )
                IconButton({ searching = false; query = "" }) { Icon(Icons.Filled.Close, "Fechar busca", tint = Neko.IceWhite) }
            }
        } else {
            Row(Modifier.fillMaxWidth().padding(start = 14.dp, end = 4.dp, top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                NekoMascot(mascotPlaying, mascotRunning, Modifier.size(38.dp).clip(RoundedCornerShape(8.dp)))
                Spacer(Modifier.width(10.dp))
                Text("NEKO MUSIC", color = Neko.IceWhite, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 18.sp, letterSpacing = 2.sp)
                Spacer(Modifier.weight(1f))
                IconButton({ searching = true }) { Icon(Icons.Filled.Search, "Pesquisar", tint = Neko.IceWhite) }
                Box {
                    IconButton({ sortMenu = true }) { Icon(Icons.AutoMirrored.Filled.Sort, "Ordenar", tint = Neko.IceWhite) }
                    DropdownMenu(sortMenu, { sortMenu = false }) {
                        SortMode.entries.forEach { m ->
                            DropdownMenuItem(text = { Text(m.label, color = if (m == sort) Neko.Cyan else Color.Unspecified) }, onClick = { sort = m; sortMenu = false })
                        }
                    }
                }
                IconButton(onOpenSettings) { Icon(Icons.Filled.Settings, "Configurações", tint = Neko.IceWhite) }
            }
        }

        // ---------- Categorias ----------
        LazyRow(contentPadding = PaddingValues(horizontal = 12.dp, vertical = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(LibTab.entries) { t ->
                val sel = t == tab
                val shape = RoundedCornerShape(5.dp)
                Text(
                    t.label.uppercase(), fontFamily = FontFamily.Monospace, fontSize = 12.sp, letterSpacing = 1.sp,
                    fontWeight = FontWeight.Bold, color = if (sel) Neko.Navy else Neko.IceWhite,
                    modifier = Modifier.clip(shape)
                        .background(if (sel) Brush.verticalGradient(listOf(Color.White, Neko.Cyan)) else Brush.verticalGradient(listOf(Neko.Electric.copy(alpha = 0.5f), Neko.Deep)))
                        .border(1.dp, if (sel) Neko.Cyan else Neko.SteelGray.copy(alpha = 0.4f), shape)
                        .clickable { tab = t; drill = null }.padding(horizontal = 12.dp, vertical = 7.dp),
                )
            }
        }

        // ---------- Conteúdo ----------
        Box(Modifier.weight(1f).fillMaxWidth()) {
            when {
                !granted -> Message("Para tocar suas músicas, o NEKO MUSIC precisa ler os arquivos de áudio do aparelho.", "Permitir acesso") { launcher.launch(Permissions.library()) }
                scanning && songs.isEmpty() -> CircularProgressIndicator(Modifier.align(Alignment.Center), color = Neko.Cyan)
                scanned && songs.isEmpty() -> Message("Nenhum arquivo de áudio encontrado neste aparelho.", "Atualizar biblioteca") { vm.refresh() }
                tab == LibTab.PLAYLISTS -> PlaylistsTab(vm, songs, current?.key)
                visible.isEmpty() -> Message("Nada encontrado para \"$query\".")
                tab == LibTab.SONGS -> SongList(visible, current?.key, vm) { actionSong = it }
                drill != null -> Column {
                    Text("‹ ${drill!!.title}", color = Neko.Cyan, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold,
                        modifier = Modifier.fillMaxWidth().clickable { drill = null }.padding(14.dp))
                    SongList(drill!!.songs, current?.key, vm) { actionSong = it }
                }
                else -> LazyColumn(Modifier.fillMaxSize()) {
                    items(groups, key = { it.title }) { g ->
                        Row(Modifier.fillMaxWidth().clickable { drill = g }.padding(horizontal = 14.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                            CoverArt(g.songs.first(), Modifier.size(52.dp), px = 128)
                            Spacer(Modifier.width(12.dp))
                            Column {
                                Text(g.title, color = Neko.IceWhite, fontWeight = FontWeight.SemiBold, fontSize = 15.sp, maxLines = 1)
                                Text("${g.songs.size} música${if (g.songs.size > 1) "s" else ""}", color = Neko.SteelGray, fontSize = 12.sp)
                            }
                        }
                    }
                }
            }
            error?.let { msg ->
                Snackbar(Modifier.align(Alignment.BottomCenter).padding(8.dp), action = { TextButton({ vm.dismissError() }) { Text("OK", color = Neko.Cyan) } }) { Text(msg) }
            }
        }

        actionSong?.let { SongActionsDialog(vm, it, null) { actionSong = null } }

        // ---------- Mini player ----------
        val c = current
        if (c != null) {
            MiniPlayer(c, playing, if (duration > 0) (position.toFloat() / duration).coerceIn(0f, 1f) else 0f,
                onToggle = vm::togglePlay, onNext = vm::next, onClick = onOpenPlayer)
        }
        Spacer(Modifier.navigationBarsPadding())
    }
}

@Composable
private fun SongList(list: List<Song>, activeKey: String?, vm: PlayerViewModel, onMore: (Song) -> Unit) {
    LazyColumn(Modifier.fillMaxSize()) {
        itemsIndexed(list, key = { _, s -> s.key }) { i, s -> SongRow(s, s.key == activeKey, onMore = { onMore(s) }) { vm.play(list, i) } }
    }
}

@Composable
private fun Message(text: String, button: String? = null, onClick: () -> Unit = {}) {
    Column(Modifier.fillMaxSize().padding(32.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(text, color = Neko.IceWhite, textAlign = TextAlign.Center)
        if (button != null) {
            Spacer(Modifier.height(16.dp))
            Button(onClick, colors = ButtonDefaults.buttonColors(containerColor = Neko.Cyan, contentColor = Neko.Navy), shape = RoundedCornerShape(6.dp)) { Text(button) }
        }
    }
}
