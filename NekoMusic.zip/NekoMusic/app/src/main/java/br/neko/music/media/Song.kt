package br.neko.music.media

import android.net.Uri

/** Faixa encontrada no aparelho. Todos os dados vêm do MediaStore (nada inventado). */
data class Song(
    val id: Long,
    val uri: Uri,
    val title: String,
    val artist: String,
    val album: String,
    val albumId: Long,
    val durationMs: Long,
    val path: String,
    val dateAdded: Long,
    val fromVideo: Boolean, // true = arquivo .mp4 cuja faixa de áudio é tocada sem vídeo
) {
    /** Id único (ids de áudio e vídeo do MediaStore podem colidir). */
    val key: String get() = (if (fromVideo) "v" else "a") + id
    val folder: String get() = path.substringBeforeLast('/', "")
    val folderName: String get() = folder.substringAfterLast('/').ifEmpty { "Pasta desconhecida" }
}
