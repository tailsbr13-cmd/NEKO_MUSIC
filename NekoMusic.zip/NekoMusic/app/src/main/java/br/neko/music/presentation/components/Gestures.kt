package br.neko.music.presentation.components

import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.changedToUpIgnoreConsumed
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp

/**
 * Arraste "travado": consome o toque já no primeiro contato (ACTION_DOWN), de modo que nenhum
 * pai (verticalScroll, LazyColumn, pager de abas) consiga roubar o gesto no meio do arraste.
 * É a correção de raiz usada por todos os controles deslizantes do app (barra de progresso,
 * faders e knob do equalizador).
 *
 * - [onDown]: dedo encostou (também serve como "toque para posicionar").
 * - [onMove]: dedo se moveu (posição atual, tamanho do componente).
 * - [onEnd]: dedo soltou ou o gesto foi cancelado.
 * - [onDoubleTap]: dois toques rápidos sem arrastar (opcional).
 */
fun Modifier.lockedDrag(
    onDown: (Offset, IntSize) -> Unit = { _, _ -> },
    onMove: (Offset, IntSize) -> Unit,
    onEnd: () -> Unit = {},
    onDoubleTap: (() -> Unit)? = null,
): Modifier = composed {
    val down by rememberUpdatedState(onDown)
    val move by rememberUpdatedState(onMove)
    val end by rememberUpdatedState(onEnd)
    val dbl by rememberUpdatedState(onDoubleTap)
    var lastTapAt = 0L
    this.pointerInput(Unit) {
        val slop = viewConfiguration.touchSlop
        awaitEachGesture {
            val first = awaitFirstDown(requireUnconsumed = false)
            first.consume()
            val start = first.position
            var moved = false
            val isDouble = dbl != null && first.uptimeMillis - lastTapAt in 1..300
            down(start, size)
            try {
                while (true) {
                    val event = awaitPointerEvent()
                    val ch = event.changes.firstOrNull { it.id == first.id } ?: break
                    if (ch.changedToUpIgnoreConsumed()) { ch.consume(); break }
                    if (!ch.pressed) break
                    if (!moved && (ch.position - start).getDistance() > slop) moved = true
                    ch.consume()
                    move(ch.position, size)
                }
            } finally {
                end()
            }
            if (!moved) {
                if (isDouble) { dbl?.invoke(); lastTapAt = 0L } else lastTapAt = first.uptimeMillis
            } else lastTapAt = 0L
        }
    }
}

/**
 * Deslizar horizontal entre abas. Observa o gesto na passada INITIAL (antes dos filhos) sem
 * consumir nada até ter certeza de que o movimento é horizontal (|dx| > 2·|dy| e acima do slop).
 * Só então consome, de modo que a rolagem vertical das listas nunca é afetada e toques/cliques
 * passam normalmente. [onDrag] recebe o deslocamento atual (para o efeito de arrasto) e
 * [onSwipe] recebe -1 (esquerda → próxima aba) ou +1 (direita → aba anterior).
 */
fun Modifier.horizontalSwipe(onDrag: (Float) -> Unit, onSwipe: (Int) -> Unit): Modifier = composed {
    val drag by rememberUpdatedState(onDrag)
    val swipe by rememberUpdatedState(onSwipe)
    this.pointerInput(Unit) {
        val slop = viewConfiguration.touchSlop
        val commit = 64.dp.toPx()
        awaitEachGesture {
            val down = awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
            var dx = 0f
            var dy = 0f
            var locked = false
            var last = down.position
            while (true) {
                val ev = awaitPointerEvent(PointerEventPass.Initial)
                val ch = ev.changes.firstOrNull { it.id == down.id } ?: break
                if (!ch.pressed) break
                if (ev.changes.size > 1) break
                dx += ch.position.x - last.x
                dy += ch.position.y - last.y
                last = ch.position
                if (!locked) {
                    if (ch.isConsumed) break
                    if (kotlin.math.abs(dy) > slop && kotlin.math.abs(dy) >= kotlin.math.abs(dx)) break   // vertical: deixa a lista
                    if (kotlin.math.abs(dx) > slop * 2 && kotlin.math.abs(dx) > 2 * kotlin.math.abs(dy)) locked = true
                }
                if (locked) { ch.consume(); drag(dx) }
            }
            if (locked) {
                drag(0f)
                if (kotlin.math.abs(dx) > commit) swipe(if (dx < 0) -1 else 1)
            }
        }
    }
}
