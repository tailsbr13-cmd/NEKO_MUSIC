package br.neko.music.media

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.content.ContextCompat

object Permissions {
    /** Permissões pedidas na primeira abertura (somente o necessário para cada versão do Android). */
    fun library(): Array<String> =
        if (Build.VERSION.SDK_INT >= 33)
            arrayOf(Manifest.permission.READ_MEDIA_AUDIO, Manifest.permission.READ_MEDIA_VIDEO, Manifest.permission.POST_NOTIFICATIONS)
        else if (Build.VERSION.SDK_INT <= 28) arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE) // gravação: excluir músicas
        else arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)

    fun hasLibrary(ctx: Context): Boolean = granted(
        ctx, if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE
    )

    /** Necessária apenas para a Visualizer API (análise do áudio que o próprio app toca). */
    fun hasMic(ctx: Context): Boolean = granted(ctx, Manifest.permission.RECORD_AUDIO)

    private fun granted(ctx: Context, p: String) =
        ContextCompat.checkSelfPermission(ctx, p) == PackageManager.PERMISSION_GRANTED
}
