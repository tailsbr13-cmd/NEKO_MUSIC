package br.neko.music.data.database

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

/** songKey = Song.key (ex.: "a123"), id da faixa no MediaStore. */
@Entity(tableName = "favorites")
data class FavoriteEntity(@PrimaryKey val songKey: String, val addedAt: Long)

@Entity(tableName = "playlists")
data class PlaylistEntity(@PrimaryKey(autoGenerate = true) val id: Long = 0, val name: String, val createdAt: Long)

@Entity(
    tableName = "playlist_songs",
    primaryKeys = ["playlistId", "songKey"], // impede a mesma música duas vezes na playlist
    foreignKeys = [ForeignKey(PlaylistEntity::class, ["id"], ["playlistId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("playlistId")],
)
data class PlaylistSongEntity(val playlistId: Long, val songKey: String, val addedAt: Long)

/** Resultado da consulta de playlists com contagem. */
data class PlaylistSummary(val id: Long, val name: String, val total: Int)
