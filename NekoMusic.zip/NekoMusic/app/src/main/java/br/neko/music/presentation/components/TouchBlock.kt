package br.neko.music.presentation.components

import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput

/**
 * Telas sobrepostas (player/configurações) ficam num Box acima da biblioteca. No Compose, um irmão sem
 * tratador de toque NÃO consome eventos e eles "atravessam" para a camada de baixo.
 * Este modificador consome todo toque que sobra (depois que os filhos já o trataram na passada Main),
 * então botões, listas e sliders da própria tela continuam funcionando normalmente.
 */
fun Modifier.blockTouchesBehind(): Modifier = pointerInput(Unit) {
    awaitPointerEventScope {
        while (true) awaitPointerEvent().changes.forEach { it.consume() }
    }
}
